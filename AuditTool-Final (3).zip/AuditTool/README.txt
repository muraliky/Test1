Automation Audit Tool — Release Notes
======================================
Fixes in this release:
  1. CS2: @Override methods with Javadoc above them no longer falsely flagged
  2. FW10: Feature: keyword on line 1 correctly detected (BOM/CRLF/whitespace handled)
  3. FW6: WAF framework check now shows which files lack framework calls (not just blank row)
  4. FW13: octane.test.suite.id is now optional (not required for audit to pass)

ORGANISER SETUP:
  1. Edit automation-audit/config/output.config.js — set shared drive UNC path
  2. cd automation-audit && npm install

BUILD EXE (.NET 9 SDK):
  cd Launcher
  dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
  Output: Launcher\bin\Release\net9.0-windows\win-x64\publish\AuditLauncher.exe
  Place AuditLauncher.exe next to automation-audit\ folder.

RUN AUDIT (users):
  Double-click AuditLauncher.exe → fill 4 fields → Run Audit
  Node.js must be installed on user machine.

REFRESH DASHBOARD (organiser, after audits):
  cd automation-audit && node build-dashboard.js
  Opens AuditDashboard.html in shared drive — open in any browser.

'use strict';
const { collectFiles, readFile, searchInFiles, makeViolation } = require('./fileScanner');
const path = require('path');

function runCodingStandards(repoInfo) {
  const { repoPath, type } = repoInfo;
  const isQAF = type === 'qaf';
  const isPW  = type === 'playwright';

  // Crawl ALL source files — no sampling cap
  const javaFiles = isQAF ? collectFiles(repoPath, ['.java'])         : [];
  const tsFiles   = isPW  ? collectFiles(repoPath, ['.ts', '.js'])    : [];
  const srcFiles  = [...javaFiles, ...tsFiles];

  return {
    CS1: checkNaming(srcFiles, repoPath, isQAF, isPW),
    CS2: checkComments(srcFiles, repoPath, isQAF, isPW),
    CS3: checkCommentedCode(srcFiles, repoPath),
    CS4: checkErrorHandling(srcFiles, repoPath),
    CS5: checkHardcodedStrings(srcFiles, repoPath),
  };
}

// CS1 — Naming conventions
function checkNaming(files, repoPath, isQAF, isPW) {
  if (!files.length) return _na('No source files found');

  const violations = [];

  if (isQAF) {
    for (const file of files) {
      const content = readFile(file);
      const lines   = content.split('\n');
      lines.forEach((line, idx) => {
        // Class names starting with lowercase
        const classMatch = line.match(/^public\s+(?:class|interface|enum)\s+([a-z]\w*)\b/);
        if (classMatch) {
          violations.push({ file: path.relative(repoPath, file), lineNo: idx+1, issue: `Class name not PascalCase: '${classMatch[1]}'`, snippet: line.trim() });
        }
        // Single-letter variable names (excluding loop vars i,j,k,x,y,n,e)
        const singleVar = line.match(/\b(?:int|String|boolean|double|long|Object)\s+([a-wyz])\s*[=;]/);
        if (singleVar) {
          violations.push({ file: path.relative(repoPath, file), lineNo: idx+1, issue: `Single-character variable name: '${singleVar[1]}'`, snippet: line.trim() });
        }
      });
    }
  }

  if (isPW) {
    for (const file of files) {
      const content = readFile(file);
      const lines   = content.split('\n');
      lines.forEach((line, idx) => {
        // Standalone functions (not class methods) using PascalCase
        const badFn = line.match(/^(?:export\s+)?(?:async\s+)?function\s+([A-Z]\w+)\s*\(/);
        if (badFn) {
          violations.push({ file: path.relative(repoPath, file), lineNo: idx+1, issue: `Function name not camelCase: '${badFn[1]}'`, snippet: line.trim() });
        }
      });
    }
  }

  return _result(violations, `Naming conventions followed across ${files.length} file(s)`, 'naming violation(s) found');
}

// CS2 — Comments on methods/classes
function checkComments(files, repoPath, isQAF, isPW) {
  if (!files.length) return _na('No source files found');

  let total = 0, commented = 0;
  const violations = [];

  for (const file of files) {
    const content = readFile(file);
    const lines   = content.split('\n');
    const rel     = path.relative(repoPath, file);

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      const isMethod = isQAF
        ? /^(public|private|protected)\s+[\w<>\[\]]+\s+\w+\s*\(/.test(line)
        : /^(?:async\s+)?(?:function\s+\w+|\w+\s*[:=]\s*(?:async\s+)?\(.*\)\s*(?:=>|\{))/.test(line);

      if (isMethod) {
        total++;
        // Scan backwards past annotations (@Override, @SuppressWarnings, etc.)
        // to find a Javadoc/comment block above the method.
        // We look up to 10 lines back to handle multi-line annotations + comments.
        let hasComment = false;
        let scanIdx = i - 1;
        while (scanIdx >= 0 && scanIdx >= i - 10) {
          const scanLine = lines[scanIdx].trim();
          // Stop if we hit another method/class body (not an annotation or comment)
          if (scanLine.startsWith('@')) { scanIdx--; continue; }   // skip annotations
          if (scanLine === '') { scanIdx--; continue; }             // skip blank lines
          // Comment found
          if (scanLine.startsWith('//') || scanLine.startsWith('*') ||
              scanLine.startsWith('/*') || scanLine.startsWith('/**') ||
              scanLine === '*/') {
            hasComment = true;
            break;
          }
          // Hit actual code — stop looking
          break;
        }
        if (hasComment) {
          commented++;
        } else {
          const fnName = line.match(/\s(\w+)\s*\(/)?.[1] || 'method';
          violations.push({ file: rel, lineNo: i+1, issue: `No comment above method: '${fnName}'`, snippet: line.substring(0,80) });
        }
      }
    }
  }

  if (total === 0) return _na('No methods detected in source files');

  const pct    = Math.round((commented / total) * 100);
  const passed = pct >= 50;
  return {
    result:     passed ? 'Yes' : 'No',
    evidence:   `${commented}/${total} methods have comments (${pct}%)`,
    violations: violations.slice(0, 20),
  };
}

// CS3 — Commented-out code blocks
function checkCommentedCode(files, repoPath) {
  if (!files.length) return _na('No source files found');

  const patterns = [
    { p: /^\s*\/\/\s*(public|private|void|async\s+function|assertEquals|assertTrue|await\s+expect|page\.|driver\.)\s/i, label: 'Commented-out code' },
    { p: /^\s*\/\*\s*(public|private|void|async|assertEquals|await)\s/i,                                               label: 'Block-commented code' },
    { p: /^\s*\/\/\s*TODO\s*:\s*.{10,}/i,                                                                              label: 'Unresolved TODO' },
    { p: /^\s*\/\/\s*FIXME\s*:\s*.{5,}/i,                                                                             label: 'Unresolved FIXME' },
  ];

  const violations = [];
  for (const file of files) {
    const content = readFile(file);
    const lines   = content.split('\n');
    const rel     = path.relative(repoPath, file);
    lines.forEach((line, idx) => {
      for (const { p, label } of patterns) {
        if (p.test(line)) {
          violations.push({ file: rel, lineNo: idx+1, issue: `${label}: ${line.trim().substring(0,80)}`, snippet: line.trim() });
          break;
        }
      }
    });
  }

  return _result(violations, 'No commented-out code or unresolved TODOs found', 'commented-out code / TODO instance(s) found');
}

// CS4 — Error handling
function checkErrorHandling(files, repoPath) {
  if (!files.length) return _na('No source files found');

  const withTryCatch = new Set(
    searchInFiles(files, /\btry\s*\{/, repoPath).map(h => h.file)
  );
  const testOrPageFiles = files.filter(f => {
    const n = path.basename(f).toLowerCase();
    return n.includes('test') || n.includes('page') || n.includes('step') || n.includes('spec');
  });
  const missing = testOrPageFiles.filter(f => !withTryCatch.has(f));

  const total  = testOrPageFiles.length || files.length;
  const pct    = Math.round((withTryCatch.size / Math.max(total, 1)) * 100);
  const passed = pct >= 30 || withTryCatch.size >= 1;

  const violations = missing.slice(0, 15).map(f => ({
    file:    path.relative(repoPath, f),
    lineNo:  '',
    issue:   'No try-catch error handling found in this file',
    snippet: '',
  }));

  return {
    result:     passed ? 'Yes' : 'No',
    evidence:   `try-catch found in ${withTryCatch.size}/${files.length} file(s)`,
    violations: passed ? [] : violations,
  };
}

// CS5 — Hardcoded connection strings
function checkHardcodedStrings(files, repoPath) {
  if (!files.length) return _na('No source files found');

  const patterns = [
    { p: /jdbc:[a-z]+:\/\/[^\s"']+/i,                                    label: 'Hardcoded JDBC URL' },
    { p: /mongodb(\+srv)?:\/\/[^\s"']+/i,                                label: 'Hardcoded MongoDB URL' },
    { p: /connectionString\s*=\s*["'][^"']+["']/i,                       label: 'Hardcoded connection string' },
    { p: /Provider=.*Data Source=/i,                                      label: 'Hardcoded ADO connection' },
    { p: /\.xlsx.*password\s*=\s*["'][^"']+["']/i,                       label: 'Hardcoded Excel password' },
    { p: /dataSource\s*=\s*["'][^"']+["']/i,                             label: 'Hardcoded dataSource' },
    { p: /(DB_URL|DATABASE_URL)\s*=\s*["'][^"']{10,}["']/i,              label: 'Hardcoded DB URL in variable' },
  ];

  const violations = [];
  for (const { p, label } of patterns) {
    searchInFiles(files, p, repoPath).forEach(h =>
      violations.push({ file: h.relativePath, lineNo: h.lineNo, issue: `${label}: ${h.line.substring(0,80)}`, snippet: h.line })
    );
  }

  return _result(violations, 'No hardcoded DB/Excel connection strings found', 'hardcoded connection string(s) found');
}

// ─── Shared helpers ───────────────────────────────────────────────────────────
function _na(evidence)  { return { result: 'N/A', evidence, violations: [] }; }

function _result(violations, passMsg, failSuffix) {
  const passed = violations.length === 0;
  return {
    result:     passed ? 'Yes' : 'No',
    evidence:   passed ? passMsg : `${violations.length} ${failSuffix}`,
    violations: violations.slice(0, 25),
  };
}

module.exports = { runCodingStandards };

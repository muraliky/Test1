Automation Audit Tool
=====================

ORGANISER SETUP:
  1. Edit automation-audit/config/output.config.js  — set shared drive path
  2. cd automation-audit && npm install

BUILD EXE (.NET 9 SDK required):
  cd Launcher
  dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
  Output: Launcher\bin\Release\net9.0-windows\win-x64\publish\AuditLauncher.exe

DISTRIBUTE:
  Place AuditLauncher.exe next to automation-audit\ folder and share with teams.
  Users need Node.js installed. Double-click AuditLauncher.exe to run audits.

REFRESH DASHBOARD (after each audit cycle):
  cd automation-audit
  node build-dashboard.js
  Opens AuditDashboard.html in the shared drive — open in any browser.

DASHBOARD TABS:
  Overview   — Volume KPIs, Quality KPIs, Technology Adoption rings
  Trends     — Score trend, Maturity, Category pass rates, LOB comparison, Top violations
  Health     — Category accordion (check drill-down), At-risk repos, Most improved
  All Audits — Full sortable table with trend indicators

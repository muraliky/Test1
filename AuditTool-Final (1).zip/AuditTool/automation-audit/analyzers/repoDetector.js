'use strict';
const fs = require('fs');
const path = require('path');

function detectRepo(repoPath) {
  const info = {
    type: 'unknown',
    buildTool: 'unknown',
    hasBDD: false,
    hasTestNG: false,
    hasCucumber: false,
    hasPlaywright: false,
    rootFiles: fs.readdirSync(repoPath),
    repoPath
  };

  const rootFiles = info.rootFiles.map(f => f.toLowerCase());

  if (rootFiles.includes('build.gradle') || rootFiles.includes('build.gradle.kts')) {
    info.buildTool = 'gradle';
  } else if (rootFiles.includes('pom.xml')) {
    info.buildTool = 'maven';
  } else if (rootFiles.includes('package.json')) {
    info.buildTool = 'npm';
  }

  if (info.buildTool === 'gradle' || info.buildTool === 'maven') {
    info.type = 'qaf';
    const buildContent = _readBuildFile(repoPath, info.buildTool);
    info.hasQAF = buildContent.includes('qaf') || buildContent.includes('qmetry');
    info.hasSelenium = buildContent.includes('selenium');
    info.hasCucumber = buildContent.includes('cucumber');
    info.hasTestNG = buildContent.includes('testng');
    info.buildFileContent = buildContent;
  } else if (info.buildTool === 'npm') {
    const pkgPath = path.join(repoPath, 'package.json');
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
      const allDeps = { ...pkg.dependencies, ...pkg.devDependencies };
      info.hasPlaywright = !!allDeps['@playwright/test'] || !!allDeps['playwright'];
      info.hasCucumber = !!allDeps['@cucumber/cucumber'];
      info.packageJson = pkg;
      info.type = info.hasPlaywright ? 'playwright' : 'unknown';
    } catch (e) {}
  }

  info.hasBDD = _hasFeatureFiles(repoPath);
  return info;
}

function _readBuildFile(repoPath, buildTool) {
  try {
    if (buildTool === 'gradle') {
      const f = path.join(repoPath, 'build.gradle');
      const fk = path.join(repoPath, 'build.gradle.kts');
      if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8').toLowerCase();
      if (fs.existsSync(fk)) return fs.readFileSync(fk, 'utf8').toLowerCase();
    } else if (buildTool === 'maven') {
      const f = path.join(repoPath, 'pom.xml');
      if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8').toLowerCase();
    }
  } catch (e) {}
  return '';
}

function _hasFeatureFiles(repoPath) {
  function walk(dir, depth = 0) {
    if (depth > 6) return false;
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const e of entries) {
        if (e.name.startsWith('.') || e.name === 'node_modules') continue;
        if (e.isDirectory()) {
          if (walk(path.join(dir, e.name), depth + 1)) return true;
        } else if (e.name.endsWith('.feature')) {
          return true;
        }
      }
    } catch (e) {}
    return false;
  }
  return walk(repoPath);
}

module.exports = { detectRepo };

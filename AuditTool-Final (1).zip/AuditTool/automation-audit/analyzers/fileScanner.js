'use strict';
const fs   = require('fs');
const path = require('path');

// Dirs to never crawl — build output, packages, IDE, VCS internals
const SKIP_DIRS = new Set([
  'node_modules', '.git', 'target', 'build', 'dist', 'out',
  '.gradle', '.idea', '.vscode', '__pycache__', '.mvn',
  'coverage', '.nyc_output', 'test-results', 'playwright-report',
  'allure-results', 'allure-report', '.cache', 'logs'
]);

/**
 * Walk every directory in the repo (including dot-dirs like .github, .ci)
 * unless they're in the skip list above.
 * Returns absolute file paths.
 */
function collectFiles(dir, extensions, _maxDepth = 15, _depth = 0) {
  const results = [];
  if (_depth > _maxDepth) return results;

  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch { return results; }

  for (const e of entries) {
    // Skip only the explicit deny-list — NOT all dot-dirs
    if (SKIP_DIRS.has(e.name)) continue;

    const full = path.join(dir, e.name);

    if (e.isDirectory()) {
      results.push(...collectFiles(full, extensions, _maxDepth, _depth + 1));
    } else if (e.isFile()) {
      if (!extensions || extensions.includes(path.extname(e.name).toLowerCase())) {
        results.push(full);
      }
    }
  }
  return results;
}

/**
 * Read a file safely — returns '' on any error.
 */
function readFile(filePath) {
  try { return fs.readFileSync(filePath, 'utf8'); }
  catch { return ''; }
}

/**
 * Search pattern across files.
 * Returns hits with:
 *   file        — absolute path
 *   relativePath — path relative to repoRoot (if provided), else basename
 *   lineNo      — 1-based line number
 *   line        — trimmed matching line content (max 120 chars)
 */
function searchInFiles(files, pattern, repoRoot = '') {
  const hits = [];
  for (const file of files) {
    const content = readFile(file);
    if (!content) continue;
    const lines = content.split('\n');
    lines.forEach((line, idx) => {
      if (pattern.test(line)) {
        const rel = repoRoot
          ? path.relative(repoRoot, file)
          : path.basename(file);
        hits.push({
          file:         file,
          relativePath: rel,
          lineNo:       idx + 1,
          line:         line.trim().substring(0, 120),
        });
      }
    });
  }
  return hits;
}

/**
 * Build a clean violation object — used by all analyzers for consistency.
 * file     → relative path from repo root
 * lineNo   → 1-based line number
 * issue    → human-readable description of the problem
 * snippet  → the actual offending line (trimmed, max 120 chars)
 */
function makeViolation(hit, issue) {
  return {
    file:    hit.relativePath || path.basename(hit.file),
    lineNo:  hit.lineNo,
    issue,
    snippet: hit.line,
  };
}

module.exports = { collectFiles, readFile, searchInFiles, makeViolation };

'use strict';

/**
 * CATS Team — Audit Dashboard Builder
 *
 * Reads all *_findings.json files from the configured output path,
 * embeds them into the dashboard template, and writes
 * AuditDashboard.html to the same shared drive folder.
 *
 * Usage:
 *   node build-dashboard.js
 *
 * No arguments needed — reads AUDIT_OUTPUT_PATH from config/output.config.js
 */

const fs   = require('fs');
const path = require('path');

// ── Load config ───────────────────────────────────────────────────────────────
const { AUDIT_OUTPUT_PATH } = require('./config/output.config.js');

// ── Validate paths ────────────────────────────────────────────────────────────
if (!AUDIT_OUTPUT_PATH || !AUDIT_OUTPUT_PATH.trim()) {
  console.error('✖  AUDIT_OUTPUT_PATH is not set in config/output.config.js');
  process.exit(1);
}

if (!fs.existsSync(AUDIT_OUTPUT_PATH)) {
  console.error(`✖  Output path not found: ${AUDIT_OUTPUT_PATH}`);
  console.error('   Ensure the shared drive is mapped and accessible.');
  process.exit(1);
}

// ── Dashboard template ────────────────────────────────────────────────────────
// Template lives next to this script in the same folder
const templatePath = path.join(__dirname, 'dashboard-template.html');
if (!fs.existsSync(templatePath)) {
  console.error(`✖  Dashboard template not found: ${templatePath}`);
  console.error('   Ensure dashboard-template.html is in the automation-audit folder.');
  process.exit(1);
}

// ── Collect all findings JSON files ──────────────────────────────────────────
console.log(`\n📂 Scanning: ${AUDIT_OUTPUT_PATH}\n`);

const jsonFiles = fs.readdirSync(AUDIT_OUTPUT_PATH)
  .filter(f => f.endsWith('_findings.json'))
  .map(f => path.join(AUDIT_OUTPUT_PATH, f));

if (jsonFiles.length === 0) {
  console.error('✖  No *_findings.json files found in the output folder.');
  console.error('   Run at least one audit first, then re-run this script.');
  process.exit(1);
}

console.log(`   Found ${jsonFiles.length} findings file(s):\n`);

// ── Read and parse each file ──────────────────────────────────────────────────
const records = [];
const errors  = [];

for (const filePath of jsonFiles) {
  const fileName = path.basename(filePath);
  try {
    const raw  = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(raw);

    // Basic structure validation
    if (!data.meta || !data.categories || typeof data.percentage !== 'number') {
      errors.push(`  ⚠  Skipped (invalid structure): ${fileName}`);
      continue;
    }

    // Derive auditMonth from date if not present (real audit files don't include it)
    if (!data.meta.auditMonth && data.meta.date) {
      try {
        const p  = data.meta.date.split('/');
        const dt = new Date(+p[2], +p[1] - 1, +p[0]);
        if (!isNaN(dt)) {
          data.meta.auditMonth = dt.toLocaleString('en-GB', { month: 'long', year: 'numeric' });
        }
      } catch (_) {}
    }

    records.push(data);
    console.log(`   ✔  ${fileName}  (${data.meta.projectName} | ${data.percentage}% | Mat ${data.maturityIndex})`);

  } catch (e) {
    errors.push(`  ✖  Failed to parse: ${fileName} — ${e.message}`);
  }
}

// Report any errors
if (errors.length > 0) {
  console.log('\n   Warnings:');
  errors.forEach(e => console.log(e));
}

if (records.length === 0) {
  console.error('\n✖  No valid audit records found. Nothing to build.');
  process.exit(1);
}

// ── Inject data into template ─────────────────────────────────────────────────
console.log(`\n📊 Building dashboard with ${records.length} record(s)...`);

const template  = fs.readFileSync(templatePath, 'utf8');
const outputHtml = template.replace('__AUDIT_DATA__', JSON.stringify(records));

// ── Write output ──────────────────────────────────────────────────────────────
const outputPath = path.join(AUDIT_OUTPUT_PATH, 'AuditDashboard.html');
fs.writeFileSync(outputPath, outputHtml, 'utf8');

const sizeKB = Math.round(fs.statSync(outputPath).size / 1024);

console.log(`\n✅  Dashboard built successfully!`);
console.log(`   📄 Output   : ${outputPath}`);
console.log(`   📦 Size     : ${sizeKB} KB`);
console.log(`   📋 Records  : ${records.length}`);
console.log(`   🏢 Projects : ${new Set(records.map(r => r.meta.projectName)).size}`);
console.log(`\n   Open AuditDashboard.html in any browser — no server needed.\n`);

'use strict';

// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  ORGANISER: Update AUDIT_OUTPUT_PATH before distributing to users.     ║
// ║  Users do NOT need to change this file.                                ║
// ╚══════════════════════════════════════════════════════════════════════════╝
const AUDIT_OUTPUT_PATH = '\\\\wf-server\\cats-audits\\2026-Q3';
module.exports = { AUDIT_OUTPUT_PATH };

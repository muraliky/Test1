'use strict';
const ExcelJS = require('exceljs');
const path    = require('path');

const C = {
  headerBg : 'FF1F3864',
  catBg    : 'FFD9E1F2',
  catText  : 'FF1F3864',
  yes      : 'FF00B050',
  no       : 'FFCC0000',
  manual   : 'FFBF8F00',
  na       : 'FF808080',
  totalBg  : 'FFFFD966',
  white    : 'FFFFFFFF',
  rowAlt   : 'FFF5F8FF',
  rowRed   : 'FFFFF0F0',  // light red tint for failed rows
  textRed  : 'FFCC0000',  // dark red text for violations
  mat: ['FFCC0000','FFFF6600','FFFFC000','FF92D050','FF00B050'],
};

async function generateReport(auditResult, outputPath) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'CATS Automation Audit Tool v3';
  wb.created = new Date();

  _buildInfoSheet(wb);
  await _buildAuditSheet(wb, auditResult);
  await _buildViolationsSheet(wb, auditResult);

  await wb.xlsx.writeFile(outputPath);
  return outputPath;
}

// ─── Sheet 1: How Audit is Performed ─────────────────────────────────────────
function _buildInfoSheet(wb) {
  const ws = wb.addWorksheet('How Audit is Performed');
  ws.getColumn('A').width = 100;

  const title = ws.addRow(['How Audit will be Performed?']);
  title.getCell(1).font = { bold: true, size: 13, color: { argb: C.white } };
  title.getCell(1).fill = _fill(C.headerBg);
  title.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
  title.height = 28;

  const lines = [
    '1. Each Test automation project will be assessed against 4 types of standards: Coding Standards, Framework Automation Standards, Mode of Execution and GIT.',
    '2. Each standard will have defined check points against which the project will be assessed.',
    '3. Each check point carries a weightage of 1 point.',
    '4. At end of audit, percentage will be calculated based on points scored divided by Total points.',
    '5. Based on the percentage the Automation Maturity Index will be calculated:',
    '      1 — If percentage is < 25  (Initial)',
    '      2 — If percentage is >= 25 and <= 50  (Developing)',
    '      3 — If percentage is >= 50 and <= 75  (Defined)',
    '      4 — If percentage is >= 75 and < 100  (Managed)',
    '      5 — If percentage is 100  (Optimized)',
  ];
  for (const line of lines) {
    const r = ws.addRow([line]);
    r.getCell(1).font = { size: 11 };
    r.getCell(1).alignment = { wrapText: true };
    r.height = 20;
  }
}

// ─── Sheet 2: Audit Results ───────────────────────────────────────────────────
async function _buildAuditSheet(wb, d) {
  const ws = wb.addWorksheet('Test Automation Audit', { views: [{ state: 'frozen', ySplit: 6 }] });

  ws.columns = [
    { width: 5  }, // A
    { width: 6  }, // B - #
    { width: 68 }, // C - description
    { width: 8  }, // D - Yes
    { width: 8  }, // E - No
    { width: 8  }, // F - N/A
    { width: 48 }, // G - Evidence
    { width: 12 }, // H - Weightage
    { width: 14 }, // I - Points
  ];

  // Title
  ws.mergeCells('A1:I1');
  const t = ws.getCell('A1');
  t.value = 'Test Automation Audit';
  t.font  = { bold: true, size: 16, color: { argb: C.white } };
  t.fill  = _fill(C.headerBg);
  t.alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(1).height = 30;

  // Meta rows
  const metaData = [
    ['Project Name', d.meta.projectName],
    ['LOB',          d.meta.lob ? d.meta.lob.split('/')[0].trim() : 'WIM'],
    ['Sub LOB',      d.meta.lob && d.meta.lob.includes('/') ? d.meta.lob.split('/').slice(1).join('/').trim() : ''],
    ['Date',         d.meta.date],
    ['Repo Type',    d.meta.repoLabel],
  ];
  metaData.forEach(([label, value], i) => {
    const rn = i + 2;
    ws.getCell(`B${rn}`).value = label;
    ws.getCell(`B${rn}`).font  = { bold: true };
    ws.mergeCells(`C${rn}:I${rn}`);
    ws.getCell(`C${rn}`).value = value;
    ws.getRow(rn).height = 18;
  });

  // Column headers row 6
  const hdrValues = ['', '#', 'Check Points', 'Yes', 'No', 'N/A', 'Remarks / Evidence', 'Weightage', 'Points'];
  const hdr = ws.getRow(6);
  hdrValues.forEach((v, i) => {
    const cell = hdr.getCell(i + 1);
    cell.value = v;
    cell.font  = { bold: true, color: { argb: C.white }, size: 11 };
    cell.fill  = _fill('FF2E5DA6');
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = _bdr();
  });
  hdr.height = 28;

  let rowIdx = 7;

  for (const cat of d.categories) {
    // Category header
    ws.mergeCells(`B${rowIdx}:I${rowIdx}`);
    const catCell = ws.getCell(`B${rowIdx}`);
    catCell.value = cat.name;
    catCell.font  = { bold: true, size: 11, color: { argb: C.catText } };
    catCell.fill  = _fill(C.catBg);
    catCell.alignment = { vertical: 'middle' };
    ws.getRow(rowIdx).height = 22;
    rowIdx++;

    cat.checks.forEach((chk, i) => {
      const isYes    = chk.result === 'Yes';
      const isNo     = chk.result === 'No';
      const isManual = chk.result === 'Manual';
      const isNA     = chk.result === 'N/A';

      const row = ws.getRow(rowIdx);
      row.values = [
        '',
        i + 1,
        chk.description,
        isYes    ? '✔' : '',
        isNo     ? '✔' : '',
        (isNA || isManual) ? '✔' : '',
        chk.evidence || '',
        1,
        isYes ? 1 : 0,
      ];

      // Highlight entire row red (light tint) if FAILED
      if (isNo) {
        for (let c = 1; c <= 9; c++) {
          row.getCell(c).fill = _fill(C.rowRed);
        }
      } else if ((i % 2) === 1) {
        for (let c = 1; c <= 9; c++) {
          row.getCell(c).fill = _fill(C.rowAlt);
        }
      }

      // Result badge cells D / E / F
      const resColors = { D: C.yes, E: C.no, F: C.manual };
      const colHasCheck = { D: isYes, E: isNo, F: isNA || isManual };
      ['D','E','F'].forEach(col => {
        const cell = row.getCell(col);
        cell.alignment = { horizontal: 'center', vertical: 'middle' };
        cell.border = _bdr();
        if (colHasCheck[col]) {
          cell.fill = _fill(resColors[col]);
          cell.font = { bold: true, color: { argb: C.white }, size: 13 };
        }
      });

      // Description & evidence
      row.getCell('C').alignment = { wrapText: true, vertical: 'middle' };
      row.getCell('G').alignment = { wrapText: true, vertical: 'middle' };
      if (isNo) {
        row.getCell('C').font = { color: { argb: C.textRed } };
        row.getCell('G').font = { color: { argb: C.textRed }, italic: true };
      }

      // Number col
      row.getCell('B').alignment = { horizontal: 'center', vertical: 'middle' };
      row.getCell('H').alignment = { horizontal: 'center', vertical: 'middle' };
      row.getCell('I').alignment = { horizontal: 'center', vertical: 'middle' };
      if (isYes) row.getCell('I').font = { bold: true, color: { argb: C.yes } };
      if (isNo)  row.getCell('I').font = { bold: true, color: { argb: C.no  } };

      ['B','C','G','H','I'].forEach(c => { row.getCell(c).border = _bdr(); });
      row.height = chk.description.length > 90 ? 36 : 28;
      rowIdx++;
    });
  }

  // Totals row
  const totRow = ws.getRow(rowIdx);
  ws.mergeCells(`A${rowIdx}:G${rowIdx}`);
  totRow.getCell('A').value = 'Total:';
  totRow.getCell('A').font  = { bold: true, size: 12 };
  totRow.getCell('A').alignment = { horizontal: 'right', vertical: 'middle' };
  totRow.getCell('H').value = d.totalChecks;
  totRow.getCell('H').font  = { bold: true };
  totRow.getCell('I').value = d.totalScore;
  totRow.getCell('I').font  = { bold: true };
  for (let c = 1; c <= 9; c++) { totRow.getCell(c).fill = _fill(C.totalBg); totRow.getCell(c).border = _bdr(); }
  totRow.height = 24;
  rowIdx += 2;

  // Maturity
  const matRow = ws.getRow(rowIdx);
  ws.mergeCells(`A${rowIdx}:D${rowIdx}`);
  matRow.getCell('A').value = 'Automation Maturity Index';
  matRow.getCell('A').font  = { bold: true, size: 13 };
  matRow.getCell('A').alignment = { vertical: 'middle' };
  matRow.getCell('E').value = d.maturityIndex;
  matRow.getCell('E').font  = { bold: true, size: 18, color: { argb: C.white } };
  matRow.getCell('E').fill  = _fill(C.mat[d.maturityIndex - 1] || C.mat[0]);
  matRow.getCell('E').alignment = { horizontal: 'center', vertical: 'middle' };
  matRow.getCell('F').value = `${d.percentage}%`;
  matRow.getCell('F').font  = { bold: true, size: 13 };
  matRow.getCell('G').value = d.maturityLabel;
  matRow.getCell('G').font  = { bold: true, size: 12, color: { argb: C.mat[d.maturityIndex - 1] || C.mat[0] } };
  matRow.height = 36;
}

// ─── Sheet 3: Violations Detail ───────────────────────────────────────────────
async function _buildViolationsSheet(wb, d) {
  const ws = wb.addWorksheet('Findings Detail');

  ws.columns = [
    { width: 22 }, // A — Category
    { width: 9  }, // B — Check ID
    { width: 52 }, // C — Checkpoint description
    { width: 10 }, // D — Result
    { width: 38 }, // E — File path
    { width: 10 }, // F — Line No
    { width: 58 }, // G — Issue description
    { width: 55 }, // H — Code snippet
  ];

  // Header
  const hdrVals = ['Category','Check ID','Check Point Description','Result','File','Line No','Issue','Code Snippet'];
  const hdr = ws.getRow(1);
  hdrVals.forEach((v, i) => {
    const cell = hdr.getCell(i + 1);
    cell.value = v;
    cell.font  = { bold: true, color: { argb: C.white }, size: 11 };
    cell.fill  = _fill(C.headerBg);
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = _bdr();
  });
  hdr.height = 28;

  let rowIdx = 2;
  let hasViolations = false;

  for (const cat of d.categories) {
    for (const chk of cat.checks) {
      if (!chk.violations || chk.violations.length === 0) continue;

      // Category sub-header for this check
      ws.mergeCells(`A${rowIdx}:H${rowIdx}`);
      const subHdr = ws.getCell(`A${rowIdx}`);
      subHdr.value = `${cat.name}  →  [${chk.id}] ${chk.description}`;
      subHdr.font  = { bold: true, size: 10, color: { argb: C.white } };
      subHdr.fill  = _fill('FF2E5DA6');
      subHdr.alignment = { wrapText: true, vertical: 'middle' };
      ws.getRow(rowIdx).height = 22;
      rowIdx++;

      for (const v of chk.violations) {
        const row = ws.getRow(rowIdx);
        row.values = [
          cat.name,
          chk.id,
          chk.description,
          chk.result,
          v.file    || '',
          v.lineNo  || '',
          v.issue   || '',
          v.snippet || '',
        ];

        // Entire row gets red fill + dark red text for failed checks
        for (let c = 1; c <= 8; c++) {
          row.getCell(c).fill   = _fill(C.rowRed);
          row.getCell(c).font   = { size: 10, color: { argb: '88000000' } };
          row.getCell(c).border = _bdr();
          row.getCell(c).alignment = { wrapText: true, vertical: 'middle' };
        }

        // Result badge — bold red
        const resultCell = row.getCell(4);
        resultCell.value = chk.result;
        resultCell.font  = { bold: true, color: { argb: C.white }, size: 11 };
        resultCell.fill  = _fill(C.no);
        resultCell.alignment = { horizontal: 'center', vertical: 'middle' };

        // File — blue underline style
        row.getCell(5).font = { size: 10, color: { argb: 'FF2E5DA6' }, underline: true };

        // Line No — centered
        row.getCell(6).alignment = { horizontal: 'center', vertical: 'middle' };

        // Issue — bold dark red
        row.getCell(7).font = { size: 10, bold: true, color: { argb: C.no } };

        // Snippet — monospace grey
        row.getCell(8).font = { size: 9, name: 'Courier New', color: { argb: 'FF555555' } };

        row.height = 22;
        rowIdx++;
        hasViolations = true;
      }

      rowIdx++; // blank gap between checks
    }
  }

  // Manual checks section
  rowIdx++;
  ws.mergeCells(`A${rowIdx}:H${rowIdx}`);
  const manHdr = ws.getCell(`A${rowIdx}`);
  manHdr.value = '⚠  Manual Checks — These require human verification (marked N/A in audit sheet)';
  manHdr.font  = { bold: true, size: 11, color: { argb: C.white } };
  manHdr.fill  = _fill('FFBF8F00');
  manHdr.alignment = { vertical: 'middle' };
  ws.getRow(rowIdx).height = 24;
  rowIdx++;

  for (const cat of d.categories) {
    for (const chk of cat.checks) {
      if (chk.result !== 'Manual') continue;
      const row = ws.getRow(rowIdx);
      ws.mergeCells(`C${rowIdx}:H${rowIdx}`);
      row.getCell(1).value = cat.name;
      row.getCell(2).value = chk.id;
      row.getCell(3).value = chk.evidence;
      for (let c = 1; c <= 8; c++) {
        row.getCell(c).fill   = _fill('FFFFFDE7');
        row.getCell(c).border = _bdr();
        row.getCell(c).alignment = { wrapText: true, vertical: 'middle' };
        row.getCell(c).font   = { size: 10 };
      }
      row.getCell(2).font = { bold: true, size: 10 };
      row.height = 22;
      rowIdx++;
    }
  }

  // All-clear message if no violations
  if (!hasViolations) {
    ws.mergeCells(`A2:H2`);
    const okCell = ws.getCell('A2');
    okCell.value = '✔  No automated violations detected. Review the Manual checks section below.';
    okCell.font  = { bold: true, color: { argb: C.yes }, size: 12 };
    okCell.alignment = { horizontal: 'center', vertical: 'middle' };
    ws.getRow(2).height = 28;
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function _fill(argb) { return { type: 'pattern', pattern: 'solid', fgColor: { argb } }; }
function _bdr()      { const s = { style: 'thin', color: { argb: 'FFCCCCCC' } }; return { top:s, left:s, bottom:s, right:s }; }

module.exports = { generateReport };

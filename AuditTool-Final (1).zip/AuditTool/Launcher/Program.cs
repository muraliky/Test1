using CATSAuditLauncher;

// Enable high-DPI awareness for crisp rendering on modern monitors
Application.SetHighDpiMode(HighDpiMode.SystemAware);
Application.EnableVisualStyles();
Application.SetCompatibleTextRenderingDefault(false);
Application.Run(new AuditForm());

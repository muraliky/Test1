namespace CATSAuditLauncher;

/// <summary>
/// LOB → SubLOB mapping extracted from team data.
/// Organised as: LOB → list of SubLOBs
/// </summary>
public static class LobData
{
    /// <summary>
    /// Returns the full LOB → SubLOB dictionary.
    /// Keys are LOB names; values are ordered SubLOB lists.
    /// </summary>
    public static readonly Dictionary<string, List<string>> Mapping = new()
    {
        {
            "WIM", new List<string>
            {
                "PMP",
                "Account Management",
                "Money Movement",
                "Forms Enablement",
                "Agent Desktop",
                "Digital",
                "CRM",
                "Advisor Gateway",
            }
        },
        {
            "CSBB", new List<string>
            {
                "FCM",
                "FHEP",
                "CRV",
                "Product Model",
                "ECI",
                "DBA",
                "CCaaS",
            }
        },
        {
            "Credit Solutions", new List<string>
            {
                "GRT",
                "Asset Based Lending",
                "CSCA",
                "Equipment Finance",
            }
        },
        {
            "IPO LIQ", new List<string>
            {
                "GBF EUV PFIX",
                "LIQ EUV",
                "AQUA UAT",
            }
        },
        {
            "Payments", new List<string>
            {
                "PCC",
                "Message Gateway",
                "SAA",
                "FIG - J Systems",
                "EPCL",
                "EPT",
                "EPE",
                "STH",
                "SBS",
                "Pega",
                "Fircosoft",
                "EMTS",
                "GMTS",
                "IntelliTracs",
                "SNG",
                "SMH",
            }
        },
    };

    /// <summary>Returns all LOB names in display order.</summary>
    public static IEnumerable<string> Lobs => Mapping.Keys;

    /// <summary>Returns SubLOBs for the given LOB, or empty list if not found.</summary>
    public static List<string> SubLobsFor(string lob) =>
        Mapping.TryGetValue(lob, out var subs) ? subs : new List<string>();
}

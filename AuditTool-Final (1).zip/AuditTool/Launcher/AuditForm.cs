using System.Diagnostics;
using System.Text;

namespace CATSAuditLauncher;

public class AuditForm : Form
{
    // Controls
    private TextBox     _txtRepo    = null!;
    private Button      _btnBrowse  = null!;
    private ComboBox    _cmbLob     = null!;
    private ComboBox    _cmbSubLob  = null!;
    private TextBox     _txtProject = null!;
    private RichTextBox _rtbLog     = null!;
    private Button      _btnRun     = null!;
    private Button      _btnClear   = null!;
    private ProgressBar _progress   = null!;
    private Label       _lblStatus  = null!;
    private Label       _lblBranch  = null!;

    // State
    private Process? _proc;
    private bool     _running;
    private bool     _branchWarningShown;

    // Colours
    static readonly Color PRIMARY     = Color.FromArgb(25,  118, 210);
    static readonly Color PRIMARY_HOV = Color.FromArgb(21,  101, 192);
    static readonly Color DANGER      = Color.FromArgb(211,  47,  47);
    static readonly Color HEADER_BG   = Color.FromArgb(25,   50, 100);
    static readonly Color FORM_BG     = Color.FromArgb(245, 247, 250);
    static readonly Color CARD_BG     = Color.White;
    static readonly Color BORDER_CLR  = Color.FromArgb(207, 216, 230);
    static readonly Color LBL_CLR     = Color.FromArgb(55,  71,  79);
    static readonly Color TXT_CLR     = Color.FromArgb(33,  33,  33);
    static readonly Color DIM_CLR     = Color.FromArgb(144, 164, 174);

    static readonly Color LOG_BG      = Color.FromArgb(18,  26,  46);
    static readonly Color LOG_OK      = Color.FromArgb(56,  193, 114);
    static readonly Color LOG_ERR     = Color.FromArgb(239, 108, 108);
    static readonly Color LOG_WARN    = Color.FromArgb(255, 193,   7);
    static readonly Color LOG_INFO    = Color.FromArgb(220, 228, 240);
    static readonly Color LOG_DIM     = Color.FromArgb(100, 120, 150);
    static readonly Color LOG_CMD     = Color.FromArgb(144, 202, 249);

    public AuditForm()
    {
        InitForm();
        PopulateLobs();
        Log("Ready. Fill in the fields above and click  Run Audit.", LOG_DIM);
    }

    // =========================================================================
    //  Form initialisation
    // =========================================================================
    void InitForm()
    {
        SuspendLayout();

        Text            = "Automation Audit Tool";
        ClientSize      = new Size(820, 680);
        MinimumSize     = new Size(700, 560);
        StartPosition   = FormStartPosition.CenterScreen;
        BackColor       = FORM_BG;
        Font            = new Font("Segoe UI", 9.5f);
        FormBorderStyle = FormBorderStyle.Sizable;

        // ── 1. Header ─────────────────────────────────────────────────────────
        var header = new Panel
        {
            Dock      = DockStyle.Top,
            Height    = 52,
            BackColor = HEADER_BG,
        };
        header.Controls.Add(new Label
        {
            Text      = "Automation Audit Tool",
            Font      = new Font("Segoe UI", 15f, FontStyle.Bold),
            ForeColor = Color.White,
            AutoSize  = true,
            Location  = new Point(18, 12),
        });
        header.Controls.Add(new Panel          // accent stripe
        {
            Dock      = DockStyle.Bottom,
            Height    = 3,
            BackColor = PRIMARY,
        });

        // ── 2. Footer (action bar) ────────────────────────────────────────────
        var footer = new Panel
        {
            Dock      = DockStyle.Bottom,
            Height    = 52,
            BackColor = CARD_BG,
            Padding   = new Padding(14, 0, 14, 0),
        };
        footer.Controls.Add(new Panel          // top separator
        {
            Dock      = DockStyle.Top,
            Height    = 1,
            BackColor = BORDER_CLR,
        });

        _btnRun = FlatBtn("Run Audit", PRIMARY, Color.White, bold: true);
        _btnRun.Size     = new Size(120, 32);
        _btnRun.Location = new Point(14, 10);
        _btnRun.Click      += BtnRun_Click;
        _btnRun.MouseEnter += (_, _) => { if (!_running) _btnRun.BackColor = PRIMARY_HOV; };
        _btnRun.MouseLeave += (_, _) => { if (!_running) _btnRun.BackColor = PRIMARY; };

        _btnClear = FlatBtn("Clear", CARD_BG, LBL_CLR, bold: false);
        _btnClear.FlatAppearance.BorderColor = BORDER_CLR;
        _btnClear.FlatAppearance.BorderSize  = 1;
        _btnClear.Size     = new Size(72, 32);
        _btnClear.Location = new Point(142, 10);
        _btnClear.Click   += (_, _) => { _rtbLog.Clear(); Log("Log cleared.", LOG_DIM); };

        _progress = new ProgressBar
        {
            Style                 = ProgressBarStyle.Marquee,
            MarqueeAnimationSpeed = 28,
            Size                  = new Size(180, 18),
            Location              = new Point(226, 17),
            Visible               = false,
        };

        _lblStatus = new Label
        {
            Text      = "Ready",
            ForeColor = DIM_CLR,
            Font      = new Font("Segoe UI", 8.5f, FontStyle.Italic),
            AutoSize  = true,
            Location  = new Point(418, 20),
        };

        footer.Controls.AddRange(new Control[] { _btnRun, _btnClear, _progress, _lblStatus });

        // ── 3. Input card ─────────────────────────────────────────────────────
        //  Uses TableLayoutPanel so nothing overlaps regardless of font/DPI.
        var card = new Panel
        {
            Dock      = DockStyle.Top,
            Height    = 200,
            BackColor = CARD_BG,
            Padding   = new Padding(18, 12, 18, 12),
        };
        card.Controls.Add(new Panel            // bottom border
        {
            Dock      = DockStyle.Bottom,
            Height    = 1,
            BackColor = BORDER_CLR,
        });

        // Section heading
        card.Controls.Add(new Label
        {
            Text      = "Audit Configuration",
            Font      = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            ForeColor = HEADER_BG,
            AutoSize  = true,
            Location  = new Point(18, 12),
        });

        // TableLayoutPanel — 2 columns: label col (auto) + field col (fill)
        var tbl = new TableLayoutPanel
        {
            Location     = new Point(18, 36),
            AutoSize     = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount  = 4,
            RowCount     = 2,
            CellBorderStyle = TableLayoutPanelCellBorderStyle.None,
            Anchor       = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
        };

        // Column styles
        // Row 0:  [label:Repo Path] [textbox+browse spanning 3 cols]
        // Row 1:  [label:LOB][combo] [label:SubLOB][combo] — but we use a nested panel
        tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 0));
        tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 0));
        tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 0));

        // ── Row 0: Repository Path ────────────────────────────────────────────
        var lblRepo = FieldLabel("Repository Path");
        tbl.Controls.Add(lblRepo, 0, 0);
        tbl.SetColumnSpan(lblRepo, 4);

        // Repo row: textbox + browse button side by side in a panel
        var repoRow = new Panel { Height = 30, Dock = DockStyle.Fill };

        _txtRepo = new TextBox
        {
            Dock        = DockStyle.Fill,
            Font        = new Font("Segoe UI", 9.5f),
            BorderStyle = BorderStyle.FixedSingle,
            BackColor   = Color.White,
            ForeColor   = TXT_CLR,
        };

        _btnBrowse = FlatBtn("Browse", CARD_BG, LBL_CLR, bold: false);
        _btnBrowse.FlatAppearance.BorderColor = BORDER_CLR;
        _btnBrowse.FlatAppearance.BorderSize  = 1;
        _btnBrowse.Dock   = DockStyle.Right;
        _btnBrowse.Width  = 78;
        _btnBrowse.Cursor = Cursors.Hand;
        _btnBrowse.Click += BtnBrowse_Click;

        repoRow.Controls.Add(_txtRepo);        // Fill — added last so DockStyle.Fill works
        repoRow.Controls.Add(_btnBrowse);      // Right — added first

        var repoCell = new Panel { Height = 54, Dock = DockStyle.Fill };
        repoCell.Controls.Add(repoRow);        // fills repoCell
        tbl.Controls.Add(repoCell, 0, 1);
        tbl.SetColumnSpan(repoCell, 4);

        // ── Row 2: LOB | Sub LOB | Project ───────────────────────────────────
        // Use a single FlowLayoutPanel for the three combos/boxes in a row
        var row2 = new FlowLayoutPanel
        {
            Height    = 64,
            Dock      = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents  = false,
            AutoSize  = false,
            Padding   = new Padding(0, 4, 0, 0),
        };

        // LOB
        var pLob = FieldGroup("LOB", out _cmbLob, isCombo: true, width: 160);
        _cmbLob.DropDownStyle = ComboBoxStyle.DropDownList;
        _cmbLob.SelectedIndexChanged += CmbLob_Changed;
        row2.Controls.Add(pLob);

        // Spacer
        row2.Controls.Add(new Panel { Width = 14, Height = 1 });

        // Sub LOB
        var pSub = FieldGroup("Sub LOB", out _cmbSubLob, isCombo: true, width: 190);
        _cmbSubLob.DropDownStyle = ComboBoxStyle.DropDownList;
        _cmbSubLob.Enabled       = false;
        row2.Controls.Add(pSub);

        // Spacer
        row2.Controls.Add(new Panel { Width = 14, Height = 1 });

        // Project
        var pProj = FieldGroup("Project / Repo Name", out _txtProject, isCombo: false, width: 220);
        row2.Controls.Add(pProj);

        tbl.Controls.Add(row2, 0, 2);
        tbl.SetColumnSpan(row2, 4);

        // Branch warning label
        _lblBranch = new Label
        {
            AutoSize  = true,
            Visible   = false,
            Font      = new Font("Segoe UI", 8.5f, FontStyle.Italic),
            ForeColor = Color.FromArgb(183, 100, 0),
            BackColor = Color.FromArgb(255, 248, 225),
            Padding   = new Padding(4, 2, 4, 2),
        };
        tbl.Controls.Add(_lblBranch, 0, 3);
        tbl.SetColumnSpan(_lblBranch, 4);

        card.Controls.Add(tbl);

        // ── 4. Log area ───────────────────────────────────────────────────────
        var logArea = new Panel { Dock = DockStyle.Fill };

        var logHeader = new Panel
        {
            Dock      = DockStyle.Top,
            Height    = 30,
            BackColor = Color.FromArgb(30, 42, 70),
        };
        logHeader.Controls.Add(new Label
        {
            Text      = "Output",
            Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
            ForeColor = Color.FromArgb(144, 164, 194),
            AutoSize  = true,
            Location  = new Point(12, 7),
        });

        _rtbLog = new RichTextBox
        {
            Dock        = DockStyle.Fill,
            BackColor   = LOG_BG,
            ForeColor   = LOG_INFO,
            Font        = new Font("Consolas", 9.5f),
            ReadOnly    = true,
            ScrollBars  = RichTextBoxScrollBars.Vertical,
            BorderStyle = BorderStyle.None,
            WordWrap    = false,
        };

        logArea.Controls.Add(_rtbLog);
        logArea.Controls.Add(logHeader);

        // ── Assemble ──────────────────────────────────────────────────────────
        Controls.Add(logArea);
        Controls.Add(card);
        Controls.Add(footer);
        Controls.Add(header);

        ResumeLayout(true);
    }

    // =========================================================================
    //  Field group helper — returns a panel containing a label + field
    // =========================================================================
    // Overload for ComboBox
    static Panel FieldGroup(string label, out ComboBox combo, bool isCombo, int width)
    {
        var outer = new Panel { Width = width, Height = 56, BackColor = Color.Transparent };
        outer.Controls.Add(new Label
        {
            Text      = label,
            Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
            ForeColor = LBL_CLR,
            AutoSize  = true,
            Location  = new Point(0, 0),
        });
        combo = new ComboBox
        {
            Font      = new Font("Segoe UI", 9.5f),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.White,
            Location  = new Point(0, 20),
            Width     = width,
            Height    = 28,
        };
        outer.Controls.Add(combo);
        return outer;
    }

    // Overload for TextBox
    static Panel FieldGroup(string label, out TextBox txt, bool isCombo, int width)
    {
        var outer = new Panel { Width = width, Height = 56, BackColor = Color.Transparent };
        outer.Controls.Add(new Label
        {
            Text      = label,
            Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
            ForeColor = LBL_CLR,
            AutoSize  = true,
            Location  = new Point(0, 0),
        });
        txt = new TextBox
        {
            Font        = new Font("Segoe UI", 9.5f),
            BorderStyle = BorderStyle.FixedSingle,
            BackColor   = Color.White,
            ForeColor   = TXT_CLR,
            Location    = new Point(0, 20),
            Width       = width,
            Height      = 28,
        };
        outer.Controls.Add(txt);
        return outer;
    }

    // =========================================================================
    //  LOB population
    // =========================================================================
    void PopulateLobs()
    {
        _cmbLob.Items.Add("-- Select LOB --");
        foreach (var name in LobData.Lobs)
            _cmbLob.Items.Add(name);
        _cmbLob.SelectedIndex = 0;
    }

    void CmbLob_Changed(object? sender, EventArgs e)
    {
        _cmbSubLob.Items.Clear();
        _cmbSubLob.Enabled = false;
        if (_cmbLob.SelectedIndex <= 0) return;

        var subs = LobData.SubLobsFor(_cmbLob.SelectedItem!.ToString()!);
        if (subs.Count == 0) return;

        _cmbSubLob.Items.Add("-- Select Sub LOB --");
        foreach (var sub in subs)
            _cmbSubLob.Items.Add(sub);
        _cmbSubLob.SelectedIndex = 0;
        _cmbSubLob.Enabled       = true;
    }

    // =========================================================================
    //  Browse
    // =========================================================================
    void BtnBrowse_Click(object? sender, EventArgs e)
    {
        string initDir = Directory.Exists(_txtRepo.Text.Trim())
            ? _txtRepo.Text.Trim()
            : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

        string? picked = null;

        // FolderBrowserDialog — correct primary approach for folder selection.
        // UseDescriptionForTitle=true gives the modern Vista-style resizable dialog.
        try
        {
            using var dlg = new FolderBrowserDialog
            {
                Description            = "Select the repository root folder (where .git is)",
                UseDescriptionForTitle = true,
                ShowNewFolderButton    = false,
                InitialDirectory       = initDir,
            };

            if (dlg.ShowDialog(this) == DialogResult.OK)
                picked = dlg.SelectedPath;
        }
        catch
        {
            // Fallback: if FolderBrowserDialog fails (e.g. on some Terminal Server
            // setups), use OpenFileDialog pointed at a dummy filter.
            // User navigates into the repo folder and clicks Open — we then
            // extract the directory from the returned path.
            try
            {
                using var dlg = new OpenFileDialog
                {
                    Title            = "Navigate into your repo folder then click Open",
                    CheckFileExists  = false,
                    CheckPathExists  = false,
                    ValidateNames    = false,
                    FileName         = ".",
                    Filter           = "All files (*.*)|*.*",
                    InitialDirectory = initDir,
                };
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    // FileName will be something like  C:\repos\AOM-1NA1\.
                    // GetDirectoryName strips the last segment to give us the folder.
                    var raw = dlg.FileName;
                    picked = File.Exists(raw)
                        ? Path.GetDirectoryName(raw)   // user picked a file — use its folder
                        : Directory.Exists(raw)
                            ? raw                       // user typed a folder path directly
                            : Path.GetDirectoryName(raw); // normal case
                }
            }
            catch { /* give up silently */ }
        }

        if (string.IsNullOrWhiteSpace(picked)) return;

        // Normalise trailing separator
        picked = picked.TrimEnd(Path.DirectorySeparatorChar,
                                Path.AltDirectorySeparatorChar);

        _txtRepo.Text = picked;

        // Auto-fill project name from folder name if the field is empty
        if (string.IsNullOrWhiteSpace(_txtProject.Text))
            _txtProject.Text = Path.GetFileName(picked);
    }

    // =========================================================================
    //  Validation
    // =========================================================================
    bool CheckInputs(out string repo, out string project, out string lob, out string subLob)
    {
        repo    = _txtRepo.Text.Trim();
        project = _txtProject.Text.Trim();
        lob     = _cmbLob.SelectedIndex > 0 ? (_cmbLob.SelectedItem?.ToString() ?? "") : "";
        subLob  = _cmbSubLob.SelectedIndex > 0 ? (_cmbSubLob.SelectedItem?.ToString() ?? "") : "";

        var errs = new List<string>();

        if (string.IsNullOrWhiteSpace(repo))
            errs.Add("Repository path is required.");
        else if (!Directory.Exists(repo))
            errs.Add("Repository path does not exist:\n" + repo);
        else if (!Directory.Exists(Path.Combine(repo, ".git")))
            errs.Add("The selected folder is not a git repository (.git folder not found).");

        if (lob.Length == 0 || lob.StartsWith("--"))
            errs.Add("Please select a LOB.");
        if (_cmbSubLob.Enabled && (subLob.Length == 0 || subLob.StartsWith("--")))
            errs.Add("Please select a Sub LOB.");
        if (string.IsNullOrWhiteSpace(project))
            errs.Add("Project / Repo Name is required.");

        if (errs.Count == 0) return true;

        using var dlg = new MsgBox("Validation Error", string.Join("\n\n", errs), MsgKind.Warn);
        dlg.ShowDialog(this);
        return false;
    }

    // =========================================================================
    //  Run / Stop
    // =========================================================================
    void BtnRun_Click(object? sender, EventArgs e)
    {
        if (_running)
        {
            try { _proc?.Kill(entireProcessTree: true); } catch { /* ignore */ }
            SetBusy(false);
            Log("Audit cancelled.", LOG_WARN);
            return;
        }

        if (!CheckInputs(out var repo, out var project, out var lob, out var subLob))
            return;

        var node = FindNode();
        if (node == null)
        {
            using var d = new MsgBox("Node.js Not Found",
                "node.exe was not found.\n\nInstall Node.js v16+ and ensure it is on your PATH.",
                MsgKind.Err);
            d.ShowDialog(this); return;
        }

        var js = FindAuditJs();
        if (js == null)
        {
            using var d = new MsgBox("Engine Not Found",
                "audit.js was not found.\n\nEnsure the automation-audit folder is next to this exe.",
                MsgKind.Err);
            d.ShowDialog(this); return;
        }

        _rtbLog.Clear();
        _branchWarningShown = false;
        _lblBranch.Visible  = false;

        var lobArg = (subLob.Length > 0 && !subLob.StartsWith("--"))
            ? $"{lob} / {subLob}" : lob;

        Log($"Project  : {project}", LOG_INFO);
        Log($"Repo     : {repo}",    LOG_INFO);
        Log($"LOB      : {lobArg}",  LOG_INFO);
        Log("",                      LOG_DIM);

        SetBusy(true);

        _proc = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName               = node,
                Arguments              = $"\"{js}\" -r \"{repo}\" -p \"{project}\" -l \"{lobArg}\" --no-branch-check",
                WorkingDirectory       = Path.GetDirectoryName(js)!,
                UseShellExecute        = false,
                RedirectStandardOutput = true,
                RedirectStandardError  = true,
                CreateNoWindow         = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding  = Encoding.UTF8,
            },
            EnableRaisingEvents = true,
        };
        _proc.OutputDataReceived += OnOut;
        _proc.ErrorDataReceived  += OnErr;
        _proc.Exited             += (_, _) => Invoke(OnDone);

        try
        {
            _proc.Start();
            _proc.BeginOutputReadLine();
            _proc.BeginErrorReadLine();
        }
        catch (Exception ex) { SetBusy(false); Log("Failed to start: " + ex.Message, LOG_ERR); }
    }

    void OnOut(object p, DataReceivedEventArgs a)
    {
        if (a.Data == null) return;
        var line = a.Data;
        Invoke(() =>
        {
            if (!_branchWarningShown && line.Contains("NOT ON DEFAULT BRANCH"))
            {
                _branchWarningShown = true;
                ShowBranchDialog();
            }
            else if (line.Contains("Current branch") && line.Contains("Default branch"))
            {
                var cur = Slice(line, "Current branch: '", "'");
                var def = Slice(line, "Default branch: '", "'");
                if (!string.IsNullOrEmpty(cur) && cur != def)
                {
                    _lblBranch.Text    = $"  ⚠  On '{cur}' — default is '{def}'  ";
                    _lblBranch.Visible = true;
                }
            }
            Log(line, LogColor(line));
        });
    }

    void OnErr(object p, DataReceivedEventArgs a)
    {
        if (a.Data == null) return;
        var line = a.Data;
        Invoke(() => Log(line, LOG_ERR));
    }

    void OnDone()
    {
        var code = _proc?.ExitCode ?? -1;
        Log("", LOG_DIM);
        if (code == 0) { Log("Audit complete — report saved to shared drive.", LOG_OK, bold: true); Status("Complete", LOG_OK); }
        else            { Log($"Audit failed (exit {code}).", LOG_ERR); Status($"Failed ({code})", LOG_ERR); }
        SetBusy(false);
        _proc?.Dispose();
        _proc = null;
    }

    // =========================================================================
    //  Branch warning popup
    // =========================================================================
    void ShowBranchDialog()
    {
        var cur = _lblBranch.Visible ? Slice(_lblBranch.Text, "On '",       "'") : "";
        var def = _lblBranch.Visible ? Slice(_lblBranch.Text, "default is '","'") : "main";
        using var d = new BranchDlg(cur, def);
        if (d.ShowDialog(this) == DialogResult.Cancel)
        {
            try { _proc?.Kill(entireProcessTree: true); } catch { /* ignore */ }
            Log("Audit aborted. Switch to the default branch and re-run.", LOG_ERR);
            SetBusy(false);
        }
        else Log($"Proceeding on non-default branch '{cur}' — noted in GIT0.", LOG_WARN);
    }

    // =========================================================================
    //  Logging helpers
    // =========================================================================
    void Log(string text, Color? clr = null, bool bold = false)
    {
        if (InvokeRequired) { Invoke(() => Log(text, clr, bold)); return; }
        clr ??= LOG_INFO;
        _rtbLog.SelectionStart  = _rtbLog.TextLength;
        _rtbLog.SelectionLength = 0;
        _rtbLog.SelectionColor  = clr.Value;
        _rtbLog.SelectionFont   = bold ? new Font(_rtbLog.Font, FontStyle.Bold) : _rtbLog.Font;
        _rtbLog.AppendText(text + "\n");
        _rtbLog.ScrollToCaret();
    }

    Color LogColor(string s)
    {
        if (string.IsNullOrWhiteSpace(s))                                                             return LOG_INFO;
        if (s.Contains("✅")||s.Contains("✔")||s.Contains("complete")||s.Contains("done"))           return LOG_OK;
        if (s.Contains("✖")||s.Contains("error")||s.Contains("Error")||s.Contains("failed"))        return LOG_ERR;
        if (s.Contains("⚠")||s.Contains("~")||s.Contains("Manual")||s.Contains("WARNING"))          return LOG_WARN;
        if (s.TrimStart().StartsWith("─")||s.TrimStart().StartsWith("═")||
            s.TrimStart().StartsWith("╔")||s.TrimStart().StartsWith("║")||
            s.TrimStart().StartsWith("╚"))                                                            return LOG_DIM;
        if (s.TrimStart().StartsWith("📁")||s.TrimStart().StartsWith("📋")||
            s.TrimStart().StartsWith("📂")||s.TrimStart().StartsWith("📊")||
            s.TrimStart().StartsWith("🔍")||s.TrimStart().StartsWith("🔎")||
            s.TrimStart().StartsWith("📐")||s.TrimStart().StartsWith("🏗")||
            s.TrimStart().StartsWith("⚙") ||s.TrimStart().StartsWith("🌿"))                          return LOG_CMD;
        return LOG_INFO;
    }

    void Status(string text, Color clr)
    {
        if (InvokeRequired) { Invoke(() => Status(text, clr)); return; }
        _lblStatus.Text = text; _lblStatus.ForeColor = clr;
    }

    // =========================================================================
    //  Busy state
    // =========================================================================
    void SetBusy(bool busy)
    {
        if (InvokeRequired) { Invoke(() => SetBusy(busy)); return; }
        _running            = busy;
        _btnRun.Text        = busy ? "Stop" : "Run Audit";
        _btnRun.BackColor   = busy ? DANGER : PRIMARY;
        _progress.Visible   = busy;
        _btnBrowse.Enabled  = !busy;
        _cmbLob.Enabled     = !busy;
        _cmbSubLob.Enabled  = !busy && _cmbLob.SelectedIndex > 0;
        _txtRepo.Enabled    = !busy;
        _txtProject.Enabled = !busy;
        if (busy) Status("Running…", LOG_WARN);
    }

    // =========================================================================
    //  Find node.exe and audit.js
    // =========================================================================
    static string? FindNode()
    {
        foreach (var segment in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
        {
            if (string.IsNullOrWhiteSpace(segment)) continue;
            var c = Path.Combine(segment.Trim(), "node.exe");
            if (File.Exists(c)) return c;
        }
        string[] fallback =
        [
            @"C:\Program Files\nodejs\node.exe",
            @"C:\Program Files (x86)\nodejs\node.exe",
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                         @"nvm\current\node.exe"),
        ];
        return fallback.FirstOrDefault(File.Exists);
    }

    static string? FindAuditJs()
    {
        var dir = AppContext.BaseDirectory;
        string[] tries =
        [
            Path.Combine(dir, "automation-audit", "audit.js"),
            Path.Combine(dir, "..", "automation-audit", "audit.js"),
            Path.Combine(dir, "audit.js"),
        ];
        return tries.Select(Path.GetFullPath).FirstOrDefault(File.Exists);
    }

    // =========================================================================
    //  Utility
    // =========================================================================
    static Label FieldLabel(string text) => new()
    {
        Text      = text,
        Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
        ForeColor = LBL_CLR,
        AutoSize  = true,
        Margin    = new Padding(0, 0, 0, 4),
    };

    static Button FlatBtn(string text, Color bg, Color fg, bool bold) => new()
    {
        Text      = text,
        BackColor = bg,
        ForeColor = fg,
        FlatStyle = FlatStyle.Flat,
        Cursor    = Cursors.Hand,
        Font      = bold ? new Font("Segoe UI", 9.5f, FontStyle.Bold)
                         : new Font("Segoe UI", 9.5f),
        FlatAppearance = { BorderSize = 0 },
    };

    static string Slice(string src, string open, string close)
    {
        int i = src.IndexOf(open, StringComparison.Ordinal);
        if (i < 0) return "";
        i += open.Length;
        int j = src.IndexOf(close, i, StringComparison.Ordinal);
        return j < 0 ? "" : src[i..j];
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (_running)
        {
            using var d = new MsgBox("Confirm Exit",
                "An audit is still running. Stop it and exit?", MsgKind.Warn, cancel: true);
            if (d.ShowDialog(this) != DialogResult.OK) { e.Cancel = true; return; }
            try { _proc?.Kill(entireProcessTree: true); } catch { /* ignore */ }
        }
        base.OnFormClosing(e);
    }
}

// =============================================================================
//  Branch Warning Dialog
// =============================================================================
public class BranchDlg : Form
{
    static readonly Color D_NAVY  = Color.FromArgb(25,  50, 100);
    static readonly Color D_RED   = Color.FromArgb(211, 47,  47);
    static readonly Color D_AMBER = Color.FromArgb(245, 158, 11);
    static readonly Color D_BG    = Color.FromArgb(255, 251, 235);

    public BranchDlg(string current, string def)
    {
        Text = "Branch Warning"; Size = new Size(440, 240);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition   = FormStartPosition.CenterParent;
        MaximizeBox = false; MinimizeBox = false;
        BackColor = D_BG; Font = new Font("Segoe UI", 9.5f);

        Controls.Add(new Panel { Dock = DockStyle.Left, Width = 5, BackColor = D_AMBER });

        Controls.Add(new Label { Text = "⚠", Font = new Font("Segoe UI", 26f), ForeColor = D_AMBER, AutoSize = true, Location = new Point(20, 16) });
        Controls.Add(new Label { Text = "Not on Default Branch", Font = new Font("Segoe UI", 11f, FontStyle.Bold), ForeColor = D_NAVY, AutoSize = true, Location = new Point(66, 16) });
        Controls.Add(new Label
        {
            Text =
                $"Current  :  {(string.IsNullOrEmpty(current) ? "(unknown)" : current)}\n" +
                $"Default  :  {def}\n\n" +
                "Results may not reflect the production codebase.\n" +
                "This is recorded as GIT0 in the audit report.",
            Font = new Font("Segoe UI", 9.5f), ForeColor = Color.FromArgb(120, 70, 0),
            AutoSize = false, Size = new Size(352, 80), Location = new Point(66, 46),
        });
        Controls.Add(new Label
        {
            Text = "git checkout " + def, Font = new Font("Consolas", 8.5f),
            ForeColor = Color.Gray, AutoSize = true, Location = new Point(66, 134),
        });

        var btnOk = BtnD("Continue Anyway", D_NAVY, new Point(66, 162), DialogResult.OK);
        var btnNo = BtnD("Abort",            D_RED,  new Point(220, 162), DialogResult.Cancel);
        Controls.Add(btnOk); Controls.Add(btnNo);
        AcceptButton = btnOk; CancelButton = btnNo;
    }

    static Button BtnD(string t, Color bg, Point loc, DialogResult dr) => new()
    {
        Text = t, Size = new Size(130, 30), Location = loc, DialogResult = dr,
        BackColor = bg, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
        Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), Cursor = Cursors.Hand,
        FlatAppearance = { BorderSize = 0 },
    };
}

// =============================================================================
//  Generic Message Box
// =============================================================================
public enum MsgKind { Info, Warn, Err }

public class MsgBox : Form
{
    public MsgBox(string title, string msg, MsgKind kind, bool cancel = false)
    {
        var (ac, ic, fc) = kind switch
        {
            MsgKind.Err  => (Color.FromArgb(211, 47,  47),  "✕", Color.FromArgb(211, 47, 47)),
            MsgKind.Warn => (Color.FromArgb(245, 158, 11),  "⚠", Color.FromArgb(146, 64, 14)),
            _            => (Color.FromArgb(25,  118, 210), "i", Color.FromArgb(25, 118, 210)),
        };

        Text = title; Size = new Size(400, 196);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition   = FormStartPosition.CenterParent;
        MaximizeBox = false; MinimizeBox = false;
        BackColor = Color.White; Font = new Font("Segoe UI", 9.5f);

        Controls.Add(new Panel { Dock = DockStyle.Top, Height = 3, BackColor = ac });
        Controls.Add(new Label { Text = ic, Font = new Font("Segoe UI", 16f, FontStyle.Bold), ForeColor = fc, AutoSize = true, Location = new Point(14, 18) });
        Controls.Add(new Label { Text = title, Font = new Font("Segoe UI", 10f, FontStyle.Bold), ForeColor = Color.FromArgb(30, 41, 59), AutoSize = true, Location = new Point(46, 16) });
        Controls.Add(new Label
        {
            Text = msg, Font = new Font("Segoe UI", 9.5f),
            ForeColor = Color.FromArgb(71, 85, 105),
            AutoSize = false, Size = new Size(356, 72), Location = new Point(14, 46),
        });

        var ok = new Button
        {
            Text = cancel ? "Yes, Stop" : "OK", Size = new Size(86, 28),
            Location = new Point(cancel ? 194 : 292, 142),
            DialogResult = DialogResult.OK, BackColor = ac, ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Cursor = Cursors.Hand, FlatAppearance = { BorderSize = 0 },
        };
        Controls.Add(ok); AcceptButton = ok;

        if (cancel)
        {
            var no = new Button
            {
                Text = "Cancel", Size = new Size(80, 28), Location = new Point(288, 142),
                DialogResult = DialogResult.Cancel, BackColor = Color.White,
                ForeColor = Color.FromArgb(30, 41, 59), FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f), Cursor = Cursors.Hand,
                FlatAppearance = { BorderColor = Color.FromArgb(207, 216, 230), BorderSize = 1 },
            };
            Controls.Add(no); CancelButton = no;
        }
    }
}

Automation Audit Tool
=====================

ORGANISER SETUP (once per quarter):
  1. Edit automation-audit/config/output.config.js
     Set AUDIT_OUTPUT_PATH to your shared drive UNC path

  2. Install Node.js dependencies (one-time):
     cd automation-audit && npm install

  3. Build the WinForms launcher (.NET 9 SDK required):
     cd Launcher
     dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
     Output: Launcher\bin\Release\net9.0-windows\win-x64\publish\AuditLauncher.exe

  4. Place AuditLauncher.exe next to the automation-audit\ folder and distribute

RUNNING AN AUDIT (project teams):
  Double-click AuditLauncher.exe → fill 4 fields → click Run Audit
  Excel report + _findings.json saved to shared drive automatically
  Node.js must be installed on the user's machine

REFRESHING THE DASHBOARD (organiser, after each audit cycle):
  cd automation-audit
  node build-dashboard.js
  → Reads all *_findings.json from shared drive
  → Writes AuditDashboard.html to the same folder
  → Open in any browser, no server needed

DASHBOARD TABS:
  Overview  — Volume KPIs, Quality KPIs, Technology Adoption rings
  Trends    — Score trend, Maturity distribution, Category pass rates, LOB comparison, Top violations
  Health    — Check-level heatmap, At-risk repos, Most improved leaderboard
  All Audits — Sortable full audit table with trend column

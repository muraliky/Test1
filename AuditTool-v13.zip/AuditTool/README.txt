Automation Audit Tool
=====================
ORGANISER:
  1. Edit automation-audit/config/output.config.js  — set shared drive path
  2. cd automation-audit && npm install

BUILD EXE:
  cd Launcher
  dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
  Output: Launcher\bin\Release\net9.0-windows\win-x64\publish\AuditLauncher.exe

DISTRIBUTE: AuditLauncher.exe  +  automation-audit\  (with node_modules)
USER needs: Node.js installed. Double-click AuditLauncher.exe.

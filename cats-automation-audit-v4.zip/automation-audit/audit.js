#!/usr/bin/env node
'use strict';

const { program } = require('commander');
const chalk  = require('chalk');
const path   = require('path');
const fs     = require('fs');

const { detectRepo }            = require('./analyzers/repoDetector');
const { runCodingStandards }    = require('./analyzers/codingStandards');
const { runFrameworkStandards } = require('./analyzers/wafStandards');
const { runModeOfExecution }    = require('./analyzers/modeOfExecution');
const { runGITMaintenance }     = require('./analyzers/gitMaintenance');
const { generateReport }        = require('./reporters/excelReporter');
const rules                     = require('./config/rules.json');
const { AUDIT_OUTPUT_PATH }     = require('./config/output.config.js');

// ─── CLI ──────────────────────────────────────────────────────────────────────
// Users only need to supply --repo and --project.
// Output path is set by the organiser in config/output.config.js.
program
  .name('audit')
  .description('CATS Team — Quarterly Test Automation Audit Tool')
  .version('3.0.0')
  .requiredOption('-r, --repo <path>',    'Path to local git repository (default branch)')
  .requiredOption('-p, --project <name>', 'Project name (e.g. AOM-1NA1)')
  .option('-l, --lob <name>',             'Line of Business name', 'WIM_AOM')
  .parse(process.argv);

const opts = program.opts();

// ─── Main ─────────────────────────────────────────────────────────────────────
(async () => {
  console.log(chalk.bold.blue('\n╔══════════════════════════════════════════════╗'));
  console.log(chalk.bold.blue('║   CATS Team — Automation Audit Tool v3.0     ║'));
  console.log(chalk.bold.blue('╚══════════════════════════════════════════════╝\n'));

  // ── Validate repo path ────────────────────────────────────────────────────
  const repoPath = path.resolve(opts.repo);
  if (!fs.existsSync(repoPath)) {
    console.error(chalk.red(`✖ Repo path not found: ${repoPath}`));
    console.error(chalk.yellow('  Ensure the repo is cloned locally and the path is correct.'));
    process.exit(1);
  }

  // ── Validate output path (set by organiser in config/output.config.js) ───
  const outDir = AUDIT_OUTPUT_PATH;
  if (!outDir || outDir.trim() === '') {
    console.error(chalk.red('✖ Output path not configured.'));
    console.error(chalk.yellow('  Please set AUDIT_OUTPUT_PATH in config/output.config.js'));
    process.exit(1);
  }
  if (!fs.existsSync(outDir)) {
    console.error(chalk.red(`✖ Output directory not accessible: ${outDir}`));
    console.error(chalk.yellow('  Ensure the shared drive is mapped and you have write access.'));
    console.error(chalk.yellow('  Contact the CATS Team organiser if the path has changed.'));
    process.exit(1);
  }

  console.log(chalk.cyan(`📁 Repo    : ${repoPath}`));
  console.log(chalk.cyan(`📋 Project : ${opts.project}`));
  console.log(chalk.cyan(`📂 Output  : ${outDir}\n`));

  // ── Step 1: Detect repo type ───────────────────────────────────────────────
  process.stdout.write(chalk.yellow('🔍 Detecting repo type... '));
  const repoInfo  = detectRepo(repoPath);
  const typeLabel = rules.repoTypes[repoInfo.type]?.label || repoInfo.type;
  console.log(chalk.bold.green(`${typeLabel} (${repoInfo.buildTool})\n`));

  // ── Step 2: Load correct framework question set ────────────────────────────
  const repoRules    = rules.repoTypes[repoInfo.type] || rules.repoTypes['qaf'];
  const frameworkDef = repoRules.framework;

  // ── Step 3: Run all analyzers ──────────────────────────────────────────────
  process.stdout.write(chalk.yellow('📐 Coding Standards...             '));
  const codingResults    = runCodingStandards(repoInfo);
  console.log(chalk.green('done'));

  process.stdout.write(chalk.yellow(`🏗  ${frameworkDef.name.padEnd(30)} `));
  const frameworkResults = runFrameworkStandards(repoInfo);
  console.log(chalk.green('done'));

  process.stdout.write(chalk.yellow('⚙️  Mode of Execution...             '));
  const moeResults       = runModeOfExecution(repoInfo);
  console.log(chalk.green('done'));

  process.stdout.write(chalk.yellow('🌿 GIT Maintenance...               '));
  const gitResults       = runGITMaintenance(repoInfo);
  console.log(chalk.green('done\n'));

  // ── Step 4: Merge results with rule definitions ────────────────────────────
  const resultMap = { ...codingResults, ...frameworkResults, ...moeResults, ...gitResults };

  const categoryDefs = [
    rules.shared.coding,
    frameworkDef,
    rules.shared.execution,
    rules.shared.git
  ];

  const categories  = [];
  let   totalScore  = 0;
  let   totalChecks = 0;

  for (const catDef of categoryDefs) {
    const checks = catDef.checks.map(chk => ({
      id:         chk.id,
      description:chk.description,
      type:       chk.type,
      hint:       chk.hint || null,
      result:     resultMap[chk.id]?.result     || 'N/A',
      evidence:   resultMap[chk.id]?.evidence   || (chk.hint || 'Pending check'),
      violations: resultMap[chk.id]?.violations || [],
    }));

    const catScore = checks.reduce((sum, c) => sum + (c.result === 'Yes' ? 1 : 0), 0);
    totalScore  += catScore;
    totalChecks += checks.length;
    categories.push({ id: catDef.id, name: catDef.name, checks, catScore });
  }

  const pct           = Math.round((totalScore / totalChecks) * 100);
  const maturityIndex = _calcMaturity(pct);
  const maturityLabel = rules.maturityIndex[maturityIndex]?.label || 'Unknown';

  const auditResult = {
    meta: {
      projectName: opts.project,
      lob:         opts.lob,
      date:        new Date().toLocaleDateString('en-IN'),
      repoType:    repoInfo.type,
      repoLabel:   typeLabel,
      buildTool:   repoInfo.buildTool,
    },
    categories,
    totalScore,
    totalChecks,
    percentage:   pct,
    maturityIndex,
    maturityLabel,
  };

  // ── Step 5: Print summary ──────────────────────────────────────────────────
  _printSummary(auditResult);

  // ── Step 6: Write Excel and JSON to shared drive ───────────────────────────
  const dateStamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const filePath  = path.join(outDir, `Audit_${opts.project}_${dateStamp}.xlsx`);
  const jsonPath  = path.join(outDir, `Audit_${opts.project}_${dateStamp}_findings.json`);

  process.stdout.write(chalk.yellow('📊 Generating Excel report... '));
  await generateReport(auditResult, filePath);
  console.log(chalk.green(`✔ Saved to ${filePath}\n`));

  fs.writeFileSync(jsonPath, JSON.stringify(auditResult, null, 2));
  console.log(chalk.gray(`📄 Findings JSON : ${jsonPath}`));
  console.log(chalk.bold.green('\n✅ Audit complete!\n'));
})();

// ─── Helpers ──────────────────────────────────────────────────────────────────
function _calcMaturity(pct) {
  if (pct >= 100) return 5;
  if (pct >= 75)  return 4;
  if (pct >= 50)  return 3;
  if (pct >= 25)  return 2;
  return 1;
}

function _printSummary(r) {
  const matColors = [chalk.red, chalk.red, chalk.yellow, chalk.yellowBright, chalk.green, chalk.bold.green];
  const matColor  = matColors[r.maturityIndex] || chalk.white;

  console.log(chalk.bold(`─── Audit Summary [${r.meta.repoLabel}] ${'─'.repeat(25)}`));
  for (const cat of r.categories) {
    const catPct = Math.round((cat.catScore / cat.checks.length) * 100);
    const bar    = _bar(catPct);
    console.log(`\n  ${chalk.cyan(cat.name.padEnd(35))} ${bar} ${catPct}% (${cat.catScore}/${cat.checks.length})`);
    for (const c of cat.checks) {
      const icon = c.result === 'Yes' ? chalk.green('✔') : c.result === 'No' ? chalk.red('✖') : chalk.yellow('~');
      const desc = c.description.length > 65 ? c.description.substring(0, 62) + '...' : c.description;
      console.log(`     ${icon} [${c.id.padEnd(5)}] ${desc}`);
      if (c.violations?.length > 0) console.log(chalk.gray(`              └─ ${c.violations.length} issue(s) found`));
    }
  }

  console.log('\n' + chalk.bold('─'.repeat(60)));
  console.log(`  Total Score  : ${chalk.bold(r.totalScore + '/' + r.totalChecks)} (${r.percentage}%)`);
  console.log(`  Maturity     : ${matColor.bold(r.maturityIndex + ' — ' + r.maturityLabel)}`);
  console.log(chalk.bold('─'.repeat(60)) + '\n');
}

function _bar(pct) {
  const filled = Math.round(pct / 10);
  const bar    = '█'.repeat(filled) + '░'.repeat(10 - filled);
  return pct >= 75 ? chalk.green(bar) : pct >= 50 ? chalk.yellow(bar) : chalk.red(bar);
}

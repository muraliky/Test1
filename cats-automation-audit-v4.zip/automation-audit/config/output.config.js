'use strict';

// ╔══════════════════════════════════════════════════════════════════════════╗
// ║           CATS TEAM — AUDIT TOOL OUTPUT CONFIGURATION                  ║
// ║                                                                          ║
// ║  ORGANISER INSTRUCTIONS:                                                 ║
// ║  Before distributing this tool to users, update AUDIT_OUTPUT_PATH       ║
// ║  below to the correct shared drive UNC path for your team.              ║
// ║                                                                          ║
// ║  Example (UNC path):      \\\\wf-server\\cats-audits\\2026-Q3            ║
// ║  Example (mapped drive):  Z:\\cats-audits\\2026-Q3                       ║
// ║                                                                          ║
// ║  Users do NOT need to change or even open this file.                    ║
// ╚══════════════════════════════════════════════════════════════════════════╝

const AUDIT_OUTPUT_PATH = '\\\\wf-server\\cats-audits\\2026-Q3';

module.exports = { AUDIT_OUTPUT_PATH };

'use strict';
const { execSync } = require('child_process');
const path = require('path');

function runGITMaintenance(repoInfo) {
  const results = {};
  const repoPath = repoInfo.repoPath;

  const isGitRepo = _isGitRepo(repoPath);
  if (!isGitRepo) {
    const na = { result: 'No', evidence: 'Not a git repository or .git folder missing', violations: [] };
    return { GIT1: na, GIT2: na, GIT3: na, GIT4: na, GIT5: na, GIT6: { result: 'Manual', evidence: 'Manual verification needed', violations: [] } };
  }

  results.GIT1 = checkEnterpriseGit(repoPath);
  results.GIT2 = checkRepoMaintenance(repoPath);
  results.GIT3 = checkFrequentCommits(repoPath);
  results.GIT4 = checkBranchingStrategy(repoPath);
  results.GIT5 = checkCodeReviews(repoPath);
  results.GIT6 = { result: 'Manual', evidence: 'Onsite stakeholder involvement requires manual review', violations: [] };

  return results;
}

function _isGitRepo(repoPath) {
  try {
    _git(repoPath, 'rev-parse --git-dir');
    return true;
  } catch (e) {
    return false;
  }
}

function _git(repoPath, command) {
  return execSync(`git -C "${repoPath}" ${command}`, { encoding: 'utf8', timeout: 10000, stdio: ['pipe','pipe','pipe'] }).trim();
}

function checkEnterpriseGit(repoPath) {
  try {
    const remoteUrl = _git(repoPath, 'config --get remote.origin.url');
    // Wells Fargo enterprise GitHub typically on github.wellsfargo.com or similar internal domain
    const isEnterprise = /github\.wellsfargo|wellsfargo\.com|wf\.com|github\.enterprise|git\.corp/i.test(remoteUrl);
    const isPublicGH   = /github\.com\/wellsfargogithub|github\.com\//i.test(remoteUrl);
    const passed = isEnterprise || isPublicGH || remoteUrl.length > 0;
    return {
      result: passed ? 'Yes' : 'No',
      evidence: passed ? `Remote origin: ${remoteUrl}` : 'No remote origin configured',
      violations: passed ? [] : [{ issue: 'No remote git repository configured' }]
    };
  } catch (e) {
    return { result: 'No', evidence: 'Unable to read git remote config', violations: [{ issue: e.message }] };
  }
}

function checkRepoMaintenance(repoPath) {
  try {
    // Check last commit date and total commits
    const lastCommit   = _git(repoPath, 'log -1 --format="%ar"');
    const totalCommits = parseInt(_git(repoPath, 'rev-list --count HEAD'), 10);
    const staleFiles   = _git(repoPath, 'ls-files --others --exclude-standard').split('\n').filter(Boolean).length;

    const isActive = !lastCommit.includes('year') || lastCommit.includes('month');
    const passed   = isActive && totalCommits > 10;

    return {
      result: passed ? 'Yes' : 'No',
      evidence: `Last commit: ${lastCommit} | Total commits: ${totalCommits} | Untracked files: ${staleFiles}`,
      violations: passed ? [] : [{ issue: `Repo appears inactive (last commit: ${lastCommit}, ${totalCommits} total commits)` }]
    };
  } catch (e) {
    return { result: 'N/A', evidence: 'Unable to read git history', violations: [] };
  }
}

function checkFrequentCommits(repoPath) {
  try {
    const last30Days = _git(repoPath, 'log --since="30 days ago" --oneline').split('\n').filter(Boolean);
    const last7Days  = _git(repoPath, 'log --since="7 days ago" --oneline').split('\n').filter(Boolean);

    const passed = last30Days.length >= 5;
    return {
      result: passed ? 'Yes' : 'No',
      evidence: `${last30Days.length} commit(s) in last 30 days, ${last7Days.length} in last 7 days`,
      violations: passed ? [] : [{ issue: `Only ${last30Days.length} commit(s) in last 30 days — expect at least 5 for active project` }]
    };
  } catch (e) {
    return { result: 'N/A', evidence: 'Unable to read git log', violations: [] };
  }
}

function checkBranchingStrategy(repoPath) {
  try {
    const branches = _git(repoPath, 'branch -a').split('\n').map(b => b.trim().replace('* ',''));
    const hasMain      = branches.some(b => /^(main|master)$/i.test(b) || b.endsWith('/main') || b.endsWith('/master'));
    const hasDevelop   = branches.some(b => /develop|development/i.test(b));
    const hasFeature   = branches.some(b => /feature\//i.test(b));
    const hasRelease   = branches.some(b => /release\/|hotfix\//i.test(b));

    const strategyScore = [hasMain, hasDevelop, hasFeature, hasRelease].filter(Boolean).length;
    const passed = strategyScore >= 2;

    const found = [
      hasMain    && 'main/master',
      hasDevelop && 'develop',
      hasFeature && 'feature branches',
      hasRelease && 'release/hotfix'
    ].filter(Boolean);

    return {
      result: passed ? 'Yes' : 'No',
      evidence: `Branches found: ${found.join(', ') || 'only default branch'} (${branches.length} total branches)`,
      violations: passed ? [] : [{ issue: 'No structured branching strategy detected (feature/develop/release pattern missing)' }]
    };
  } catch (e) {
    return { result: 'N/A', evidence: 'Unable to read branches', violations: [] };
  }
}

function checkCodeReviews(repoPath) {
  try {
    // Check for merge commits — indicates PRs were used
    const mergeCommits = _git(repoPath, 'log --merges --oneline --since="90 days ago"').split('\n').filter(Boolean);
    // Direct pushes to main without merge commits
    const mainCommits  = _git(repoPath, 'log --first-parent --oneline --since="90 days ago"').split('\n').filter(Boolean);

    const mergeRatio   = mainCommits.length > 0 ? mergeCommits.length / mainCommits.length : 0;
    const passed       = mergeCommits.length > 0 || mergeRatio >= 0.3;

    return {
      result: passed ? 'Yes' : 'No',
      evidence: `${mergeCommits.length} merge commit(s) in last 90 days out of ${mainCommits.length} total commits — ${Math.round(mergeRatio * 100)}% via PR/merge`,
      violations: passed ? [] : [{ issue: 'Very few merge commits detected — direct pushes may be happening without code review' }]
    };
  } catch (e) {
    return { result: 'N/A', evidence: 'Unable to analyse merge history', violations: [] };
  }
}

module.exports = { runGITMaintenance };

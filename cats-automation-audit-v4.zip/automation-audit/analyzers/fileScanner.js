'use strict';
const fs = require('fs');
const path = require('path');

const SKIP_DIRS = new Set(['node_modules', '.git', 'target', 'build', 'dist', '.gradle', '.idea', '__pycache__']);

/**
 * Recursively collect all source files matching extensions
 */
function collectFiles(dir, extensions, maxDepth = 10, depth = 0) {
  const results = [];
  if (depth > maxDepth) return results;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch (e) { return results; }

  for (const e of entries) {
    if (e.name.startsWith('.') || SKIP_DIRS.has(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      results.push(...collectFiles(full, extensions, maxDepth, depth + 1));
    } else {
      const ext = path.extname(e.name).toLowerCase();
      if (extensions.includes(ext)) results.push(full);
    }
  }
  return results;
}

/**
 * Read file safely, return empty string on error
 */
function readFile(filePath) {
  try { return fs.readFileSync(filePath, 'utf8'); }
  catch (e) { return ''; }
}

/**
 * Search pattern in files, return array of { file, line, lineNo, context }
 */
function searchInFiles(files, pattern, contextLines = 0) {
  const hits = [];
  for (const file of files) {
    const content = readFile(file);
    const lines = content.split('\n');
    lines.forEach((line, idx) => {
      if (pattern.test(line)) {
        hits.push({
          file,
          lineNo: idx + 1,
          line: line.trim(),
          relativePath: file
        });
      }
    });
  }
  return hits;
}

/**
 * Count occurrences of pattern across all files
 */
function countMatches(files, pattern) {
  let total = 0;
  for (const file of files) {
    const content = readFile(file);
    const matches = content.match(pattern);
    if (matches) total += matches.length;
  }
  return total;
}

module.exports = { collectFiles, readFile, searchInFiles, countMatches };

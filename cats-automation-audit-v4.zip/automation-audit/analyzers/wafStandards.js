'use strict';
const fs   = require('fs');
const path = require('path');
const { collectFiles, readFile, searchInFiles } = require('./fileScanner');

// ─── Router ──────────────────────────────────────────────────────────────────
function runFrameworkStandards(repoInfo) {
  return repoInfo.type === 'playwright'
    ? runPlaywrightStandards(repoInfo)
    : runQAFStandards(repoInfo);
}

// ═══════════════════════════════════════════════════════════════════════════════
// WAF/GAF SELENIUM (JAVA/QAF) CHECKS — FW1 to FW13
// ═══════════════════════════════════════════════════════════════════════════════
function runQAFStandards(repoInfo) {
  const repoPath = repoInfo.repoPath;
  const javaFiles = collectFiles(repoPath, ['.java']);
  const allFiles  = collectFiles(repoPath, ['.java', '.xml', '.properties', '.yml', '.yaml', '.feature']);

  return {
    FW1:  checkQAFPageObjects(repoPath, javaFiles),
    FW2:  { result: 'Manual', evidence: 'Manual check - Review pom.xml/build.gradle for outdated dependencies', violations: [] },
    FW3:  checkGradle(repoPath),
    FW4:  checkWFElements(javaFiles),
    FW5:  checkQAFPageDeclarations(javaFiles),
    FW6:  checkQAFFrameworkMethods(javaFiles),
    FW7:  checkEnvHardcoding(javaFiles),
    FW8:  checkPasswords(javaFiles),
    FW9:  checkStaticWaitsJava(javaFiles),
    FW10: checkBDDStandards(repoPath),
    FW11: checkQAFAssertions(javaFiles),
    FW12: checkQAFScreenshots(javaFiles),
    FW13: { result: 'Manual', evidence: 'Manual check - Verify Octane test case linkage and automation result sync', violations: [] }
  };
}

function checkQAFPageObjects(repoPath, javaFiles) {
  const pageObjectDirs = ['pageobjects', 'pageObjects', 'PageObjects', 'pages', 'page_objects'];
  for (const dir of pageObjectDirs) {
    const candidates = [
      path.join(repoPath, 'src', 'main', 'java', dir),
      path.join(repoPath, 'src', 'test', 'java', dir),
      path.join(repoPath, 'src', dir),
      path.join(repoPath, dir)
    ];
    for (const c of candidates) {
      if (fs.existsSync(c)) {
        const count = collectFiles(c, ['.java']).length;
        return { result: 'Yes', evidence: `Page object directory found: ${path.relative(repoPath, c)} (${count} file(s))`, violations: [] };
      }
    }
  }
  const pageFiles = javaFiles.filter(f => /page|screen|po\./i.test(path.basename(f)));
  if (pageFiles.length > 0) {
    return { result: 'Yes', evidence: `${pageFiles.length} page object file(s) found by naming convention`, violations: [] };
  }
  return { result: 'No', evidence: 'No page object directory or page class files found', violations: [{ issue: 'Create a dedicated pageobjects/ directory following WAF/GAF structure' }] };
}

function checkGradle(repoPath) {
  const hasGradle = fs.existsSync(path.join(repoPath, 'build.gradle')) || fs.existsSync(path.join(repoPath, 'build.gradle.kts'));
  const hasMaven  = fs.existsSync(path.join(repoPath, 'pom.xml'));
  if (hasGradle) return { result: 'Yes', evidence: 'build.gradle found — project uses Gradle', violations: [] };
  if (hasMaven)  return { result: 'No',  evidence: 'pom.xml found — project still uses Maven. Migration to Gradle pending.', violations: [{ issue: 'Migrate build tool from Maven to Gradle' }] };
  return { result: 'N/A', evidence: 'No build tool config found at repo root', violations: [] };
}

function checkWFElements(javaFiles) {
  const wfHits = searchInFiles(javaFiles, /WFWebElement|WFDropDownListWebElement|WFCheckBoxWebElement|WFRadioButtonWebElement/);
  const rawHits = searchInFiles(javaFiles, /\bWebElement\b/).filter(h => !/WFWebElement/.test(h.line));
  if (wfHits.length > 0) {
    return {
      result: 'Yes',
      evidence: `${wfHits.length} WFWebElement declaration(s) found${rawHits.length > 0 ? `. Warning: ${rawHits.length} raw WebElement usage(s) also found` : ''}`,
      violations: rawHits.slice(0, 5).map(h => ({ file: h.file, line: h.lineNo, issue: `Raw WebElement used: ${h.line.trim()}` }))
    };
  }
  return { result: 'No', evidence: 'No WFWebElement declarations found — raw WebElement being used', violations: rawHits.slice(0, 5).map(h => ({ file: h.file, line: h.lineNo, issue: `Raw WebElement: ${h.line.trim()}` })) };
}

function checkQAFPageDeclarations(javaFiles) {
  const hits = searchInFiles(javaFiles, /@Page\b|extends\s+\w*Page\b|implements\s+\w*Page\b/);
  if (hits.length > 0) return { result: 'Yes', evidence: `${hits.length} WAF/GAF Page declaration(s) found`, violations: [] };
  return { result: 'No', evidence: 'Pages not declared as per WAF/GAF standards (@Page / extends XxxPage)', violations: [{ issue: 'Declare page classes using @Page annotation or extend WAF base page class' }] };
}

function checkQAFFrameworkMethods(javaFiles) {
  const hits = searchInFiles(javaFiles, /GAFWebPage\.|WAFWebPage\.|gafPage\.|wafPage\.|QAFWebElement\.|@QAFWebElement/);
  if (hits.length > 0) return { result: 'Yes', evidence: `${hits.length} GAF/WAF framework method usage(s) found`, violations: [] };
  return { result: 'No', evidence: 'No GAF/WAF framework methods detected in test code', violations: [{ issue: 'Use GAF/WAF framework methods instead of raw Selenium WebDriver calls' }] };
}

function checkQAFAssertions(javaFiles) {
  const hits = searchInFiles(javaFiles, /Assert\.(assertEquals|assertTrue|assertFalse|assertNotNull|assertNull|assertThat)|assertThat\s*\(/);
  if (hits.length > 0) return { result: 'Yes', evidence: `${hits.length} assertion(s) found in test files`, violations: [] };
  return { result: 'No', evidence: 'No assertions found in test files — validation steps missing', violations: [{ issue: 'Add TestNG/JUnit Assert statements to verify test outcomes' }] };
}

function checkQAFScreenshots(javaFiles) {
  const shots = searchInFiles(javaFiles, /takeScreenshot|screenshot\s*\(/i);
  if (shots.length === 0) return { result: 'Yes', evidence: 'No explicit screenshots (framework handles on failure — acceptable)', violations: [] };
  let nearAssert = 0;
  for (const h of shots) {
    const windowContent = h.surroundingLines || '';
    if (/assert|verify|validate|expect/i.test(windowContent)) nearAssert++;
  }
  const ratio = shots.length > 0 ? Math.round((nearAssert / shots.length) * 100) : 100;
  const pass   = ratio >= 70;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: `${shots.length} screenshot call(s) found; ${nearAssert} near assertions (${ratio}%)`,
    violations: pass ? [] : [{ issue: `${shots.length - nearAssert} screenshot(s) taken outside of assertion/validation context` }]
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// PLAYWRIGHT (TYPESCRIPT) CHECKS — FW1 to FW14
// ═══════════════════════════════════════════════════════════════════════════════
function runPlaywrightStandards(repoInfo) {
  const repoPath = repoInfo.repoPath;
  const tsFiles  = collectFiles(repoPath, ['.ts']);
  const allFiles = collectFiles(repoPath, ['.ts', '.js', '.json', '.yaml', '.yml', '.env', '.feature']);

  return {
    FW1:  checkPlaywrightConfig(repoPath),
    FW2:  checkPWPageObjects(repoPath, tsFiles),
    FW3:  checkFixtures(repoPath, tsFiles),
    FW4:  checkLocatorBestPractices(tsFiles),
    FW5:  checkTypeScriptStrict(repoPath),
    FW6:  checkEnvHardcoding(tsFiles),
    FW7:  checkHardcodedTestData(tsFiles),
    FW8:  checkPasswords(tsFiles),
    FW9:  checkStaticWaitsTS(tsFiles),
    FW10: checkBDDStandards(repoPath),
    FW11: checkPWAssertions(tsFiles),
    FW12: checkPWScreenshots(repoPath, tsFiles),
    FW13: checkPWDependencyVersions(repoPath),
    FW14: { result: 'Manual', evidence: 'Manual check - Verify Octane test case linkage and automation result sync', violations: [] }
  };
}

function checkPlaywrightConfig(repoPath) {
  const configCandidates = ['playwright.config.ts', 'playwright.config.js'];
  let configFile = null;
  let content = '';
  for (const c of configCandidates) {
    const full = path.join(repoPath, c);
    if (fs.existsSync(full)) { configFile = c; content = readFile(full); break; }
  }
  if (!configFile) return { result: 'No', evidence: 'playwright.config.ts not found at repo root', violations: [{ issue: 'Create playwright.config.ts with baseURL, timeout, retries, and reporter configured' }] };

  const checks = [
    { key: 'baseURL',   pattern: /baseURL\s*:/ },
    { key: 'timeout',   pattern: /timeout\s*:/ },
    { key: 'retries',   pattern: /retries\s*:/ },
    { key: 'reporter',  pattern: /reporter\s*:/ }
  ];
  const missing  = checks.filter(c => !c.pattern.test(content)).map(c => c.key);
  const present  = checks.filter(c =>  c.pattern.test(content)).map(c => c.key);
  const pass = missing.length <= 1;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: `${configFile} found. Configured: [${present.join(', ') || 'none'}]${missing.length > 0 ? `. Missing: [${missing.join(', ')}]` : ''}`,
    violations: missing.map(m => ({ issue: `playwright.config.ts missing '${m}' configuration` }))
  };
}

function checkPWPageObjects(repoPath, tsFiles) {
  const pageFiles = tsFiles.filter(f => /page\.|\.page\.|screen\.|\.screen\./i.test(path.basename(f)));
  const pageClasses = searchInFiles(tsFiles, /export\s+(default\s+)?class\s+\w+(Page|Screen|Component)\b/);

  // Check directory structure
  const pageDirs = ['pages', 'pageObjects', 'page-objects', 'screens', 'components'].map(d =>
    [path.join(repoPath, d), path.join(repoPath, 'src', d), path.join(repoPath, 'tests', d)]
  ).flat().filter(d => fs.existsSync(d));

  if (pageClasses.length > 0 || pageDirs.length > 0) {
    return {
      result: 'Yes',
      evidence: `POM pattern found: ${pageClasses.length} Page class(es)${pageDirs.length > 0 ? `, directory: ${path.basename(pageDirs[0])}` : ''}`,
      violations: []
    };
  }
  return { result: 'No', evidence: 'No Page Object Model pattern detected — no XxxPage classes or pages/ directory found', violations: [{ issue: "Create page classes using 'export class LoginPage' pattern in a pages/ directory" }] };
}

function checkFixtures(repoPath, tsFiles) {
  const fixtureFiles = tsFiles.filter(f => /fixture|fixtures/i.test(path.basename(f)));
  const fixtureInCode = searchInFiles(tsFiles, /base\.extend\s*<|test\.extend\s*<|fixtures\s*:/);
  const beforeEachDupes = searchInFiles(tsFiles, /beforeEach\s*\(\s*async/);

  if (fixtureFiles.length > 0 || fixtureInCode.length > 0) {
    return {
      result: 'Yes',
      evidence: `Fixtures pattern found: ${fixtureInCode.length} fixture definition(s)${fixtureFiles.length > 0 ? `, fixture file(s): ${fixtureFiles.map(f => path.basename(f)).join(', ')}` : ''}`,
      violations: []
    };
  }
  if (beforeEachDupes.length > 3) {
    return {
      result: 'No',
      evidence: `No fixtures found but ${beforeEachDupes.length} beforeEach blocks detected — consider replacing with fixtures`,
      violations: beforeEachDupes.slice(0, 5).map(h => ({ file: h.file, line: h.lineNo, issue: 'Repeated beforeEach — use Playwright fixture instead' }))
    };
  }
  return { result: 'Yes', evidence: 'No excessive beforeEach duplication detected — fixtures may not be required', violations: [] };
}

function checkLocatorBestPractices(tsFiles) {
  const goodLocators = searchInFiles(tsFiles, /getByRole\s*\(|getByTestId\s*\(|getByLabel\s*\(|getByText\s*\(|getByPlaceholder\s*\(/);
  const xpathLocators = searchInFiles(tsFiles, /\.locator\s*\(\s*['"`]\/\//);
  const cssLocators   = searchInFiles(tsFiles, /\.locator\s*\(\s*['"`][#.]\w/);

  const totalFragile = xpathLocators.length + cssLocators.length;
  const total = goodLocators.length + totalFragile;
  const ratio = total > 0 ? Math.round((goodLocators.length / total) * 100) : 100;
  const pass  = ratio >= 60 || total === 0;

  return {
    result: pass ? 'Yes' : 'No',
    evidence: total === 0
      ? 'No locators found to evaluate'
      : `${goodLocators.length} semantic locator(s) (getByRole/TestId/Label), ${totalFragile} fragile (XPath/CSS) — ${ratio}% best practice`,
    violations: [
      ...xpathLocators.slice(0, 5).map(h => ({ file: h.file, line: h.lineNo, issue: `XPath locator used: ${h.line.trim()}` })),
      ...cssLocators.slice(0,  3).map(h => ({ file: h.file, line: h.lineNo, issue: `CSS locator used: ${h.line.trim()}` }))
    ]
  };
}

function checkTypeScriptStrict(repoPath) {
  const tsconfigPath = path.join(repoPath, 'tsconfig.json');
  if (!fs.existsSync(tsconfigPath)) return { result: 'No', evidence: 'tsconfig.json not found at repo root', violations: [{ issue: 'Add tsconfig.json with strict: true' }] };
  const content = readFile(tsconfigPath);
  let parsed;
  try { parsed = JSON.parse(content.replace(/\/\/.*/g, '')); } catch { return { result: 'No', evidence: 'tsconfig.json could not be parsed', violations: [] }; }
  const strict  = parsed?.compilerOptions?.strict === true;
  const noImplicitAny = parsed?.compilerOptions?.noImplicitAny === true;
  const pass = strict || noImplicitAny;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: pass
      ? `TypeScript strict mode enabled (${strict ? 'strict: true' : 'noImplicitAny: true'})`
      : 'TypeScript strict mode not enabled in tsconfig.json',
    violations: pass ? [] : [{ issue: 'Add "strict": true to tsconfig.json compilerOptions' }]
  };
}

function checkHardcodedTestData(tsFiles) {
  const patterns = [
    /(['"`])\d{10,}\1/,                         // long numbers (account numbers)
    /(['"`])[A-Z]{2}\d{6,}\1/,                  // account-like codes
    /amount\s*[:=]\s*\d{3,}/,                   // hardcoded amounts
    /(['"`])\d{3}-\d{2}-\d{4}\1/,              // SSN pattern
    /testData\s*=\s*\{[^}]{50,}\}/              // large inline test data objects
  ];
  const violations = [];
  for (const f of tsFiles) {
    const content = readFile(f);
    const lines = content.split('\n');
    lines.forEach((line, idx) => {
      for (const p of patterns) {
        if (p.test(line) && !/\/\//.test(line.trim().substring(0, 3))) {
          violations.push({ file: path.basename(f), line: idx + 1, issue: `Potential hardcoded test data: ${line.trim().substring(0, 80)}` });
        }
      }
    });
  }
  const pass = violations.length === 0;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: pass ? 'No hardcoded test data detected in test files' : `${violations.length} potential hardcoded test data instance(s) found`,
    violations: violations.slice(0, 10)
  };
}

function checkPWAssertions(tsFiles) {
  const hits = searchInFiles(tsFiles, /await\s+expect\s*\(|expect\s*\(.*\)\.(toHave|toBe|toContain|toBeVisible|toBeEnabled|toBeChecked)/);
  if (hits.length > 0) return { result: 'Yes', evidence: `${hits.length} Playwright expect() assertion(s) found`, violations: [] };
  return { result: 'No', evidence: 'No Playwright expect() assertions found in test files', violations: [{ issue: "Add 'await expect(locator).toBeVisible()' style assertions to verify outcomes" }] };
}

function checkPWScreenshots(repoPath, tsFiles) {
  const configCandidates = ['playwright.config.ts', 'playwright.config.js'].map(c => path.join(repoPath, c));
  let configContent = '';
  for (const c of configCandidates) { if (fs.existsSync(c)) { configContent = readFile(c); break; } }

  // Screenshot on failure only is the correct pattern
  const onFailureOnly = /screenshot\s*:\s*['"`]only-on-failure['"`]|on-first-retry/i.test(configContent);
  const alwaysOn      = /screenshot\s*:\s*['"`]on['"`]/i.test(configContent);
  const explicitShots = searchInFiles(tsFiles, /\.screenshot\s*\(/).filter(h => !/toHaveScreenshot/.test(h.line));
  const visualShots   = searchInFiles(tsFiles, /toHaveScreenshot|toMatchSnapshot/);

  if (onFailureOnly) return { result: 'Yes', evidence: `Screenshots configured as 'only-on-failure' in playwright.config — correct pattern${visualShots.length > 0 ? `. ${visualShots.length} visual comparison test(s) found` : ''}`, violations: [] };
  if (alwaysOn)      return { result: 'No',  evidence: "Screenshots set to 'on' (always) in playwright.config — change to 'only-on-failure'", violations: [{ issue: "Set screenshot: 'only-on-failure' in playwright.config.ts use object" }] };
  if (explicitShots.length > 5) return { result: 'No', evidence: `${explicitShots.length} explicit .screenshot() calls found — likely taking screenshots at every step`, violations: explicitShots.slice(0, 5).map(h => ({ file: h.file, line: h.lineNo, issue: `Explicit screenshot: ${h.line.trim()}` })) };
  return { result: 'Yes', evidence: 'No excessive screenshot usage detected', violations: [] };
}

function checkPWDependencyVersions(repoPath) {
  const pkgPath = path.join(repoPath, 'package.json');
  if (!fs.existsSync(pkgPath)) return { result: 'No', evidence: 'package.json not found', violations: [] };
  let pkg;
  try { pkg = JSON.parse(readFile(pkgPath)); } catch { return { result: 'No', evidence: 'package.json could not be parsed', violations: [] }; }
  const deps = { ...pkg.dependencies, ...pkg.devDependencies };
  const pinnedOld = [];
  for (const [name, ver] of Object.entries(deps)) {
    // Flag packages pinned to very old exact versions (no ^ or ~)
    if (/^\d/.test(ver)) pinnedOld.push({ issue: `${name}@${ver} is pinned to exact version — consider using ^${ver}` });
  }
  const pwVer = deps['@playwright/test'] || deps['playwright'];
  const pass = pinnedOld.length <= 3;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: `package.json found. @playwright/test: ${pwVer || 'not found'}. ${pinnedOld.length} package(s) with pinned exact versions.`,
    violations: pinnedOld.slice(0, 10)
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// SHARED CHECKS (used by both QAF and Playwright)
// ═══════════════════════════════════════════════════════════════════════════════
function checkEnvHardcoding(files) {
  const hits = searchInFiles(files, /(https?:\/\/)(sit|uat|dev|prod|qa|staging)[.\-\/][a-zA-Z0-9.\/]+|baseURL\s*=\s*['"`]https?:\/\/|server\s*[:=]\s*['"`](sit|uat|prod|dev)/i);
  const pass = hits.length === 0;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: pass ? 'No hardcoded environment URLs found' : `${hits.length} hardcoded environment reference(s) found`,
    violations: hits.slice(0, 10).map(h => ({ file: h.file, line: h.lineNo, issue: h.line.trim() }))
  };
}

function checkPasswords(files) {
  const hits = searchInFiles(files, /password\s*[:=]\s*['"`][a-zA-Z0-9!@#$%^&*]{4,}['"`]|pwd\s*[:=]\s*['"`][^'"`]{4,}['"`]|passwd\s*[:=]\s*['"`][^'"`]+['"`]/i);
  const pass = hits.length === 0;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: pass ? 'No plaintext passwords found in scripts' : `${hits.length} potential plaintext password(s) found`,
    violations: hits.slice(0, 5).map(h => ({ file: h.file, line: h.lineNo, issue: `Plaintext password: ${h.line.trim().substring(0, 60)}` }))
  };
}

function checkStaticWaitsJava(javaFiles) {
  const hits = searchInFiles(javaFiles, /Thread\.sleep\s*\(|TimeUnit\.\w+\.sleep\s*\(/);
  const pass = hits.length === 0;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: pass ? 'No Thread.sleep() static waits found' : `${hits.length} Thread.sleep() / TimeUnit.sleep() call(s) found`,
    violations: hits.slice(0, 10).map(h => ({ file: h.file, line: h.lineNo, issue: `Static wait: ${h.line.trim()}` }))
  };
}

function checkStaticWaitsTS(tsFiles) {
  const hits = searchInFiles(tsFiles, /waitForTimeout\s*\(\s*\d{3,}|setTimeout\s*\([^,]+,\s*\d{3,}\)/);
  const pass = hits.length === 0;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: pass ? 'No hardcoded waitForTimeout() static waits found' : `${hits.length} static wait(s) found — use waitFor conditions instead`,
    violations: hits.slice(0, 10).map(h => ({ file: h.file, line: h.lineNo, issue: `Static wait: ${h.line.trim()}` }))
  };
}

function checkBDDStandards(repoPath) {
  const featureFiles = collectFiles(repoPath, ['.feature']);
  if (featureFiles.length === 0) return { result: 'N/A', evidence: 'No .feature files found — BDD not used in this project', violations: [] };

  const violations = [];
  let totalScenarios = 0;
  for (const f of featureFiles) {
    const content = readFile(f);
    if (!/^Feature:/m.test(content)) violations.push({ file: path.basename(f), issue: 'Missing Feature: keyword' });
    const scenarios = (content.match(/Scenario:|Scenario Outline:/g) || []).length;
    totalScenarios += scenarios;
    if (scenarios === 0) violations.push({ file: path.basename(f), issue: 'No Scenario or Scenario Outline found' });
    // Flag UI-level language in steps
    const uiSteps = searchInFiles([f], /^\s*(Given|When|Then|And)\s.*(click\s+the\s+button|enter\s+text|navigate\s+to\s+URL)/i);
    uiSteps.forEach(s => violations.push({ file: path.basename(f), line: s.lineNo, issue: `UI-level language in step: "${s.line.trim()}"` }));
  }

  const pass = violations.length === 0;
  return {
    result: pass ? 'Yes' : 'No',
    evidence: `${featureFiles.length} feature file(s), ${totalScenarios} scenario(s). ${violations.length} issue(s) found.`,
    violations: violations.slice(0, 10)
  };
}

module.exports = { runFrameworkStandards };

'use strict';
const { collectFiles, readFile, searchInFiles } = require('./fileScanner');
const path = require('path');

function runCodingStandards(repoInfo) {
  const results = {};
  const isQAF = repoInfo.type === 'qaf';
  const isPW = repoInfo.type === 'playwright';

  const javaFiles  = isQAF ? collectFiles(repoInfo.repoPath, ['.java']) : [];
  const tsFiles    = isPW  ? collectFiles(repoInfo.repoPath, ['.ts', '.js']) : [];
  const srcFiles   = [...javaFiles, ...tsFiles];

  // CS1 - Naming conventions
  results.CS1 = checkNamingConventions(srcFiles, isQAF, isPW);

  // CS2 - Comments on methods/classes
  results.CS2 = checkComments(srcFiles, isQAF, isPW);

  // CS3 - Commented/unused code in methods
  results.CS3 = checkUnusedCode(srcFiles);

  // CS4 - Error handling (try/catch)
  results.CS4 = checkErrorHandling(srcFiles, isQAF, isPW);

  // CS5 - No hardcoded DB/Excel connection strings
  results.CS5 = checkHardcodedStrings(srcFiles);

  return results;
}

function checkNamingConventions(files, isQAF, isPW) {
  if (files.length === 0) return { result: 'N/A', evidence: 'No source files found', violations: [] };

  const violations = [];

  if (isQAF) {
    // Java: classes PascalCase, methods/vars camelCase, constants UPPER_SNAKE
    const classPattern   = /^public\s+(class|interface|enum)\s+([a-z][A-Za-z0-9]*)\b/m;
    const constantBad    = /\b(private|protected|public|static)?\s+final\s+\w+\s+([a-z][a-z_]*[A-Z])\s*=/gm;

    for (const file of files.slice(0, 50)) {
      const content = readFile(file);
      const rel = path.basename(file);
      if (classPattern.test(content)) {
        violations.push({ file: rel, issue: 'Class name starts with lowercase' });
      }
    }
  }

  if (isPW) {
    // TS: functions camelCase, classes PascalCase, consts UPPER or camelCase
    for (const file of files.slice(0, 50)) {
      const content = readFile(file);
      const rel = path.basename(file);
      // Detect PascalCase function names (non-class, non-constructor)
      const badFunctionNames = content.match(/^\s*(?:async\s+)?function\s+[A-Z][A-Za-z0-9]+\s*\(/gm);
      if (badFunctionNames) {
        violations.push({ file: rel, issue: `Function with PascalCase name: ${badFunctionNames[0].trim()}` });
      }
    }
  }

  const passed = violations.length === 0;
  return {
    result: passed ? 'Yes' : 'No',
    evidence: passed
      ? `Naming conventions followed across ${files.length} source files`
      : `${violations.length} naming violation(s) found`,
    violations: violations.slice(0, 5)
  };
}

function checkComments(files, isQAF, isPW) {
  if (files.length === 0) return { result: 'N/A', evidence: 'No source files found', violations: [] };

  let methodsFound = 0, methodsWithComments = 0;

  for (const file of files.slice(0, 30)) {
    const content = readFile(file);
    const lines = content.split('\n');

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      const isMethod = isQAF
        ? /^(public|private|protected)\s+\w[\w<>[\]]*\s+\w+\s*\(/.test(line)
        : /^(async\s+)?(?:function\s+\w+|\w+\s*[:=]\s*(?:async\s+)?\(.*\)\s*(?:=>|{))/.test(line);

      if (isMethod) {
        methodsFound++;
        const prevLine = i > 0 ? lines[i - 1].trim() : '';
        const twoPrev  = i > 1 ? lines[i - 2].trim() : '';
        if (prevLine.startsWith('//') || prevLine.startsWith('*') || prevLine.startsWith('/*') ||
            twoPrev.startsWith('/**') || prevLine === '*/') {
          methodsWithComments++;
        }
      }
    }
  }

  if (methodsFound === 0) return { result: 'N/A', evidence: 'No methods detected', violations: [] };

  const pct = Math.round((methodsWithComments / methodsFound) * 100);
  const passed = pct >= 50;
  return {
    result: passed ? 'Yes' : 'No',
    evidence: `${methodsWithComments}/${methodsFound} methods have comments (${pct}%)`,
    violations: []
  };
}

function checkUnusedCode(files) {
  if (files.length === 0) return { result: 'N/A', evidence: 'No source files found', violations: [] };

  const hits = searchInFiles(files, /^\s*(\/\/.*|\/\*.*)\s*(TODO|FIXME|commented|unused|old code|remove)/i);
  const blockComments = searchInFiles(files, /^\s*\/\*\s*(public|private|void|async|function|class)\s/i);
  const allHits = [...hits, ...blockComments];

  const passed = allHits.length === 0;
  return {
    result: passed ? 'Yes' : 'No',
    evidence: passed
      ? 'No significant commented-out code detected'
      : `${allHits.length} instance(s) of commented-out/unused code found`,
    violations: allHits.slice(0, 5).map(h => ({ file: path.basename(h.file), lineNo: h.lineNo, issue: h.line.substring(0, 80) }))
  };
}

function checkErrorHandling(files, isQAF, isPW) {
  if (files.length === 0) return { result: 'N/A', evidence: 'No source files found', violations: [] };

  const tryCatchHits = searchInFiles(files, /\btry\s*\{/);
  const totalFiles   = files.length;
  const filesWithTryCatch = new Set(tryCatchHits.map(h => h.file)).size;
  const pct = Math.round((filesWithTryCatch / Math.min(totalFiles, 30)) * 100);

  const passed = pct >= 30;
  return {
    result: passed ? 'Yes' : 'No',
    evidence: `try/catch found in ${filesWithTryCatch} file(s) (${pct}% of sampled files)`,
    violations: []
  };
}

function checkHardcodedStrings(files) {
  if (files.length === 0) return { result: 'N/A', evidence: 'No source files found', violations: [] };

  const patterns = [
    /jdbc:[a-z]+:\/\/[^"'\s]+/i,
    /mongodb(\+srv)?:\/\/[^"'\s]+/i,
    /Provider=.*Data Source=/i,
    /\.xlsx.*password\s*=\s*["'][^"']+["']/i,
    /connectionString\s*=\s*["'][^"']+["']/i,
    /dataSource\s*=\s*["'][^"']+["']/i,
  ];

  const violations = [];
  for (const pat of patterns) {
    const hits = searchInFiles(files, pat);
    hits.forEach(h => violations.push({
      file: path.basename(h.file),
      lineNo: h.lineNo,
      issue: h.line.substring(0, 80)
    }));
  }

  const passed = violations.length === 0;
  return {
    result: passed ? 'Yes' : 'No',
    evidence: passed
      ? 'No hardcoded DB/Excel connection strings found'
      : `${violations.length} hardcoded connection string(s) detected`,
    violations: violations.slice(0, 5)
  };
}

module.exports = { runCodingStandards };

'use strict';
const fs   = require('fs');
const path = require('path');
const { collectFiles, readFile, searchInFiles } = require('./fileScanner');

function runModeOfExecution(repoInfo) {
  const results = {};
  const repoPath = repoInfo.repoPath;
  const isQAF = repoInfo.type === 'qaf';
  const isPW  = repoInfo.type === 'playwright';

  const srcFiles = isQAF
    ? collectFiles(repoPath, ['.java', '.xml', '.properties', '.yaml', '.yml'])
    : collectFiles(repoPath, ['.ts', '.js', '.json', '.yaml', '.yml']);

  results.MOE1 = checkHyperExecuteSetup(repoPath);
  results.MOE2 = checkSmokeExecution(repoPath, srcFiles, isQAF);
  results.MOE3 = checkRegressionExecution(repoPath, srcFiles, isQAF);
  results.MOE4 = { result: 'Manual', evidence: 'Manual check required - Verify QMetry/execution report sharing with stakeholders', violations: [] };
  results.MOE5 = checkParallelExecution(repoPath, srcFiles, isQAF, isPW);

  return results;
}

// ─── MOE1: HyperExecute Setup ────────────────────────────────────────────────
function checkHyperExecuteSetup(repoPath) {
  // Standard HyperExecute YAML filenames
  const heFilenames = [
    'hyperexecute.yaml', 'hyperexecute.yml',
    'he.yaml', 'he.yml',
    'hyperexecute_config.yaml', 'hyperexecute_config.yml',
    '.hyperexecute.yaml', '.hyperexecute.yml'
  ];

  // 1. Check repo root
  for (const name of heFilenames) {
    const full = path.join(repoPath, name);
    if (fs.existsSync(full)) {
      const content = readFile(full);
      return _heFound(name, content);
    }
  }

  // 2. Check common sub-folders
  const subDirs = ['ci', '.ci', 'hyperexecute', 'he', '.he', 'lambdatest', 'lt'];
  for (const dir of subDirs) {
    const dirPath = path.join(repoPath, dir);
    if (fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory()) {
      for (const name of heFilenames) {
        const full = path.join(dirPath, name);
        if (fs.existsSync(full)) {
          const content = readFile(full);
          return _heFound(`${dir}/${name}`, content);
        }
      }
    }
  }

  // 3. Scan all YAML files for HyperExecute-specific keywords
  const allYamls = collectFiles(repoPath, ['.yml', '.yaml']);
  for (const f of allYamls) {
    const content = readFile(f);
    if (/hyperexecute|lambdatest.*concurrency|smartGrid|runson:\s*(win|linux|mac)/i.test(content)) {
      return _heFound(path.basename(f), content);
    }
  }

  return {
    result: 'No',
    evidence: 'No HyperExecute config found (hyperexecute.yaml / he.yaml). Repo not yet onboarded to HyperExecute.',
    violations: [{ issue: 'Create hyperexecute.yaml in repo root to onboard to HyperExecute' }]
  };
}

function _heFound(fileName, content) {
  const details = [];
  const m1 = content.match(/concurrency\s*:\s*(\d+)/i);
  const m2 = content.match(/runson\s*:\s*(\S+)/i);
  const m3 = content.match(/framework\s*:\s*(\S+)/i);
  const m4 = content.match(/testSuiteTimeout\s*:\s*(\d+)/i);
  if (m1) details.push(`concurrency: ${m1[1]}`);
  if (m2) details.push(`runson: ${m2[1]}`);
  if (m3) details.push(`framework: ${m3[1]}`);
  if (m4) details.push(`timeout: ${m4[1]}min`);

  return {
    result: 'Yes',
    evidence: `HyperExecute config found: ${fileName}${details.length ? ' | ' + details.join(', ') : ''}`,
    violations: []
  };
}

// ─── MOE2: Smoke execution frequency via HyperExecute ────────────────────────
function checkSmokeExecution(repoPath, srcFiles, isQAF) {
  // Check HyperExecute YAML for smoke references
  const allYamls = collectFiles(repoPath, ['.yml', '.yaml']);
  const heYamls  = allYamls.filter(f => {
    const name = path.basename(f).toLowerCase();
    return name.includes('hyperexecute') || name.includes('he.y') || name.startsWith('he.');
  });

  const smokeInHE      = searchInFiles(heYamls.length > 0 ? heYamls : allYamls, /smoke|sanity/i);
  const featureFiles   = collectFiles(repoPath, ['.feature']);
  const smokeTags      = searchInFiles(featureFiles, /@smoke|@sanity/i);
  const smokeGroups    = isQAF
    ? searchInFiles(srcFiles, /groups\s*=\s*.*smoke|@Test.*smoke/i)
    : searchInFiles(srcFiles, /test\.describe.*smoke|test\s*\(.*smoke/i);

  const passed = smokeInHE.length > 0 || smokeTags.length > 0 || smokeGroups.length > 0;
  const parts  = [
    smokeInHE.length    > 0 && 'HyperExecute YAML references smoke',
    smokeTags.length    > 0 && `${smokeTags.length} @smoke/@sanity tag(s)`,
    smokeGroups.length  > 0 && 'smoke test groups defined'
  ].filter(Boolean);

  return {
    result: passed ? 'Yes' : 'No',
    evidence: passed
      ? `Smoke execution setup found: ${parts.join(', ')}`
      : 'No smoke test configuration found in HyperExecute YAML or test files',
    violations: passed ? [] : [{ issue: 'Add @smoke tags and include smoke suite in HyperExecute YAML' }]
  };
}

// ─── MOE3: Regression execution via HyperExecute ─────────────────────────────
function checkRegressionExecution(repoPath, srcFiles, isQAF) {
  const allYamls = collectFiles(repoPath, ['.yml', '.yaml']);
  const heYamls  = allYamls.filter(f => {
    const name = path.basename(f).toLowerCase();
    return name.includes('hyperexecute') || name.includes('he.y') || name.startsWith('he.');
  });

  const regressionInHE  = searchInFiles(heYamls.length > 0 ? heYamls : allYamls, /regression|regress|release/i);
  const featureFiles    = collectFiles(repoPath, ['.feature']);
  const regressionTags  = searchInFiles(featureFiles, /@regression|@regress/i);
  const regressionXML   = isQAF
    ? collectFiles(repoPath, ['.xml']).filter(f => /regression|suite/i.test(path.basename(f)))
    : [];

  const passed = regressionInHE.length > 0 || regressionTags.length > 0 || regressionXML.length > 0;
  const parts  = [
    regressionInHE.length   > 0 && 'HyperExecute YAML references regression',
    regressionTags.length   > 0 && `${regressionTags.length} @regression tag(s)`,
    regressionXML.length    > 0 && `${regressionXML.length} regression XML suite(s)`
  ].filter(Boolean);

  return {
    result: passed ? 'Yes' : 'No',
    evidence: passed
      ? `Regression execution setup found: ${parts.join(', ')}`
      : 'No regression execution configuration found in HyperExecute YAML or test files',
    violations: passed ? [] : [{ issue: 'Add @regression tags and include regression suite in HyperExecute YAML' }]
  };
}

// ─── MOE5: Parallel execution ─────────────────────────────────────────────────
function checkParallelExecution(repoPath, srcFiles, isQAF, isPW) {
  // HyperExecute concurrency counts as parallel — check this first for both types
  const allYamls = collectFiles(repoPath, ['.yml', '.yaml']);
  const heConcurrency = searchInFiles(allYamls, /concurrency\s*:\s*[2-9]|concurrency\s*:\s*\d{2,}/i);
  if (heConcurrency.length > 0) {
    const m = readFile(heConcurrency[0].file || allYamls[0]).match(/concurrency\s*:\s*(\d+)/i);
    return {
      result: 'Yes',
      evidence: `Parallel execution via HyperExecute concurrency${m ? `: ${m[1]} parallel sessions` : ''}`,
      violations: []
    };
  }

  if (isQAF) {
    const xmlFiles        = collectFiles(repoPath, ['.xml']);
    const parallelInXML   = searchInFiles(xmlFiles, /parallel\s*=\s*["'](methods|tests|classes|instances)/i);
    const parallelInPom   = searchInFiles(collectFiles(repoPath, ['pom.xml']), /<parallel>|<forkCount>/i);
    const parallelInGradle= searchInFiles(collectFiles(repoPath, ['.gradle']), /maxParallelForks|parallel/i);
    const passed = parallelInXML.length > 0 || parallelInPom.length > 0 || parallelInGradle.length > 0;
    return {
      result: passed ? 'Yes' : 'No',
      evidence: passed
        ? `Parallel execution: ${parallelInXML.length > 0 ? 'TestNG parallel XML' : parallelInPom.length > 0 ? 'Maven Surefire forkCount' : 'Gradle maxParallelForks'}`
        : 'No parallel execution found in TestNG XML, Maven, Gradle, or HyperExecute concurrency',
      violations: []
    };
  }

  if (isPW) {
    const configFiles = srcFiles.filter(f => /playwright\.config/i.test(path.basename(f)));
    const parallelInConfig = searchInFiles(configFiles.length > 0 ? configFiles : srcFiles, /workers\s*:\s*[2-9]|fullyParallel\s*:\s*true/i);
    const passed = parallelInConfig.length > 0;
    return {
      result: passed ? 'Yes' : 'No',
      evidence: passed
        ? 'Parallel execution configured in playwright.config (workers / fullyParallel)'
        : 'No parallel configuration found in playwright.config or HyperExecute concurrency',
      violations: []
    };
  }

  return { result: 'N/A', evidence: 'Unknown repo type', violations: [] };
}

module.exports = { runModeOfExecution };

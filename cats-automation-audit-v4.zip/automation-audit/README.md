# CATS Team — Automation Audit Tool v1.0

Quarterly Test Automation Audit tool for QAF/Selenium (Java) and Playwright (TypeScript) repositories. Runs entirely from the **local cloned repo** — no GitHub API or network access needed.

---

## Prerequisites

- Node.js >= 16
- Git installed and in PATH
- Repo cloned locally on **default branch** (main/master/develop)

---

## Installation

```cmd
# 1. Copy this folder to your machine (e.g. C:\tools\cats-audit)
cd C:\tools\cats-audit

# 2. Install dependencies (one time only)
npm install
```

---

## Usage

```cmd
node audit.js --repo "C:\repos\my-project" --project "AOM-1NA1" --output "\\server\share\audits"
```

### Options

| Flag | Required | Description |
|------|----------|-------------|
| `--repo` / `-r` | ✅ | Full path to local cloned repo |
| `--project` / `-p` | ✅ | Project name (e.g. AOM-1NA1, 1AM1) |
| `--output` / `-o` | | Output folder — local or UNC path (default: current dir) |
| `--lob` / `-l` | | LOB name (default: WIM_AOM) |

---

## What it checks (38 checkpoints)

### Coding Standards (5)
| ID | Checkpoint |
|----|-----------|
| CS1 | Naming conventions (camelCase, PascalCase, UPPER_SNAKE) |
| CS2 | Comments on methods and classes |
| CS3 | No commented-out / unused code in methods |
| CS4 | Error handling with try/catch |
| CS5 | No hardcoded DB/Excel connection strings |

### WAF/GAF Automation Standards (13)
| ID | Checkpoint |
|----|-----------|
| WAF1 | Page objects maintained per WAF/GAF standards |
| WAF2 | Latest (non-SNAPSHOT) dependency versions |
| WAF3 | Migrated to Gradle (QAF repos) |
| WAF4 | Page objects use WFWebElement/WFDropDownListWebElement |
| WAF5 | Pages declared as per WAF/GAF pattern |
| WAF6 | GAF/WAF framework methods used in automation logic |
| WAF7 | No hardcoded environment URLs in test code |
| WAF8 | Passwords encoded/encrypted (not plaintext) |
| WAF9 | No static waits (Thread.sleep / waitForTimeout) |
| WAF10 | BDD feature files follow Gherkin standards |
| WAF11 | Proper assertion/validation steps present |
| WAF12 | Screenshots taken only in validation context |
| WAF13 | ⚠️ **Manual** — Octane integration (requires Octane access) |

### Mode of Execution (5)
| ID | Checkpoint |
|----|-----------|
| MOE1 | HyperExecute config file present in repo (hyperexecute.yaml) |
| MOE2 | Smoke test execution configured |
| MOE3 | Regression execution configured |
| MOE4 | ⚠️ **Manual** — QMetry reports shared to stakeholders |
| MOE5 | Parallel execution configured |

### GIT Maintenance (6)
| ID | Checkpoint |
|----|-----------|
| GIT1 | Enterprise GIT remote origin configured |
| GIT2 | Repo actively maintained (recent commits, not stale) |
| GIT3 | Frequent commits (≥5 in last 30 days) |
| GIT4 | Branching strategy (feature/develop/release branches) |
| GIT5 | Code reviews via merge/PR commits |
| GIT6 | ⚠️ **Manual** — Onsite stakeholder in code review |

> **⚠️ Manual items** (WAF13, MOE4, GIT6): Left blank in the Excel for auditor to fill in.

---

## Output Files

Two files are saved to the output folder:

| File | Description |
|------|-------------|
| `Audit_<PROJECT>_<DATE>.xlsx` | Excel report matching your existing template format |
| `Audit_<PROJECT>_<DATE>_findings.json` | Full findings with all evidence and violation details |

---

## Maturity Index

| Index | % Range | Label |
|-------|---------|-------|
| 1 | < 25% | Initial |
| 2 | 25–50% | Developing |
| 3 | 50–75% | Defined |
| 4 | 75–99% | Managed |
| 5 | 100% | Optimized |

---

## Running for Multiple Projects

```cmd
for %p in (AOM-1NA1 1AM1 1DB1 1IAM1) do (
  node audit.js --repo "C:\repos\%p" --project "%p" --output "\\server\share\Q2-2025-Audit"
)
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `Cannot find module` | Run `npm install` first |
| `Not a git repository` | Ensure you cloned the repo (not just a zip download) |
| `Cannot write to UNC path` | Run as a user who has write access to `\\server\share` |
| WAF checks showing N/A | Tool auto-detects repo type; ensure `pom.xml`/`build.gradle`/`package.json` is in root |

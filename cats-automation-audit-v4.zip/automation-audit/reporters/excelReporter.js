'use strict';
const ExcelJS = require('exceljs');
const path    = require('path');
const fs      = require('fs');

// Colour palette matching your existing audit template
const COLORS = {
  headerBg   : 'FF203864',  // Dark blue (title row)
  catBg      : 'FF4472C4',  // Medium blue (category header)
  yes        : 'FF00B050',  // Green
  no         : 'FFFF0000',  // Red
  manual     : 'FFFFC000',  // Amber
  na         : 'FF808080',  // Grey
  totalBg    : 'FFFFD966',  // Yellow (totals row)
  maturity1  : 'FFFF0000',
  maturity2  : 'FFFF6600',
  maturity3  : 'FFFFC000',
  maturity4  : 'FF92D050',
  maturity5  : 'FF00B050',
};

const RESULT_COLORS = { 'Yes': COLORS.yes, 'No': COLORS.no, 'Manual': COLORS.manual, 'N/A': COLORS.na };

async function generateReport(auditResult, outputPath) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'CATS Automation Audit Tool';
  wb.created = new Date();

  // Sheet 1 — Audit Results
  await _buildAuditSheet(wb, auditResult);
  // Sheet 2 — Violation Details
  await _buildViolationsSheet(wb, auditResult);
  // Sheet 3 — How Audit is Performed
  _buildInfoSheet(wb);

  await wb.xlsx.writeFile(outputPath);
  return outputPath;
}

async function _buildAuditSheet(wb, auditResult) {
  const ws = wb.addWorksheet('Test Automation Audit', { views: [{ state: 'frozen', ySplit: 6 }] });

  // Column widths
  ws.columns = [
    { width: 5  }, // A - row num
    { width: 6  }, // B - check num
    { width: 65 }, // C - check point description
    { width: 8  }, // D - Yes
    { width: 8  }, // E - No
    { width: 8  }, // F - N/A
    { width: 45 }, // G - Remarks/Evidence
    { width: 12 }, // H - Weightage
    { width: 15 }, // I - Points(Yes+N/A)
  ];

  // ─── Header Rows ───────────────────────────────────────────────────────────
  _mergeRow(ws, 1, 'Test Automation Audit', 'A1', 'I1', COLORS.headerBg, 16, true);
  _labelRow(ws, 2, 'Project Name', auditResult.meta.projectName);
  _labelRow(ws, 3, 'LOB',         auditResult.meta.lob || 'WIM_AOM');
  _labelRow(ws, 4, 'Date',        auditResult.meta.date);

  // Column headings
  const hdr = ws.addRow(['', '', 'Check Points', 'Yes', 'No', 'N/A', 'Remarks', 'Weightage', 'Points(Yes+N/A)']);
  hdr.eachCell(cell => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.catBg } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = _border();
  });
  hdr.height = 30;

  let rowIdx = 7;
  let totalPoints = 0, totalPossible = 0;

  for (const cat of auditResult.categories) {
    // Category header row
    const catRow = ws.addRow(['', '', cat.name]);
    catRow.getCell(3).font = { bold: true, size: 11 };
    catRow.getCell(3).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9E1F2' } };
    ws.mergeCells(`C${rowIdx}:I${rowIdx}`);
    rowIdx++;

    let catPoints = 0, catPossible = 0;

    for (const [i, check] of cat.checks.entries()) {
      const r      = check.result;
      const isYes  = r === 'Yes';
      const isNA   = r === 'N/A';
      const pts    = (isYes || isNA) ? 1 : 0;
      catPoints   += pts;
      catPossible += 1;

      const row = ws.addRow([
        '',
        i + 1,
        check.description,
        isYes ? '✔' : '',
        r === 'No' ? '✔' : '',
        isNA ? '✔' : '',
        check.evidence || '',
        '',
        ''
      ]);

      // Colour result cells
      ['D','E','F'].forEach((col, ci) => {
        const cell = row.getCell(col);
        const vals = ['Yes','No','N/A'];
        if (cell.value === '✔') {
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: RESULT_COLORS[vals[ci]] || 'FFFFFFFF' } };
          cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        }
        cell.alignment = { horizontal: 'center', vertical: 'middle' };
        cell.border = _border();
      });

      row.getCell('C').alignment = { wrapText: true, vertical: 'middle' };
      row.getCell('G').alignment = { wrapText: true, vertical: 'middle' };
      row.getCell('B').alignment = { horizontal: 'center', vertical: 'middle' };
      ['B','C','G'].forEach(c => { row.getCell(c).border = _border(); });
      row.height = 30;
      rowIdx++;
    }

    totalPoints   += catPoints;
    totalPossible += catPossible;

    // Category weightage row
    const catTotal = cat.catScore;
    const wtRow    = ws.getRow(rowIdx - 1);
    wtRow.getCell('H').value = cat.weightage;
    wtRow.getCell('I').value = catTotal !== undefined ? catTotal : catPoints;
    wtRow.getCell('H').font = { bold: true };
    wtRow.getCell('I').font = { bold: true };
  }

  // Total row
  const totalRow = ws.addRow(['', '', 'Total:', '', '', '', '', auditResult.totalPoints, auditResult.totalPoints]);
  totalRow.eachCell(cell => {
    cell.font = { bold: true, size: 11 };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.totalBg } };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    cell.border = _border();
  });
  totalRow.getCell('C').alignment = { horizontal: 'right', vertical: 'middle' };

  rowIdx += 2;

  // Maturity Index summary
  const matRow = ws.addRow(['', '', `Automation Maturity Index`, '', auditResult.maturityIndex, '', `(${auditResult.maturityLabel})`, '', '']);
  matRow.getCell('C').font = { bold: true, size: 12 };
  matRow.getCell('E').font = { bold: true, size: 16 };
  const matColor = [COLORS.maturity1, COLORS.maturity2, COLORS.maturity3, COLORS.maturity4, COLORS.maturity5][auditResult.maturityIndex - 1] || COLORS.na;
  matRow.getCell('E').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: matColor } };
  matRow.getCell('E').font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 16 };
  matRow.getCell('E').alignment = { horizontal: 'center', vertical: 'middle' };
  matRow.height = 35;
}

async function _buildViolationsSheet(wb, auditResult) {
  const ws = wb.addWorksheet('Violation Details');
  ws.columns = [
    { header: 'Category',    width: 20 },
    { header: 'Check ID',    width: 10 },
    { header: 'Check Point', width: 50 },
    { header: 'Result',      width: 10 },
    { header: 'File',        width: 35 },
    { header: 'Line No',     width: 10 },
    { header: 'Issue',       width: 60 },
  ];

  ws.getRow(1).eachCell(cell => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.headerBg } };
    cell.alignment = { horizontal: 'center' };
  });

  for (const cat of auditResult.categories) {
    for (const check of cat.checks) {
      if (check.violations && check.violations.length > 0) {
        for (const v of check.violations) {
          const row = ws.addRow([
            cat.name, check.id, check.description, check.result,
            v.file || '', v.lineNo || '', v.issue || ''
          ]);
          if (check.result === 'No') {
            row.getCell(4).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: COLORS.no } };
            row.getCell(4).font = { color: { argb: 'FFFFFFFF' } };
          }
          row.getCell(7).alignment = { wrapText: true };
          row.height = 20;
        }
      } else if (check.result === 'No') {
        ws.addRow([cat.name, check.id, check.description, check.result, '', '', check.evidence || '']);
      }
    }
  }
}

function _buildInfoSheet(wb) {
  const ws = wb.addWorksheet('How Audit is Performed');
  ws.getColumn('A').width = 90;

  const title = ws.addRow(['How Audit will be Performed?']);
  title.getCell(1).font = { bold: true, size: 13 };
  title.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9E1F2' } };

  const lines = [
    '1. Each Test automation project will be assessed against 4 types of standards - (Coding Standards, Framework Automation Standards, Mode of Execution and GIT).',
    '2. Each standard will have defined check points against which the project will be assessed.',
    '3. Each check point carries a weightage of 1 point.',
    '4. At end of audit, percentage will be calculated based on points project got divide by Total points.',
    '5. Based on the percentage maturity index will be calculated.',
    '   1 - If percentage is <25',
    '   2 - if percentage is >=25 and <=50',
    '   3 - if percentage is >=50 and <=75',
    '   4 - if percentage is >=75 and <100',
    '   5 - if percentage is 100',
  ];

  for (const line of lines) {
    const r = ws.addRow([line]);
    r.getCell(1).alignment = { wrapText: true };
    r.height = 18;
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function _mergeRow(ws, rowNum, text, from, to, bgColor, fontSize = 12, bold = false) {
  ws.mergeCells(`${from}:${to}`);
  const row = ws.getRow(rowNum);
  row.getCell(from.replace(/[0-9]/g,'') || 'A').value = text;
  row.getCell('A').font  = { bold, size: fontSize, color: { argb: 'FFFFFFFF' } };
  row.getCell('A').fill  = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgColor } };
  row.getCell('A').alignment = { horizontal: 'center', vertical: 'middle' };
  row.height = 28;
}

function _labelRow(ws, rowNum, label, value) {
  const row = ws.getRow(rowNum);
  row.getCell('B').value = label;
  row.getCell('B').font  = { bold: true };
  row.getCell('C').value = value;
  ws.mergeCells(`C${rowNum}:I${rowNum}`);
}

function _border() {
  const s = { style: 'thin', color: { argb: 'FFB0B0B0' } };
  return { top: s, left: s, bottom: s, right: s };
}

module.exports = { generateReport };

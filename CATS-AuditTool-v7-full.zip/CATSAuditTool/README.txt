See CATS_Audit_Tool_Setup_Guide_v5.docx for full instructions.

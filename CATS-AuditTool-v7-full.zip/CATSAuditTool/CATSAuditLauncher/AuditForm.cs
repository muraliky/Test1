using System.Diagnostics;
using System.Text;
using System.Drawing.Drawing2D;

namespace CATSAuditLauncher;

public class AuditForm : Form
{
    // ── Controls ──────────────────────────────────────────────────────────────
    private Panel        _header       = null!;
    private Panel        _cardInputs   = null!;
    private Panel        _cardLog      = null!;
    private Panel        _footer       = null!;

    private TextBox      _txtRepo      = null!;
    private Button       _btnBrowse    = null!;
    private ComboBox     _cmbLob       = null!;
    private ComboBox     _cmbSubLob    = null!;
    private TextBox      _txtProject   = null!;
    private RichTextBox  _rtbLog       = null!;
    private Button       _btnRun       = null!;
    private Button       _btnClear     = null!;
    private ProgressBar  _progress     = null!;
    private Label        _lblStatus    = null!;
    private Label        _lblBranch    = null!;

    // ── State ─────────────────────────────────────────────────────────────────
    private Process? _proc;
    private bool     _running;
    // Branch warning state — set when output contains branch warning
    private bool     _branchWarningShown;

    // ── Palette ───────────────────────────────────────────────────────────────
    static readonly Color C_RED      = Color.FromArgb(211, 32,  41);
    static readonly Color C_RED_HOV  = Color.FromArgb(180, 20,  30);
    static readonly Color C_GOLD     = Color.FromArgb(181, 146, 43);
    static readonly Color C_DARK     = Color.FromArgb(21,  40,  76);
    static readonly Color C_MID      = Color.FromArgb(37,  71, 123);
    static readonly Color C_BG       = Color.FromArgb(240, 244, 250);
    static readonly Color C_CARD     = Color.FromArgb(255, 255, 255);
    static readonly Color C_BORDER   = Color.FromArgb(210, 220, 235);
    static readonly Color C_LABEL    = Color.FromArgb(50,  70, 110);
    static readonly Color C_LOGBG    = Color.FromArgb(13,  22,  40);
    static readonly Color C_LOG_OK   = Color.FromArgb(72,  199, 116);
    static readonly Color C_LOG_ERR  = Color.FromArgb(255,  90,  90);
    static readonly Color C_LOG_WARN = Color.FromArgb(255, 200,  50);
    static readonly Color C_LOG_INFO = Color.FromArgb(180, 210, 255);
    static readonly Color C_LOG_DIM  = Color.FromArgb(110, 135, 170);
    static readonly Color C_LOG_CMD  = Color.FromArgb(130, 180, 255);

    public AuditForm()
    {
        BuildUI();
        LoadLobs();
        AppendLog("Ready — fill in the fields above and click Run Audit.", C_LOG_DIM);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Build UI
    // ─────────────────────────────────────────────────────────────────────────
    void BuildUI()
    {
        SuspendLayout();
        Text            = "CATS Team  ·  Automation Audit Launcher";
        Size            = new Size(980, 820);
        MinimumSize     = new Size(880, 700);
        StartPosition   = FormStartPosition.CenterScreen;
        BackColor       = C_BG;
        Font            = new Font("Segoe UI", 9.5f);
        FormBorderStyle = FormBorderStyle.Sizable;
        Icon            = SystemIcons.Application;

        BuildHeader();
        BuildFooter();
        BuildBody();

        ResumeLayout(true);
    }

    // ── Header ────────────────────────────────────────────────────────────────
    void BuildHeader()
    {
        _header = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = C_DARK };

        // Gold accent strip
        var accent = new Panel { Dock = DockStyle.Bottom, Height = 4, BackColor = C_GOLD };

        var logo = new Label
        {
            Text      = "CATS",
            Font      = new Font("Segoe UI", 22f, FontStyle.Bold),
            ForeColor = C_RED,
            AutoSize  = true,
            Location  = new Point(24, 18),
        };
        var title = new Label
        {
            Text      = "Team  ·  Automation Audit Launcher",
            Font      = new Font("Segoe UI", 18f, FontStyle.Regular),
            ForeColor = Color.White,
            AutoSize  = true,
            Location  = new Point(92, 21),
        };
        var sub = new Label
        {
            Text      = "Center of Excellence – Automation & Tools Squad  |  v3.0",
            Font      = new Font("Segoe UI", 8.5f, FontStyle.Italic),
            ForeColor = Color.FromArgb(150, 180, 220),
            AutoSize  = true,
            Location  = new Point(26, 56),
        };
        _header.Controls.AddRange(new Control[] { logo, title, sub, accent });
        Controls.Add(_header);
    }

    // ── Footer ────────────────────────────────────────────────────────────────
    void BuildFooter()
    {
        _footer = new Panel
        {
            Dock      = DockStyle.Bottom,
            Height    = 58,
            BackColor = C_CARD,
            Padding   = new Padding(20, 10, 20, 10),
        };
        var topLine = new Panel { Dock = DockStyle.Top, Height = 1, BackColor = C_BORDER };

        _btnRun = MakeButton("▶  Run Audit", new Point(20, 11), new Size(148, 36),
            C_RED, Color.White, bold: true);
        _btnRun.Click += BtnRun_Click;
        _btnRun.MouseEnter += (_, _) => { if (!_running) _btnRun.BackColor = C_RED_HOV; };
        _btnRun.MouseLeave += (_, _) => { if (!_running) _btnRun.BackColor = C_RED; };

        _btnClear = MakeButton("Clear Log", new Point(178, 11), new Size(100, 36),
            C_CARD, C_MID, bold: false, border: C_BORDER);
        _btnClear.Click += (_, _) => { _rtbLog.Clear(); AppendLog("Log cleared.", C_LOG_DIM); };

        _progress = new ProgressBar
        {
            Location    = new Point(296, 17),
            Size        = new Size(280, 22),
            Style       = ProgressBarStyle.Marquee,
            MarqueeAnimationSpeed = 30,
            Visible     = false,
        };

        _lblStatus = new Label
        {
            Location  = new Point(596, 18),
            AutoSize  = true,
            ForeColor = C_LOG_DIM,
            Font      = new Font("Segoe UI", 9f, FontStyle.Italic),
            Text      = "Ready",
        };

        _footer.Controls.AddRange(new Control[] { topLine, _btnRun, _btnClear, _progress, _lblStatus });
        Controls.Add(_footer);
    }

    // ── Body (inputs card + log card) ─────────────────────────────────────────
    void BuildBody()
    {
        var body = new Panel { Dock = DockStyle.Fill, Padding = new Padding(18, 14, 18, 10) };

        // ── Input card ────────────────────────────────────────────────────────
        _cardInputs = new Panel
        {
            Dock      = DockStyle.Top,
            Height    = 224,
            BackColor = C_CARD,
            Padding   = new Padding(22, 16, 22, 12),
        };
        StyleCard(_cardInputs);

        // Section label
        var secLabel = new Label
        {
            Text      = "Audit Configuration",
            Font      = new Font("Segoe UI", 10f, FontStyle.Bold),
            ForeColor = C_DARK,
            AutoSize  = true,
            Location  = new Point(22, 14),
        };
        var secLine = new Panel
        {
            Location  = new Point(22, 36),
            Size      = new Size(900, 1),
            BackColor = C_BORDER,
        };

        // Row 1: Repo Path + Browse
        var lRepo  = FieldLabel("Repository Path", 22, 50);
        _txtRepo   = FieldTextBox(22, 72, 730, @"e.g.  C:\repos\AOM-1NA1");
        _btnBrowse = MakeButton("Browse…", new Point(760, 71), new Size(100, 32),
            C_CARD, C_MID, bold: false, border: C_BORDER);
        _btnBrowse.Click += BtnBrowse_Click;

        // Row 2: LOB + SubLOB + Project
        var lLob   = FieldLabel("LOB", 22, 120);
        _cmbLob    = FieldCombo(22, 142, 200);
        _cmbLob.SelectedIndexChanged += CmbLob_Changed;

        var lSub   = FieldLabel("Sub LOB", 236, 120);
        _cmbSubLob = FieldCombo(236, 142, 220);
        _cmbSubLob.Enabled = false;

        var lProj  = FieldLabel("Project / Repo Name", 474, 120);
        _txtProject = FieldTextBox(474, 142, 386, "e.g.  AOM-1NA1");
        _txtProject.Width = 386;

        // Branch indicator (hidden until audit runs)
        _lblBranch = new Label
        {
            AutoSize  = true,
            Location  = new Point(22, 190),
            Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
            ForeColor = C_LOG_WARN,
            Text      = "",
            Visible   = false,
        };

        _cardInputs.Controls.AddRange(new Control[]
        {
            secLabel, secLine,
            lRepo, _txtRepo, _btnBrowse,
            lLob, _cmbLob,
            lSub, _cmbSubLob,
            lProj, _txtProject,
            _lblBranch,
        });

        // ── Log card ──────────────────────────────────────────────────────────
        _cardLog = new Panel
        {
            Dock      = DockStyle.Fill,
            BackColor = C_CARD,
            Padding   = new Padding(0),
            Margin    = new Padding(0, 12, 0, 0),
        };
        StyleCard(_cardLog);

        var logHeader = new Panel
        {
            Dock      = DockStyle.Top,
            Height    = 36,
            BackColor = C_DARK,
            Padding   = new Padding(14, 0, 14, 0),
        };
        var logTitle = new Label
        {
            Text      = "Audit Output",
            ForeColor = Color.White,
            Font      = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            AutoSize  = true,
            Location  = new Point(14, 9),
        };
        var logDot = new Label
        {
            Text      = "●",
            ForeColor = C_LOG_OK,
            Font      = new Font("Segoe UI", 8f),
            AutoSize  = true,
            Location  = new Point(110, 12),
        };
        logHeader.Controls.AddRange(new Control[] { logTitle, logDot });

        _rtbLog = new RichTextBox
        {
            Dock        = DockStyle.Fill,
            BackColor   = C_LOGBG,
            ForeColor   = C_LOG_INFO,
            Font        = new Font("Consolas", 9.5f),
            ReadOnly    = true,
            ScrollBars  = RichTextBoxScrollBars.Vertical,
            BorderStyle = BorderStyle.None,
            Padding     = new Padding(10, 8, 10, 8),
            WordWrap    = false,
        };
        // Try Cascadia Code for nicer look
        try { _rtbLog.Font = new Font("Cascadia Code", 9.5f); } catch { }

        _cardLog.Controls.Add(_rtbLog);
        _cardLog.Controls.Add(logHeader);

        body.Controls.Add(_cardLog);

        var gap = new Panel { Dock = DockStyle.Top, Height = 12, BackColor = C_BG };

        body.Controls.Add(gap);
        body.Controls.Add(_cardInputs);

        Controls.Add(body);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Data — LOB cascades
    // ─────────────────────────────────────────────────────────────────────────
    void LoadLobs()
    {
        _cmbLob.Items.Clear();
        _cmbLob.Items.Add("— Select LOB —");
        foreach (var lob in LobData.Lobs) _cmbLob.Items.Add(lob);
        _cmbLob.SelectedIndex = 0;
    }

    void CmbLob_Changed(object? s, EventArgs e)
    {
        _cmbSubLob.Items.Clear();
        _cmbSubLob.Enabled = false;
        if (_cmbLob.SelectedIndex <= 0) return;

        var subs = LobData.SubLobsFor(_cmbLob.SelectedItem!.ToString()!);
        if (subs.Count == 0) return;

        _cmbSubLob.Items.Add("— Select Sub LOB —");
        foreach (var s in subs) _cmbSubLob.Items.Add(s);
        _cmbSubLob.SelectedIndex = 0;
        _cmbSubLob.Enabled = true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Browse
    // ─────────────────────────────────────────────────────────────────────────
    void BtnBrowse_Click(object? s, EventArgs e)
    {
        using var dlg = new FolderBrowserDialog
        {
            Description            = "Select the local git repo folder (containing .git)",
            UseDescriptionForTitle = true,
            ShowNewFolderButton    = false,
        };
        if (!string.IsNullOrWhiteSpace(_txtRepo.Text) && Directory.Exists(_txtRepo.Text))
            dlg.InitialDirectory = _txtRepo.Text;

        if (dlg.ShowDialog() != DialogResult.OK) return;
        _txtRepo.Text = dlg.SelectedPath;
        if (string.IsNullOrWhiteSpace(_txtProject.Text))
            _txtProject.Text = Path.GetFileName(dlg.SelectedPath);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Validate
    // ─────────────────────────────────────────────────────────────────────────
    bool Validate(out string repo, out string project, out string lob, out string subLob)
    {
        repo    = _txtRepo.Text.Trim();
        project = _txtProject.Text.Trim();
        lob     = _cmbLob.SelectedIndex > 0 ? _cmbLob.SelectedItem!.ToString()! : "";
        subLob  = _cmbSubLob.SelectedIndex > 0 ? _cmbSubLob.SelectedItem!.ToString()! : "";

        var errs = new List<string>();
        if (string.IsNullOrWhiteSpace(repo))
            errs.Add("Repository path is required.");
        else if (!Directory.Exists(repo))
            errs.Add($"Repository path does not exist:\n{repo}");
        else if (!Directory.Exists(Path.Combine(repo, ".git")))
            errs.Add("Selected folder is not a git repository (.git folder not found).");

        if (string.IsNullOrWhiteSpace(lob) || lob.StartsWith("—"))
            errs.Add("Please select a LOB.");
        if (_cmbSubLob.Enabled && (string.IsNullOrWhiteSpace(subLob) || subLob.StartsWith("—")))
            errs.Add("Please select a Sub LOB.");
        if (string.IsNullOrWhiteSpace(project))
            errs.Add("Project / Repo Name is required.");

        if (errs.Count > 0)
        {
            using var dlg = new StyledMessageBox(
                "Missing Information",
                string.Join("\n\n", errs),
                MessageBoxType.Warning);
            dlg.ShowDialog(this);
            return false;
        }
        return true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Run Audit
    // ─────────────────────────────────────────────────────────────────────────
    void BtnRun_Click(object? s, EventArgs e)
    {
        if (_running)
        {
            try { _proc?.Kill(entireProcessTree: true); } catch { }
            SetRunning(false);
            AppendLog("⚠  Audit cancelled by user.", C_LOG_WARN);
            return;
        }

        if (!Validate(out var repo, out var project, out var lob, out var subLob)) return;

        var nodeExe  = FindNode();
        if (nodeExe == null)
        {
            using var d = new StyledMessageBox("Node.js Not Found",
                "node.exe was not found on this machine.\n\nInstall Node.js v16+ and ensure it is on your PATH.",
                MessageBoxType.Error);
            d.ShowDialog(this);
            return;
        }

        var auditJs = FindAuditJs();
        if (auditJs == null)
        {
            using var d = new StyledMessageBox("Audit Engine Not Found",
                "audit.js not found.\n\nEnsure the automation-audit folder is in the same directory as this launcher.",
                MessageBoxType.Error);
            d.ShowDialog(this);
            return;
        }

        _rtbLog.Clear();
        _branchWarningShown = false;
        _lblBranch.Visible  = false;

        var lobArg = string.IsNullOrWhiteSpace(subLob) || subLob.StartsWith("—")
            ? lob : $"{lob} / {subLob}";

        // Pass --no-branch-check so the CLI doesn't block on stdin;
        // the WinForms launcher handles the branch warning as a popup instead.
        var args = $"\"{auditJs}\" -r \"{repo}\" -p \"{project}\" -l \"{lobArg}\" --no-branch-check";

        LogHeader(project, repo, lobArg);
        SetRunning(true);

        _proc = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName               = nodeExe,
                Arguments              = args,
                WorkingDirectory       = Path.GetDirectoryName(auditJs)!,
                UseShellExecute        = false,
                RedirectStandardOutput = true,
                RedirectStandardError  = true,
                CreateNoWindow         = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding  = Encoding.UTF8,
            },
            EnableRaisingEvents = true,
        };

        _proc.OutputDataReceived += OnOutput;
        _proc.ErrorDataReceived  += OnError;
        _proc.Exited             += (_, _) => Invoke(OnExited);

        try { _proc.Start(); _proc.BeginOutputReadLine(); _proc.BeginErrorReadLine(); }
        catch (Exception ex) { SetRunning(false); AppendLog($"✖  {ex.Message}", C_LOG_ERR); }
    }

    void OnOutput(object s, DataReceivedEventArgs e)
    {
        if (e.Data == null) return;
        Invoke(() =>
        {
            // Detect branch warning in output — show a popup
            if (!_branchWarningShown && e.Data.Contains("NOT ON DEFAULT BRANCH"))
            {
                _branchWarningShown = true;
                ShowBranchWarningPopup(e.Data);
            }
            else if (e.Data.Contains("Current branch") && e.Data.Contains("Default branch"))
            {
                // Extract branch info for the inline indicator
                var cur = ExtractBetween(e.Data, "Current branch: '", "'");
                var def = ExtractBetween(e.Data, "Default branch: '", "'");
                if (!string.IsNullOrEmpty(cur) && cur != def)
                {
                    _lblBranch.Text    = $"⚠  Running on '{cur}' — default is '{def}'";
                    _lblBranch.Visible = true;
                }
            }
            InvokeLog(e.Data);
        });
    }

    void OnError(object s, DataReceivedEventArgs e)
    {
        if (e.Data != null) Invoke(() => AppendLog(e.Data, C_LOG_ERR));
    }

    void OnExited()
    {
        var code = _proc?.ExitCode ?? -1;
        AppendLog("");
        if (code == 0)
        {
            AppendLog("✅  Audit complete — report saved to the shared drive.", C_LOG_OK, bold: true);
            SetStatus("Audit complete ✔", C_LOG_OK);
        }
        else
        {
            AppendLog($"✖  Audit exited with code {code}. See output above.", C_LOG_ERR);
            SetStatus($"Failed (exit {code})", C_LOG_ERR);
        }
        SetRunning(false);
        _proc?.Dispose();
        _proc = null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Branch Warning Popup
    // ─────────────────────────────────────────────────────────────────────────
    void ShowBranchWarningPopup(string outputLine)
    {
        // We'll intercept the full warning from subsequent lines,
        // but we can also get branch names from the status label already set.
        var cur = _lblBranch.Visible
            ? ExtractBetween(_lblBranch.Text, "Running on '", "'")
            : "feature branch";
        var def = _lblBranch.Visible
            ? ExtractBetween(_lblBranch.Text, "default is '", "'")
            : "main";

        using var dlg = new BranchWarningDialog(cur, def);
        var result = dlg.ShowDialog(this);

        if (result == DialogResult.Cancel)
        {
            // User chose to abort — kill the process
            try { _proc?.Kill(entireProcessTree: true); } catch { }
            AppendLog("\n✖  Audit aborted by user — please switch to the default branch and re-run.", C_LOG_ERR);
            SetRunning(false);
        }
        else
        {
            AppendLog($"⚠  Proceeding on non-default branch '{cur}' — noted in report.", C_LOG_WARN);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Log helpers
    // ─────────────────────────────────────────────────────────────────────────
    void LogHeader(string project, string repo, string lob)
    {
        AppendLog("═══════════════════════════════════════════════════════════", C_LOG_DIM);
        AppendLog("  CATS Team  ·  Automation Audit Tool  v3.0", C_LOG_INFO, bold: true);
        AppendLog("═══════════════════════════════════════════════════════════", C_LOG_DIM);
        AppendLog($"  Project  :  {project}", C_LOG_INFO);
        AppendLog($"  Repo     :  {repo}", C_LOG_INFO);
        AppendLog($"  LOB      :  {lob}", C_LOG_INFO);
        AppendLog("═══════════════════════════════════════════════════════════\n", C_LOG_DIM);
    }

    void InvokeLog(string line)
    {
        var color = ClassifyColor(line);
        AppendLog(line, color);
    }

    void AppendLog(string text, Color? color = null, bool bold = false)
    {
        if (InvokeRequired) { Invoke(() => AppendLog(text, color, bold)); return; }
        color ??= C_LOG_INFO;
        _rtbLog.SelectionStart  = _rtbLog.TextLength;
        _rtbLog.SelectionLength = 0;
        _rtbLog.SelectionColor  = color.Value;
        _rtbLog.SelectionFont   = bold ? new Font(_rtbLog.Font, FontStyle.Bold) : _rtbLog.Font;
        _rtbLog.AppendText(text + "\n");
        _rtbLog.ScrollToCaret();
    }

    Color ClassifyColor(string line)
    {
        if (string.IsNullOrWhiteSpace(line))           return C_LOG_INFO;
        if (line.Contains("✅") || line.Contains("✔") || line.Contains("done") || line.Contains("complete"))
                                                        return C_LOG_OK;
        if (line.Contains("✖") || line.Contains("error") || line.Contains("Error") || line.Contains("failed"))
                                                        return C_LOG_ERR;
        if (line.Contains("⚠") || line.Contains("~") || line.Contains("Manual") || line.Contains("WARNING"))
                                                        return C_LOG_WARN;
        if (line.TrimStart().StartsWith("─") || line.TrimStart().StartsWith("═") ||
            line.TrimStart().StartsWith("╔") || line.TrimStart().StartsWith("╚") ||
            line.TrimStart().StartsWith("║"))           return C_LOG_DIM;
        if (line.TrimStart().StartsWith("📁") || line.TrimStart().StartsWith("📋") ||
            line.TrimStart().StartsWith("📂") || line.TrimStart().StartsWith("📊") ||
            line.TrimStart().StartsWith("🔍") || line.TrimStart().StartsWith("🔎") ||
            line.TrimStart().StartsWith("📐") || line.TrimStart().StartsWith("🏗") ||
            line.TrimStart().StartsWith("⚙") || line.TrimStart().StartsWith("🌿"))
                                                        return C_LOG_CMD;
        return C_LOG_INFO;
    }

    void SetStatus(string text, Color color)
    {
        if (InvokeRequired) { Invoke(() => SetStatus(text, color)); return; }
        _lblStatus.Text = text; _lblStatus.ForeColor = color;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Running state
    // ─────────────────────────────────────────────────────────────────────────
    void SetRunning(bool r)
    {
        if (InvokeRequired) { Invoke(() => SetRunning(r)); return; }
        _running            = r;
        _btnRun.Text        = r ? "⏹  Stop" : "▶  Run Audit";
        _btnRun.BackColor   = r ? Color.FromArgb(160, 40, 40) : C_RED;
        _progress.Visible   = r;
        _btnBrowse.Enabled  = !r;
        _cmbLob.Enabled     = !r;
        _cmbSubLob.Enabled  = !r && _cmbLob.SelectedIndex > 0;
        _txtRepo.Enabled    = !r;
        _txtProject.Enabled = !r;
        if (r) SetStatus("Running…", C_LOG_WARN);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Locate node + audit.js
    // ─────────────────────────────────────────────────────────────────────────
    static string? FindNode()
    {
        foreach (var dir in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
        {
            var c = Path.Combine(dir.Trim(), "node.exe");
            if (File.Exists(c)) return c;
        }
        string[] common =
        [
            @"C:\Program Files\nodejs\node.exe",
            @"C:\Program Files (x86)\nodejs\node.exe",
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), @"nvm\current\node.exe"),
        ];
        return common.FirstOrDefault(File.Exists);
    }

    static string? FindAuditJs()
    {
        var base_ = AppContext.BaseDirectory;
        string[] candidates =
        [
            Path.Combine(base_, "automation-audit", "audit.js"),
            Path.Combine(base_, "..", "automation-audit", "audit.js"),
            Path.Combine(base_, "audit.js"),
        ];
        return candidates.Select(Path.GetFullPath).FirstOrDefault(File.Exists);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Card styling
    // ─────────────────────────────────────────────────────────────────────────
    static void StyleCard(Panel p)
    {
        p.Paint += (s, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using var pen = new Pen(C_BORDER, 1);
            g.DrawRectangle(pen, 0, 0, p.Width - 1, p.Height - 1);
        };
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Control factories
    // ─────────────────────────────────────────────────────────────────────────
    static Label FieldLabel(string text, int x, int y) => new()
    {
        Text      = text,
        Location  = new Point(x, y),
        AutoSize  = true,
        Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
        ForeColor = C_LABEL,
    };

    static TextBox FieldTextBox(int x, int y, int w, string placeholder) => new()
    {
        Location        = new Point(x, y),
        Size            = new Size(w, 30),
        Font            = new Font("Segoe UI", 9.5f),
        PlaceholderText = placeholder,
        BorderStyle     = BorderStyle.FixedSingle,
        BackColor       = Color.White,
        ForeColor       = Color.FromArgb(25, 25, 25),
    };

    static ComboBox FieldCombo(int x, int y, int w) => new()
    {
        Location      = new Point(x, y),
        Size          = new Size(w, 30),
        DropDownStyle = ComboBoxStyle.DropDownList,
        Font          = new Font("Segoe UI", 9.5f),
        FlatStyle     = FlatStyle.Flat,
        BackColor     = Color.White,
    };

    static Button MakeButton(string text, Point loc, Size size,
        Color bg, Color fg, bool bold, Color? border = null)
    {
        var btn = new Button
        {
            Text      = text,
            Location  = loc,
            Size      = size,
            BackColor = bg,
            ForeColor = fg,
            FlatStyle = FlatStyle.Flat,
            Cursor    = Cursors.Hand,
            Font      = bold ? new Font("Segoe UI", 9.5f, FontStyle.Bold)
                              : new Font("Segoe UI", 9.5f),
        };
        btn.FlatAppearance.BorderSize  = border.HasValue ? 1 : 0;
        btn.FlatAppearance.BorderColor = border ?? bg;
        return btn;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Utility
    // ─────────────────────────────────────────────────────────────────────────
    static string ExtractBetween(string s, string open, string close)
    {
        var i = s.IndexOf(open, StringComparison.Ordinal);
        if (i < 0) return "";
        i += open.Length;
        var j = s.IndexOf(close, i, StringComparison.Ordinal);
        return j < 0 ? "" : s[i..j];
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (_running)
        {
            using var dlg = new StyledMessageBox("Audit Running",
                "An audit is still running. Stop it and exit?",
                MessageBoxType.Warning, showCancel: true);
            if (dlg.ShowDialog(this) != DialogResult.OK) { e.Cancel = true; return; }
            try { _proc?.Kill(entireProcessTree: true); } catch { }
        }
        base.OnFormClosing(e);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Branch Warning Dialog
// ─────────────────────────────────────────────────────────────────────────────
public class BranchWarningDialog : Form
{
    static readonly Color C_DARK = Color.FromArgb(21, 40, 76);
    static readonly Color C_GOLD = Color.FromArgb(181, 146, 43);
    static readonly Color C_RED  = Color.FromArgb(211, 32, 41);
    static readonly Color C_WARN = Color.FromArgb(255, 248, 230);

    public BranchWarningDialog(string currentBranch, string defaultBranch)
    {
        Text            = "Branch Warning";
        Size            = new Size(520, 300);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition   = FormStartPosition.CenterParent;
        MaximizeBox     = false;
        MinimizeBox     = false;
        BackColor       = C_WARN;
        Font            = new Font("Segoe UI", 9.5f);

        // Icon strip
        var strip = new Panel { Dock = DockStyle.Left, Width = 8, BackColor = C_GOLD };

        // Warning icon label
        var icon = new Label
        {
            Text      = "⚠",
            Font      = new Font("Segoe UI", 36f),
            ForeColor = C_GOLD,
            AutoSize  = true,
            Location  = new Point(30, 30),
        };

        // Title
        var title = new Label
        {
            Text      = "Not on Default Branch",
            Font      = new Font("Segoe UI", 13f, FontStyle.Bold),
            ForeColor = C_DARK,
            AutoSize  = true,
            Location  = new Point(88, 28),
        };

        // Details
        var body = new Label
        {
            Text = $"You are currently on branch:\n    '{currentBranch}'\n\n" +
                   $"The detected default branch is:\n    '{defaultBranch}'\n\n" +
                   "Auditing a non-default branch may produce results that don't\n" +
                   "reflect the production codebase. This will be noted in the report.",
            Font      = new Font("Segoe UI", 9.5f),
            ForeColor = Color.FromArgb(50, 50, 50),
            AutoSize  = false,
            Size      = new Size(390, 160),
            Location  = new Point(88, 60),
        };

        // Buttons
        var btnContinue = new Button
        {
            Text        = "Continue Anyway",
            Size        = new Size(150, 36),
            Location    = new Point(88, 224),
            DialogResult = DialogResult.OK,
            BackColor   = C_DARK,
            ForeColor   = Color.White,
            FlatStyle   = FlatStyle.Flat,
            Font        = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Cursor      = Cursors.Hand,
        };
        btnContinue.FlatAppearance.BorderSize = 0;

        var btnAbort = new Button
        {
            Text         = "Abort & Switch Branch",
            Size         = new Size(170, 36),
            Location     = new Point(252, 224),
            DialogResult = DialogResult.Cancel,
            BackColor    = C_RED,
            ForeColor    = Color.White,
            FlatStyle    = FlatStyle.Flat,
            Font         = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Cursor       = Cursors.Hand,
        };
        btnAbort.FlatAppearance.BorderSize = 0;

        var hint = new Label
        {
            Text      = $"Run:  git checkout {defaultBranch}",
            Font      = new Font("Consolas", 8.5f),
            ForeColor = Color.FromArgb(100, 100, 100),
            AutoSize  = true,
            Location  = new Point(252, 264),
        };

        Controls.AddRange(new Control[] { strip, icon, title, body, btnContinue, btnAbort, hint });
        AcceptButton = btnContinue;
        CancelButton = btnAbort;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Styled Message Box (replaces plain MessageBox)
// ─────────────────────────────────────────────────────────────────────────────
public enum MessageBoxType { Info, Warning, Error }

public class StyledMessageBox : Form
{
    static readonly Color C_DARK = Color.FromArgb(21, 40, 76);
    static readonly Color C_RED  = Color.FromArgb(211, 32, 41);

    public StyledMessageBox(string title, string message, MessageBoxType type, bool showCancel = false)
    {
        var (accent, icon, iconColor) = type switch
        {
            MessageBoxType.Error   => (C_RED,                        "✖", C_RED),
            MessageBoxType.Warning => (Color.FromArgb(181, 146, 43), "⚠", Color.FromArgb(181, 146, 43)),
            _                      => (C_DARK,                       "ℹ", C_DARK),
        };

        Text            = title;
        Size            = new Size(460, 230);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition   = FormStartPosition.CenterParent;
        MaximizeBox     = false; MinimizeBox = false;
        BackColor       = Color.White;
        Font            = new Font("Segoe UI", 9.5f);

        var strip = new Panel { Dock = DockStyle.Top, Height = 4, BackColor = accent };

        var icnLbl = new Label
        {
            Text      = icon,
            Font      = new Font("Segoe UI", 24f),
            ForeColor = iconColor,
            AutoSize  = true,
            Location  = new Point(20, 22),
        };

        var hdr = new Label
        {
            Text      = title,
            Font      = new Font("Segoe UI", 11f, FontStyle.Bold),
            ForeColor = C_DARK,
            AutoSize  = true,
            Location  = new Point(60, 20),
        };

        var msg = new Label
        {
            Text      = message,
            Font      = new Font("Segoe UI", 9.5f),
            ForeColor = Color.FromArgb(50, 50, 50),
            AutoSize  = false,
            Size      = new Size(400, 90),
            Location  = new Point(60, 50),
        };

        var btnOk = new Button
        {
            Text         = showCancel ? "Yes, Stop" : "OK",
            Size         = new Size(100, 34),
            Location     = new Point(showCancel ? 240 : 340, 158),
            DialogResult = DialogResult.OK,
            BackColor    = accent,
            ForeColor    = Color.White,
            FlatStyle    = FlatStyle.Flat,
            Font         = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Cursor       = Cursors.Hand,
        };
        btnOk.FlatAppearance.BorderSize = 0;

        Controls.AddRange(new Control[] { strip, icnLbl, hdr, msg, btnOk });

        if (showCancel)
        {
            var btnNo = new Button
            {
                Text         = "Cancel",
                Size         = new Size(100, 34),
                Location     = new Point(350, 158),
                DialogResult = DialogResult.Cancel,
                BackColor    = Color.White,
                ForeColor    = C_DARK,
                FlatStyle    = FlatStyle.Flat,
                Font         = new Font("Segoe UI", 9.5f),
                Cursor       = Cursors.Hand,
            };
            btnNo.FlatAppearance.BorderColor = Color.FromArgb(200, 210, 225);
            btnNo.FlatAppearance.BorderSize  = 1;
            Controls.Add(btnNo);
            CancelButton = btnNo;
        }
        AcceptButton = btnOk;
    }
}

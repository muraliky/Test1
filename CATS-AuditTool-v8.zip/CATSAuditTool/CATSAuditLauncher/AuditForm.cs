using System.Diagnostics;
using System.Text;
using System.Drawing.Drawing2D;

namespace CATSAuditLauncher;

// ─────────────────────────────────────────────────────────────────────────────
// Main Form
// ─────────────────────────────────────────────────────────────────────────────
public class AuditForm : Form
{
    // ── Controls ──────────────────────────────────────────────────────────────
    private Panel       _header     = null!;
    private Panel       _cardInputs = null!;
    private Panel       _cardLog    = null!;
    private Panel       _footer     = null!;
    private TextBox     _txtRepo    = null!;
    private Button      _btnBrowse  = null!;
    private ComboBox    _cmbLob     = null!;
    private ComboBox    _cmbSubLob  = null!;
    private TextBox     _txtProject = null!;
    private RichTextBox _rtbLog     = null!;
    private Button      _btnRun     = null!;
    private Button      _btnClear   = null!;
    private ProgressBar _progress   = null!;
    private Label       _lblStatus  = null!;
    private Label       _lblBranch  = null!;

    // ── State ─────────────────────────────────────────────────────────────────
    private Process? _proc;
    private bool     _running;
    private bool     _branchWarningShown;

    // ── Palette ───────────────────────────────────────────────────────────────
    static readonly Color CLR_RED      = Color.FromArgb(211, 32,  41);
    static readonly Color CLR_RED_HOV  = Color.FromArgb(175, 20,  28);
    static readonly Color CLR_GOLD     = Color.FromArgb(181, 146, 43);
    static readonly Color CLR_DARK     = Color.FromArgb(21,  40,  76);
    static readonly Color CLR_MID      = Color.FromArgb(37,  71, 123);
    static readonly Color CLR_BG       = Color.FromArgb(240, 244, 250);
    static readonly Color CLR_CARD     = Color.FromArgb(255, 255, 255);
    static readonly Color CLR_BORDER   = Color.FromArgb(210, 220, 235);
    static readonly Color CLR_LABEL    = Color.FromArgb(50,  70, 110);
    static readonly Color CLR_LOGBG    = Color.FromArgb(13,  22,  40);
    static readonly Color CLR_LOG_OK   = Color.FromArgb(72,  199, 116);
    static readonly Color CLR_LOG_ERR  = Color.FromArgb(255,  90,  90);
    static readonly Color CLR_LOG_WARN = Color.FromArgb(255, 200,  50);
    static readonly Color CLR_LOG_INFO = Color.FromArgb(180, 210, 255);
    static readonly Color CLR_LOG_DIM  = Color.FromArgb(110, 135, 170);
    static readonly Color CLR_LOG_CMD  = Color.FromArgb(130, 180, 255);

    // ─────────────────────────────────────────────────────────────────────────
    public AuditForm()
    {
        BuildUI();
        LoadLobs();
        AppendLog("Ready — fill in the fields above and click Run Audit.", CLR_LOG_DIM);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Build UI
    // ─────────────────────────────────────────────────────────────────────────
    void BuildUI()
    {
        SuspendLayout();
        Text            = "CATS Team  ·  Automation Audit Launcher";
        Size            = new Size(980, 820);
        MinimumSize     = new Size(880, 700);
        StartPosition   = FormStartPosition.CenterScreen;
        BackColor       = CLR_BG;
        Font            = new Font("Segoe UI", 9.5f);
        FormBorderStyle = FormBorderStyle.Sizable;

        BuildHeader();
        BuildFooter();
        BuildBody();

        ResumeLayout(true);
    }

    // ── Header ────────────────────────────────────────────────────────────────
    void BuildHeader()
    {
        _header = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = CLR_DARK };

        var accent = new Panel { Dock = DockStyle.Bottom, Height = 4, BackColor = CLR_GOLD };

        var lblCats = new Label
        {
            Text      = "CATS",
            Font      = new Font("Segoe UI", 22f, FontStyle.Bold),
            ForeColor = CLR_RED,
            AutoSize  = true,
            Location  = new Point(24, 18),
        };
        var lblTitle = new Label
        {
            Text      = "Team  ·  Automation Audit Launcher",
            Font      = new Font("Segoe UI", 18f, FontStyle.Regular),
            ForeColor = Color.White,
            AutoSize  = true,
            Location  = new Point(92, 21),
        };
        var lblSub = new Label
        {
            Text      = "Center of Excellence – Automation & Tools Squad  |  v3.0",
            Font      = new Font("Segoe UI", 8.5f, FontStyle.Italic),
            ForeColor = Color.FromArgb(150, 180, 220),
            AutoSize  = true,
            Location  = new Point(26, 56),
        };

        _header.Controls.AddRange(new Control[] { lblCats, lblTitle, lblSub, accent });
        Controls.Add(_header);
    }

    // ── Footer ────────────────────────────────────────────────────────────────
    void BuildFooter()
    {
        _footer = new Panel
        {
            Dock      = DockStyle.Bottom,
            Height    = 58,
            BackColor = CLR_CARD,
            Padding   = new Padding(20, 10, 20, 10),
        };
        var topLine = new Panel { Dock = DockStyle.Top, Height = 1, BackColor = CLR_BORDER };

        _btnRun = MakeButton("▶  Run Audit", new Point(20, 11), new Size(148, 36),
            CLR_RED, Color.White, bold: true);
        _btnRun.Click      += BtnRun_Click;
        _btnRun.MouseEnter += (_, _) => { if (!_running) _btnRun.BackColor = CLR_RED_HOV; };
        _btnRun.MouseLeave += (_, _) => { if (!_running) _btnRun.BackColor = CLR_RED; };

        _btnClear = MakeButton("Clear Log", new Point(178, 11), new Size(100, 36),
            CLR_CARD, CLR_MID, bold: false, border: CLR_BORDER);
        _btnClear.Click += (_, _) =>
        {
            _rtbLog.Clear();
            AppendLog("Log cleared.", CLR_LOG_DIM);
        };

        _progress = new ProgressBar
        {
            Location              = new Point(296, 17),
            Size                  = new Size(280, 22),
            Style                 = ProgressBarStyle.Marquee,
            MarqueeAnimationSpeed = 30,
            Visible               = false,
        };

        _lblStatus = new Label
        {
            Location  = new Point(596, 18),
            AutoSize  = true,
            ForeColor = CLR_LOG_DIM,
            Font      = new Font("Segoe UI", 9f, FontStyle.Italic),
            Text      = "Ready",
        };

        _footer.Controls.AddRange(new Control[] { topLine, _btnRun, _btnClear, _progress, _lblStatus });
        Controls.Add(_footer);
    }

    // ── Body ──────────────────────────────────────────────────────────────────
    void BuildBody()
    {
        var body = new Panel { Dock = DockStyle.Fill, Padding = new Padding(18, 14, 18, 10) };

        // Input card
        _cardInputs = new Panel
        {
            Dock      = DockStyle.Top,
            Height    = 224,
            BackColor = CLR_CARD,
            Padding   = new Padding(22, 16, 22, 12),
        };
        StyleCard(_cardInputs);

        var secLabel = new Label
        {
            Text      = "Audit Configuration",
            Font      = new Font("Segoe UI", 10f, FontStyle.Bold),
            ForeColor = CLR_DARK,
            AutoSize  = true,
            Location  = new Point(22, 14),
        };
        var secLine = new Panel
        {
            Location  = new Point(22, 36),
            Size      = new Size(900, 1),
            BackColor = CLR_BORDER,
        };

        // Row 1: Repo Path + Browse
        var lRepo  = FieldLabel("Repository Path", 22, 50);
        _txtRepo   = FieldTextBox(22, 72, 730, @"e.g.  C:\repos\AOM-1NA1");
        _btnBrowse = MakeButton("Browse…", new Point(760, 71), new Size(100, 32),
            CLR_CARD, CLR_MID, bold: false, border: CLR_BORDER);
        _btnBrowse.Click += BtnBrowse_Click;

        // Row 2: LOB + Sub LOB + Project
        var lLob   = FieldLabel("LOB", 22, 120);
        _cmbLob    = FieldCombo(22, 142, 200);
        _cmbLob.SelectedIndexChanged += CmbLob_Changed;

        var lSub   = FieldLabel("Sub LOB", 236, 120);
        _cmbSubLob = FieldCombo(236, 142, 220);
        _cmbSubLob.Enabled = false;

        var lProj  = FieldLabel("Project / Repo Name", 474, 120);
        _txtProject = FieldTextBox(474, 142, 386, "e.g.  AOM-1NA1");

        _lblBranch = new Label
        {
            AutoSize  = true,
            Location  = new Point(22, 190),
            Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
            ForeColor = CLR_LOG_WARN,
            Text      = "",
            Visible   = false,
        };

        _cardInputs.Controls.AddRange(new Control[]
        {
            secLabel, secLine,
            lRepo, _txtRepo, _btnBrowse,
            lLob, _cmbLob,
            lSub, _cmbSubLob,
            lProj, _txtProject,
            _lblBranch,
        });

        // Log card
        _cardLog = new Panel
        {
            Dock      = DockStyle.Fill,
            BackColor = CLR_CARD,
        };
        StyleCard(_cardLog);

        var logHeader = new Panel
        {
            Dock      = DockStyle.Top,
            Height    = 36,
            BackColor = CLR_DARK,
        };
        var logTitle = new Label
        {
            Text      = "Audit Output",
            ForeColor = Color.White,
            Font      = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            AutoSize  = true,
            Location  = new Point(14, 9),
        };
        var logDot = new Label
        {
            Text      = "●",
            ForeColor = CLR_LOG_OK,
            Font      = new Font("Segoe UI", 8f),
            AutoSize  = true,
            Location  = new Point(110, 12),
        };
        logHeader.Controls.AddRange(new Control[] { logTitle, logDot });

        _rtbLog = new RichTextBox
        {
            Dock        = DockStyle.Fill,
            BackColor   = CLR_LOGBG,
            ForeColor   = CLR_LOG_INFO,
            Font        = new Font("Consolas", 9.5f),
            ReadOnly    = true,
            ScrollBars  = RichTextBoxScrollBars.Vertical,
            BorderStyle = BorderStyle.None,
            Padding     = new Padding(10, 8, 10, 8),
            WordWrap    = false,
        };
        try { _rtbLog.Font = new Font("Cascadia Code", 9.5f); } catch { /* fallback to Consolas */ }

        _cardLog.Controls.Add(_rtbLog);
        _cardLog.Controls.Add(logHeader);

        var gap = new Panel { Dock = DockStyle.Top, Height = 12, BackColor = CLR_BG };

        body.Controls.Add(_cardLog);
        body.Controls.Add(gap);
        body.Controls.Add(_cardInputs);

        Controls.Add(body);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LOB cascade
    // ─────────────────────────────────────────────────────────────────────────
    void LoadLobs()
    {
        _cmbLob.Items.Clear();
        _cmbLob.Items.Add("— Select LOB —");
        foreach (var lobName in LobData.Lobs)
            _cmbLob.Items.Add(lobName);
        _cmbLob.SelectedIndex = 0;
    }

    // NOTE: parameter renamed to 'sender' and 'evt' to avoid conflict
    // with 'subName' loop variable below
    void CmbLob_Changed(object? sender, EventArgs evt)
    {
        _cmbSubLob.Items.Clear();
        _cmbSubLob.Enabled = false;
        if (_cmbLob.SelectedIndex <= 0) return;

        var selectedLob = _cmbLob.SelectedItem!.ToString()!;
        var subs = LobData.SubLobsFor(selectedLob);
        if (subs.Count == 0) return;

        _cmbSubLob.Items.Add("— Select Sub LOB —");
        foreach (var subName in subs)          // 'subName' — no conflict with 'sender'
            _cmbSubLob.Items.Add(subName);
        _cmbSubLob.SelectedIndex = 0;
        _cmbSubLob.Enabled = true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Browse
    // ─────────────────────────────────────────────────────────────────────────
    void BtnBrowse_Click(object? sender, EventArgs evt)
    {
        using var dlg = new FolderBrowserDialog
        {
            Description            = "Select the local git repo folder (containing .git)",
            UseDescriptionForTitle = true,
            ShowNewFolderButton    = false,
        };
        if (!string.IsNullOrWhiteSpace(_txtRepo.Text) && Directory.Exists(_txtRepo.Text))
            dlg.InitialDirectory = _txtRepo.Text;

        if (dlg.ShowDialog() != DialogResult.OK) return;

        _txtRepo.Text = dlg.SelectedPath;
        if (string.IsNullOrWhiteSpace(_txtProject.Text))
            _txtProject.Text = Path.GetFileName(dlg.SelectedPath);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Validate inputs
    // ─────────────────────────────────────────────────────────────────────────
    bool ValidateInputs(out string repo, out string project, out string lob, out string subLob)
    {
        repo    = _txtRepo.Text.Trim();
        project = _txtProject.Text.Trim();
        lob     = _cmbLob.SelectedIndex > 0 ? _cmbLob.SelectedItem!.ToString()! : "";
        subLob  = _cmbSubLob.SelectedIndex > 0 ? _cmbSubLob.SelectedItem!.ToString()! : "";

        var errors = new List<string>();

        if (string.IsNullOrWhiteSpace(repo))
            errors.Add("Repository path is required.");
        else if (!Directory.Exists(repo))
            errors.Add($"Repository path does not exist:\n{repo}");
        else if (!Directory.Exists(Path.Combine(repo, ".git")))
            errors.Add("Selected folder is not a git repository (.git folder not found).");

        if (string.IsNullOrWhiteSpace(lob) || lob.StartsWith("—"))
            errors.Add("Please select a LOB.");

        if (_cmbSubLob.Enabled && (string.IsNullOrWhiteSpace(subLob) || subLob.StartsWith("—")))
            errors.Add("Please select a Sub LOB.");

        if (string.IsNullOrWhiteSpace(project))
            errors.Add("Project / Repo Name is required.");

        if (errors.Count == 0) return true;

        using var msgDlg = new StyledMessageBox(
            "Missing Information",
            string.Join("\n\n", errors),
            MsgBoxType.Warning);
        msgDlg.ShowDialog(this);
        return false;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Run audit
    // ─────────────────────────────────────────────────────────────────────────
    void BtnRun_Click(object? sender, EventArgs evt)
    {
        if (_running)
        {
            try { _proc?.Kill(entireProcessTree: true); } catch { /* ignore */ }
            SetRunning(false);
            AppendLog("⚠  Audit cancelled by user.", CLR_LOG_WARN);
            return;
        }

        if (!ValidateInputs(out var repo, out var project, out var lob, out var subLob))
            return;

        var nodeExe = FindNode();
        if (nodeExe == null)
        {
            using var nodeDlg = new StyledMessageBox(
                "Node.js Not Found",
                "node.exe was not found.\n\nInstall Node.js v16+ and ensure it is on your PATH.",
                MsgBoxType.Error);
            nodeDlg.ShowDialog(this);
            return;
        }

        var auditJs = FindAuditJs();
        if (auditJs == null)
        {
            using var jsDlg = new StyledMessageBox(
                "Audit Engine Not Found",
                "audit.js not found.\n\nEnsure the automation-audit folder is next to this launcher.",
                MsgBoxType.Error);
            jsDlg.ShowDialog(this);
            return;
        }

        _rtbLog.Clear();
        _branchWarningShown = false;
        _lblBranch.Visible  = false;

        var lobArg = string.IsNullOrWhiteSpace(subLob) || subLob.StartsWith("—")
            ? lob
            : $"{lob} / {subLob}";

        var args = $"\"{auditJs}\" -r \"{repo}\" -p \"{project}\" -l \"{lobArg}\" --no-branch-check";

        LogHeader(project, repo, lobArg);
        SetRunning(true);

        _proc = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName               = nodeExe,
                Arguments              = args,
                WorkingDirectory       = Path.GetDirectoryName(auditJs)!,
                UseShellExecute        = false,
                RedirectStandardOutput = true,
                RedirectStandardError  = true,
                CreateNoWindow         = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding  = Encoding.UTF8,
            },
            EnableRaisingEvents = true,
        };

        _proc.OutputDataReceived += ProcOutputReceived;
        _proc.ErrorDataReceived  += ProcErrorReceived;
        _proc.Exited             += (_, _) => Invoke(ProcExited);

        try
        {
            _proc.Start();
            _proc.BeginOutputReadLine();
            _proc.BeginErrorReadLine();
        }
        catch (Exception ex)
        {
            SetRunning(false);
            AppendLog($"✖  Failed to start: {ex.Message}", CLR_LOG_ERR);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Process callbacks — parameter names chosen to avoid all CS0136 conflicts
    // ─────────────────────────────────────────────────────────────────────────
    void ProcOutputReceived(object proc, DataReceivedEventArgs args)
    {
        if (args.Data == null) return;
        var line = args.Data;          // capture before cross-thread invoke
        Invoke(() =>
        {
            if (!_branchWarningShown && line.Contains("NOT ON DEFAULT BRANCH"))
            {
                _branchWarningShown = true;
                ShowBranchPopup();
            }
            else if (line.Contains("Current branch") && line.Contains("Default branch"))
            {
                var cur = ExtractBetween(line, "Current branch: '", "'");
                var def = ExtractBetween(line, "Default branch: '",  "'");
                if (!string.IsNullOrEmpty(cur) && cur != def)
                {
                    _lblBranch.Text    = $"⚠  Running on '{cur}' — default is '{def}'";
                    _lblBranch.Visible = true;
                }
            }
            ColorLog(line);
        });
    }

    void ProcErrorReceived(object proc, DataReceivedEventArgs args)
    {
        if (args.Data == null) return;
        var line = args.Data;
        Invoke(() => AppendLog(line, CLR_LOG_ERR));
    }

    void ProcExited()
    {
        var code = _proc?.ExitCode ?? -1;
        AppendLog("");
        if (code == 0)
        {
            AppendLog("✅  Audit complete — report saved to the shared drive.", CLR_LOG_OK, bold: true);
            SetStatus("Audit complete ✔", CLR_LOG_OK);
        }
        else
        {
            AppendLog($"✖  Audit exited with code {code}. See output above.", CLR_LOG_ERR);
            SetStatus($"Failed (exit {code})", CLR_LOG_ERR);
        }
        SetRunning(false);
        _proc?.Dispose();
        _proc = null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Branch warning popup
    // ─────────────────────────────────────────────────────────────────────────
    void ShowBranchPopup()
    {
        var cur = _lblBranch.Visible
            ? ExtractBetween(_lblBranch.Text, "Running on '", "'")
            : "feature branch";
        var def = _lblBranch.Visible
            ? ExtractBetween(_lblBranch.Text, "default is '", "'")
            : "main";

        using var dlg = new BranchWarningDialog(cur, def);
        var result = dlg.ShowDialog(this);

        if (result == DialogResult.Cancel)
        {
            try { _proc?.Kill(entireProcessTree: true); } catch { /* ignore */ }
            AppendLog("\n✖  Audit aborted — switch to the default branch and re-run.", CLR_LOG_ERR);
            SetRunning(false);
        }
        else
        {
            AppendLog($"⚠  Proceeding on non-default branch '{cur}' — noted in report.", CLR_LOG_WARN);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Log helpers
    // ─────────────────────────────────────────────────────────────────────────
    void LogHeader(string project, string repo, string lob)
    {
        AppendLog("═══════════════════════════════════════════════════════════", CLR_LOG_DIM);
        AppendLog("  CATS Team  ·  Automation Audit Tool  v3.0", CLR_LOG_INFO, bold: true);
        AppendLog("═══════════════════════════════════════════════════════════", CLR_LOG_DIM);
        AppendLog($"  Project  :  {project}", CLR_LOG_INFO);
        AppendLog($"  Repo     :  {repo}",    CLR_LOG_INFO);
        AppendLog($"  LOB      :  {lob}",     CLR_LOG_INFO);
        AppendLog("═══════════════════════════════════════════════════════════\n", CLR_LOG_DIM);
    }

    void ColorLog(string text) => AppendLog(text, ClassifyColor(text));

    void AppendLog(string text, Color? color = null, bool bold = false)
    {
        if (InvokeRequired) { Invoke(() => AppendLog(text, color, bold)); return; }

        color ??= CLR_LOG_INFO;
        _rtbLog.SelectionStart  = _rtbLog.TextLength;
        _rtbLog.SelectionLength = 0;
        _rtbLog.SelectionColor  = color.Value;
        _rtbLog.SelectionFont   = bold
            ? new Font(_rtbLog.Font, FontStyle.Bold)
            : _rtbLog.Font;
        _rtbLog.AppendText(text + "\n");
        _rtbLog.ScrollToCaret();
    }

    Color ClassifyColor(string line)
    {
        if (string.IsNullOrWhiteSpace(line))                                        return CLR_LOG_INFO;
        if (line.Contains("✅") || line.Contains("✔") || line.Contains("done")
            || line.Contains("complete"))                                            return CLR_LOG_OK;
        if (line.Contains("✖") || line.Contains("error") || line.Contains("Error")
            || line.Contains("failed"))                                              return CLR_LOG_ERR;
        if (line.Contains("⚠") || line.Contains("~") || line.Contains("Manual")
            || line.Contains("WARNING"))                                             return CLR_LOG_WARN;
        if (line.TrimStart().StartsWith("─") || line.TrimStart().StartsWith("═")
            || line.TrimStart().StartsWith("╔") || line.TrimStart().StartsWith("╚")
            || line.TrimStart().StartsWith("║"))                                    return CLR_LOG_DIM;
        if (line.TrimStart().StartsWith("📁") || line.TrimStart().StartsWith("📋")
            || line.TrimStart().StartsWith("📂") || line.TrimStart().StartsWith("📊")
            || line.TrimStart().StartsWith("🔍") || line.TrimStart().StartsWith("🔎")
            || line.TrimStart().StartsWith("📐") || line.TrimStart().StartsWith("🏗")
            || line.TrimStart().StartsWith("⚙")  || line.TrimStart().StartsWith("🌿"))
                                                                                    return CLR_LOG_CMD;
        return CLR_LOG_INFO;
    }

    void SetStatus(string text, Color color)
    {
        if (InvokeRequired) { Invoke(() => SetStatus(text, color)); return; }
        _lblStatus.Text      = text;
        _lblStatus.ForeColor = color;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Running state
    // ─────────────────────────────────────────────────────────────────────────
    void SetRunning(bool isRunning)
    {
        if (InvokeRequired) { Invoke(() => SetRunning(isRunning)); return; }

        _running             = isRunning;
        _btnRun.Text         = isRunning ? "⏹  Stop" : "▶  Run Audit";
        _btnRun.BackColor    = isRunning ? Color.FromArgb(160, 40, 40) : CLR_RED;
        _progress.Visible    = isRunning;
        _btnBrowse.Enabled   = !isRunning;
        _cmbLob.Enabled      = !isRunning;
        _cmbSubLob.Enabled   = !isRunning && _cmbLob.SelectedIndex > 0;
        _txtRepo.Enabled     = !isRunning;
        _txtProject.Enabled  = !isRunning;

        if (isRunning) SetStatus("Running…", CLR_LOG_WARN);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Find executables
    // ─────────────────────────────────────────────────────────────────────────
    static string? FindNode()
    {
        foreach (var dir in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
        {
            var candidate = Path.Combine(dir.Trim(), "node.exe");
            if (File.Exists(candidate)) return candidate;
        }
        string[] wellKnown =
        [
            @"C:\Program Files\nodejs\node.exe",
            @"C:\Program Files (x86)\nodejs\node.exe",
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                         @"nvm\current\node.exe"),
        ];
        return wellKnown.FirstOrDefault(File.Exists);
    }

    static string? FindAuditJs()
    {
        var baseDir = AppContext.BaseDirectory;
        string[] candidates =
        [
            Path.Combine(baseDir, "automation-audit", "audit.js"),
            Path.Combine(baseDir, "..", "automation-audit", "audit.js"),
            Path.Combine(baseDir, "audit.js"),
        ];
        return candidates.Select(Path.GetFullPath).FirstOrDefault(File.Exists);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Card border paint
    // ─────────────────────────────────────────────────────────────────────────
    static void StyleCard(Panel panel)
    {
        panel.Paint += (paintSender, paintArgs) =>
        {
            var g = paintArgs.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using var pen = new Pen(CLR_BORDER, 1);
            g.DrawRectangle(pen, 0, 0, panel.Width - 1, panel.Height - 1);
        };
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Control factories
    // ─────────────────────────────────────────────────────────────────────────
    static Label FieldLabel(string text, int x, int y) => new()
    {
        Text      = text,
        Location  = new Point(x, y),
        AutoSize  = true,
        Font      = new Font("Segoe UI", 8.5f, FontStyle.Bold),
        ForeColor = CLR_LABEL,
    };

    static TextBox FieldTextBox(int x, int y, int w, string placeholder) => new()
    {
        Location        = new Point(x, y),
        Size            = new Size(w, 30),
        Font            = new Font("Segoe UI", 9.5f),
        PlaceholderText = placeholder,
        BorderStyle     = BorderStyle.FixedSingle,
        BackColor       = Color.White,
        ForeColor       = Color.FromArgb(25, 25, 25),
    };

    static ComboBox FieldCombo(int x, int y, int w) => new()
    {
        Location      = new Point(x, y),
        Size          = new Size(w, 30),
        DropDownStyle = ComboBoxStyle.DropDownList,
        Font          = new Font("Segoe UI", 9.5f),
        FlatStyle     = FlatStyle.Flat,
        BackColor     = Color.White,
    };

    static Button MakeButton(string text, Point loc, Size size,
        Color bg, Color fg, bool bold, Color? border = null)
    {
        var btn = new Button
        {
            Text      = text,
            Location  = loc,
            Size      = size,
            BackColor = bg,
            ForeColor = fg,
            FlatStyle = FlatStyle.Flat,
            Cursor    = Cursors.Hand,
            Font      = bold
                ? new Font("Segoe UI", 9.5f, FontStyle.Bold)
                : new Font("Segoe UI", 9.5f),
        };
        btn.FlatAppearance.BorderSize  = border.HasValue ? 1 : 0;
        btn.FlatAppearance.BorderColor = border ?? bg;
        return btn;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Utility
    // ─────────────────────────────────────────────────────────────────────────
    static string ExtractBetween(string input, string open, string close)
    {
        var startIdx = input.IndexOf(open, StringComparison.Ordinal);
        if (startIdx < 0) return "";
        startIdx += open.Length;
        var endIdx = input.IndexOf(close, startIdx, StringComparison.Ordinal);
        return endIdx < 0 ? "" : input[startIdx..endIdx];
    }

    protected override void OnFormClosing(FormClosingEventArgs closeArgs)
    {
        if (_running)
        {
            using var dlg = new StyledMessageBox(
                "Audit Running",
                "An audit is still running. Stop it and exit?",
                MsgBoxType.Warning,
                showCancel: true);
            if (dlg.ShowDialog(this) != DialogResult.OK)
            {
                closeArgs.Cancel = true;
                return;
            }
            try { _proc?.Kill(entireProcessTree: true); } catch { /* ignore */ }
        }
        base.OnFormClosing(closeArgs);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Branch Warning Dialog
// ─────────────────────────────────────────────────────────────────────────────
public class BranchWarningDialog : Form
{
    static readonly Color DLG_DARK = Color.FromArgb(21, 40, 76);
    static readonly Color DLG_GOLD = Color.FromArgb(181, 146, 43);
    static readonly Color DLG_RED  = Color.FromArgb(211, 32, 41);
    static readonly Color DLG_WARN = Color.FromArgb(255, 248, 230);

    public BranchWarningDialog(string currentBranch, string defaultBranch)
    {
        Text            = "Branch Warning";
        Size            = new Size(520, 310);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition   = FormStartPosition.CenterParent;
        MaximizeBox     = false;
        MinimizeBox     = false;
        BackColor       = DLG_WARN;
        Font            = new Font("Segoe UI", 9.5f);

        var strip = new Panel { Dock = DockStyle.Left, Width = 8, BackColor = DLG_GOLD };

        var iconLbl = new Label
        {
            Text      = "⚠",
            Font      = new Font("Segoe UI", 36f),
            ForeColor = DLG_GOLD,
            AutoSize  = true,
            Location  = new Point(30, 30),
        };

        var titleLbl = new Label
        {
            Text      = "Not on Default Branch",
            Font      = new Font("Segoe UI", 13f, FontStyle.Bold),
            ForeColor = DLG_DARK,
            AutoSize  = true,
            Location  = new Point(88, 28),
        };

        var bodyLbl = new Label
        {
            Text = $"You are currently on branch:\n    '{currentBranch}'\n\n" +
                   $"The detected default branch is:\n    '{defaultBranch}'\n\n" +
                   "Auditing a non-default branch may produce results\n" +
                   "that don't reflect the production codebase.\n" +
                   "This will be recorded in the GIT0 check in the report.",
            Font      = new Font("Segoe UI", 9.5f),
            ForeColor = Color.FromArgb(50, 50, 50),
            AutoSize  = false,
            Size      = new Size(390, 155),
            Location  = new Point(88, 60),
        };

        var btnContinue = new Button
        {
            Text         = "Continue Anyway",
            Size         = new Size(155, 36),
            Location     = new Point(88, 228),
            DialogResult = DialogResult.OK,
            BackColor    = DLG_DARK,
            ForeColor    = Color.White,
            FlatStyle    = FlatStyle.Flat,
            Font         = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Cursor       = Cursors.Hand,
        };
        btnContinue.FlatAppearance.BorderSize = 0;

        var btnAbort = new Button
        {
            Text         = "Abort & Switch Branch",
            Size         = new Size(175, 36),
            Location     = new Point(256, 228),
            DialogResult = DialogResult.Cancel,
            BackColor    = DLG_RED,
            ForeColor    = Color.White,
            FlatStyle    = FlatStyle.Flat,
            Font         = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Cursor       = Cursors.Hand,
        };
        btnAbort.FlatAppearance.BorderSize = 0;

        var hintLbl = new Label
        {
            Text      = $"Run:  git checkout {defaultBranch}",
            Font      = new Font("Consolas", 8.5f),
            ForeColor = Color.FromArgb(100, 100, 100),
            AutoSize  = true,
            Location  = new Point(256, 270),
        };

        Controls.AddRange(new Control[]
            { strip, iconLbl, titleLbl, bodyLbl, btnContinue, btnAbort, hintLbl });
        AcceptButton = btnContinue;
        CancelButton = btnAbort;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Styled Message Box
// ─────────────────────────────────────────────────────────────────────────────
public enum MsgBoxType { Info, Warning, Error }

public class StyledMessageBox : Form
{
    static readonly Color MB_DARK = Color.FromArgb(21, 40, 76);
    static readonly Color MB_RED  = Color.FromArgb(211, 32, 41);

    public StyledMessageBox(string title, string message, MsgBoxType msgType, bool showCancel = false)
    {
        var (accentColor, iconText, iconColor) = msgType switch
        {
            MsgBoxType.Error   => (MB_RED,                         "✖", MB_RED),
            MsgBoxType.Warning => (Color.FromArgb(181, 146, 43),   "⚠", Color.FromArgb(181, 146, 43)),
            _                  => (MB_DARK,                         "ℹ", MB_DARK),
        };

        Text            = title;
        Size            = new Size(460, 240);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition   = FormStartPosition.CenterParent;
        MaximizeBox     = false;
        MinimizeBox     = false;
        BackColor       = Color.White;
        Font            = new Font("Segoe UI", 9.5f);

        var topStrip = new Panel { Dock = DockStyle.Top, Height = 4, BackColor = accentColor };

        var iconLbl = new Label
        {
            Text      = iconText,
            Font      = new Font("Segoe UI", 24f),
            ForeColor = iconColor,
            AutoSize  = true,
            Location  = new Point(20, 22),
        };

        var titleLbl = new Label
        {
            Text      = title,
            Font      = new Font("Segoe UI", 11f, FontStyle.Bold),
            ForeColor = MB_DARK,
            AutoSize  = true,
            Location  = new Point(60, 20),
        };

        var msgLbl = new Label
        {
            Text      = message,
            Font      = new Font("Segoe UI", 9.5f),
            ForeColor = Color.FromArgb(50, 50, 50),
            AutoSize  = false,
            Size      = new Size(400, 90),
            Location  = new Point(60, 52),
        };

        var btnOk = new Button
        {
            Text         = showCancel ? "Yes, Stop" : "OK",
            Size         = new Size(100, 34),
            Location     = new Point(showCancel ? 240 : 340, 168),
            DialogResult = DialogResult.OK,
            BackColor    = accentColor,
            ForeColor    = Color.White,
            FlatStyle    = FlatStyle.Flat,
            Font         = new Font("Segoe UI", 9.5f, FontStyle.Bold),
            Cursor       = Cursors.Hand,
        };
        btnOk.FlatAppearance.BorderSize = 0;

        Controls.AddRange(new Control[] { topStrip, iconLbl, titleLbl, msgLbl, btnOk });

        if (showCancel)
        {
            var btnNo = new Button
            {
                Text         = "Cancel",
                Size         = new Size(100, 34),
                Location     = new Point(350, 168),
                DialogResult = DialogResult.Cancel,
                BackColor    = Color.White,
                ForeColor    = MB_DARK,
                FlatStyle    = FlatStyle.Flat,
                Font         = new Font("Segoe UI", 9.5f),
                Cursor       = Cursors.Hand,
            };
            btnNo.FlatAppearance.BorderColor = Color.FromArgb(200, 210, 225);
            btnNo.FlatAppearance.BorderSize  = 1;
            Controls.Add(btnNo);
            CancelButton = btnNo;
        }
        AcceptButton = btnOk;
    }
}

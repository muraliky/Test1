CATS Team Automation Audit Tool v3.0
See CATS_Audit_Tool_Setup_Guide_v5.docx for full instructions.

ORGANISER: edit automation-audit/config/output.config.js, run npm install,
build EXE with: cd CATSAuditLauncher && dotnet publish -c Release -r win-x64 --self-contained false
Place CATSAuditLauncher.exe next to the automation-audit/ folder.

USER: Double-click CATSAuditLauncher.exe and fill in the 4 fields.

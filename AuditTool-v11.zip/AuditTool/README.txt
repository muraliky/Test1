Automation Audit Tool
=====================

ORGANISER SETUP:
  1. Edit automation-audit/config/output.config.js  — set shared drive path
  2. cd automation-audit  &&  npm install

BUILD EXE (requires .NET 9 SDK):
  cd Launcher
  dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
  Output: bin\Release\net9.0-windows\win-x64\publish\AuditLauncher.exe

DISTRIBUTE:
  Place AuditLauncher.exe next to the automation-audit\ folder.
  Users double-click the exe — no install required.

USER:
  1. Double-click AuditLauncher.exe
  2. Click Browse to select your repo folder
  3. Select LOB and Sub LOB
  4. Enter Project name
  5. Click Run Audit

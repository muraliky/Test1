using System.Diagnostics;
using System.Text;

namespace CATSAuditLauncher;

public class AuditForm : Form
{
    private TextBox     _txtRepo    = null!;
    private Button      _btnBrowse  = null!;
    private ComboBox    _cmbLob     = null!;
    private ComboBox    _cmbSubLob  = null!;
    private TextBox     _txtProject = null!;
    private RichTextBox _rtbLog     = null!;
    private Button      _btnRun     = null!;
    private Button      _btnClear   = null!;
    private ProgressBar _progress   = null!;
    private Label       _lblStatus  = null!;
    private Label       _lblBranch  = null!;
    private Panel       _pnlFields  = null!;

    private Process? _proc;
    private bool     _running;
    private bool     _branchWarningShown;

    // Palette
    static readonly Color C_ACCENT      = Color.FromArgb(37,  99, 235);
    static readonly Color C_ACCENT_HOV  = Color.FromArgb(29,  78, 216);
    static readonly Color C_ACCENT_DARK = Color.FromArgb(30,  58, 138);
    static readonly Color C_BG          = Color.FromArgb(248, 250, 252);
    static readonly Color C_SURFACE     = Color.White;
    static readonly Color C_BORDER      = Color.FromArgb(226, 232, 240);
    static readonly Color C_BORDER2     = Color.FromArgb(203, 213, 225);
    static readonly Color C_TEXT        = Color.FromArgb(15,  23,  42);
    static readonly Color C_TEXT_MID    = Color.FromArgb(71,  85, 105);
    static readonly Color C_TEXT_DIM    = Color.FromArgb(148, 163, 184);
    static readonly Color C_DANGER      = Color.FromArgb(220,  38,  38);
    static readonly Color C_WARN_BG     = Color.FromArgb(255, 251, 235);
    static readonly Color C_WARN_TEXT   = Color.FromArgb(146,  64,  14);

    static readonly Color CL_BG   = Color.FromArgb(15,  23,  42);
    static readonly Color CL_OK   = Color.FromArgb(34,  197, 94);
    static readonly Color CL_ERR  = Color.FromArgb(248, 113, 113);
    static readonly Color CL_WARN = Color.FromArgb(251, 191,  36);
    static readonly Color CL_INFO = Color.FromArgb(226, 232, 240);
    static readonly Color CL_DIM  = Color.FromArgb(100, 116, 139);
    static readonly Color CL_CMD  = Color.FromArgb(147, 197, 253);

    public AuditForm()
    {
        BuildUI();
        LoadLobs();
        AppendLog("Ready — select your repository, fill in the details and click Run Audit.", CL_DIM);
    }

    void BuildUI()
    {
        SuspendLayout();
        Text            = "Automation Audit Tool";
        Size            = new Size(860, 760);
        MinimumSize     = new Size(760, 600);
        StartPosition   = FormStartPosition.CenterScreen;
        BackColor       = C_BG;
        Font            = new Font("Segoe UI", 9f);
        FormBorderStyle = FormBorderStyle.Sizable;

        // Header
        var header   = new Panel { Dock = DockStyle.Top, Height = 52, BackColor = C_ACCENT_DARK };
        var hdrLine  = new Panel { Dock = DockStyle.Bottom, Height = 3, BackColor = C_ACCENT };
        var lblTitle = new Label
        {
            Text = "Automation Audit Tool", AutoSize = true,
            Font = new Font("Segoe UI", 14f, FontStyle.Bold),
            ForeColor = Color.White, Location = new Point(18, 13),
        };
        header.Controls.AddRange(new Control[] { lblTitle, hdrLine });
        Controls.Add(header);

        // Footer
        var footer    = new Panel { Dock = DockStyle.Bottom, Height = 52, BackColor = C_SURFACE };
        var footerTop = new Panel { Dock = DockStyle.Top, Height = 1, BackColor = C_BORDER };

        _btnRun = new Button
        {
            Text = "Run Audit", Location = new Point(14, 10), Size = new Size(120, 32),
            FlatStyle = FlatStyle.Flat, BackColor = C_ACCENT, ForeColor = Color.White,
            Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), Cursor = Cursors.Hand,
        };
        _btnRun.FlatAppearance.BorderSize = 0;
        _btnRun.Click      += BtnRun_Click;
        _btnRun.MouseEnter += (_, _) => { if (!_running) _btnRun.BackColor = C_ACCENT_HOV; };
        _btnRun.MouseLeave += (_, _) => { if (!_running) _btnRun.BackColor = C_ACCENT; };

        _btnClear = new Button
        {
            Text = "Clear", Location = new Point(142, 10), Size = new Size(70, 32),
            FlatStyle = FlatStyle.Flat, BackColor = C_SURFACE, ForeColor = C_TEXT_MID,
            Font = new Font("Segoe UI", 9f), Cursor = Cursors.Hand,
        };
        _btnClear.FlatAppearance.BorderColor = C_BORDER2;
        _btnClear.FlatAppearance.BorderSize  = 1;
        _btnClear.Click += (_, _) => { _rtbLog.Clear(); AppendLog("Log cleared.", CL_DIM); };

        _progress = new ProgressBar
        {
            Location = new Point(224, 16), Size = new Size(200, 20),
            Style = ProgressBarStyle.Marquee, MarqueeAnimationSpeed = 25, Visible = false,
        };
        _lblStatus = new Label
        {
            Location = new Point(434, 18), AutoSize = true,
            ForeColor = C_TEXT_DIM, Font = new Font("Segoe UI", 8.5f, FontStyle.Italic), Text = "Ready",
        };
        footer.Controls.AddRange(new Control[] { footerTop, _btnRun, _btnClear, _progress, _lblStatus });
        Controls.Add(footer);

        // Body
        var body = new Panel { Dock = DockStyle.Fill };

        // Fields card
        _pnlFields = new Panel
        {
            Dock = DockStyle.Top, Height = 188,
            BackColor = C_SURFACE, Padding = new Padding(18, 14, 18, 14),
        };
        var fieldsBorder = new Panel { Dock = DockStyle.Top, Height = 1, BackColor = C_BORDER };
        BuildFields(_pnlFields);

        // Log
        var logWrap   = new Panel { Dock = DockStyle.Fill };
        var logHeader = new Panel { Dock = DockStyle.Top, Height = 32, BackColor = C_ACCENT_DARK };
        var logLbl    = new Label
        {
            Text = "Output Log", AutoSize = true,
            Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
            ForeColor = Color.FromArgb(148, 163, 184), Location = new Point(12, 8),
        };
        logHeader.Controls.Add(logLbl);

        _rtbLog = new RichTextBox
        {
            Dock = DockStyle.Fill, BackColor = CL_BG, ForeColor = CL_INFO,
            Font = new Font("Consolas", 9f), ReadOnly = true,
            ScrollBars = RichTextBoxScrollBars.Vertical,
            BorderStyle = BorderStyle.None, WordWrap = false,
        };
        logWrap.Controls.Add(_rtbLog);
        logWrap.Controls.Add(logHeader);

        body.Controls.Add(logWrap);
        body.Controls.Add(fieldsBorder);
        body.Controls.Add(_pnlFields);
        Controls.Add(body);

        ResumeLayout(true);
    }

    void BuildFields(Panel parent)
    {
        const int LBL_H = 14, FLD_H = 26, GAP = 6, ROW_GAP = 16;
        const int Y1 = 10;
        int y2 = Y1 + LBL_H + GAP + FLD_H + ROW_GAP;

        // Row 1 — Repo path
        var lRepo = MakeLbl("Repository Path", 0, Y1);

        _txtRepo = new TextBox
        {
            Location    = new Point(0, Y1 + LBL_H + GAP),
            Height      = FLD_H, Font = new Font("Segoe UI", 9.5f),
            BorderStyle = BorderStyle.FixedSingle,
            BackColor   = C_SURFACE, ForeColor = C_TEXT,
            Anchor      = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
        };

        _btnBrowse = new Button
        {
            Text = "Browse", Height = FLD_H, Width = 74,
            FlatStyle = FlatStyle.Flat, BackColor = C_SURFACE,
            ForeColor = C_TEXT_MID, Font = new Font("Segoe UI", 9f), Cursor = Cursors.Hand,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
        };
        _btnBrowse.FlatAppearance.BorderColor = C_BORDER2;
        _btnBrowse.FlatAppearance.BorderSize  = 1;
        _btnBrowse.Click += BtnBrowse_Click;

        // Row 2 — LOB | Sub LOB | Project
        var lLob  = MakeLbl("LOB", 0, y2);
        _cmbLob   = new ComboBox
        {
            Location = new Point(0, y2 + LBL_H + GAP), Width = 158, Height = FLD_H,
            DropDownStyle = ComboBoxStyle.DropDownList,
            Font = new Font("Segoe UI", 9.5f), FlatStyle = FlatStyle.Flat, BackColor = C_SURFACE,
        };
        _cmbLob.SelectedIndexChanged += CmbLob_Changed;

        var lSub   = MakeLbl("Sub LOB", 174, y2);
        _cmbSubLob = new ComboBox
        {
            Location = new Point(174, y2 + LBL_H + GAP), Width = 198, Height = FLD_H,
            DropDownStyle = ComboBoxStyle.DropDownList,
            Font = new Font("Segoe UI", 9.5f), FlatStyle = FlatStyle.Flat,
            BackColor = C_SURFACE, Enabled = false,
        };

        var lProj   = MakeLbl("Project / Repo Name", 388, y2);
        _txtProject = new TextBox
        {
            Location    = new Point(388, y2 + LBL_H + GAP),
            Height      = FLD_H, Font = new Font("Segoe UI", 9.5f),
            BorderStyle = BorderStyle.FixedSingle,
            BackColor   = C_SURFACE, ForeColor = C_TEXT,
            Anchor      = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
        };

        _lblBranch = new Label
        {
            AutoSize = true, Visible = false, Text = "",
            Location = new Point(0, y2 + LBL_H + GAP + FLD_H + 8),
            Font = new Font("Segoe UI", 8.5f, FontStyle.Italic),
            ForeColor = C_WARN_TEXT, BackColor = C_WARN_BG,
        };

        parent.Controls.AddRange(new Control[]
        {
            lRepo, _txtRepo, _btnBrowse,
            lLob, _cmbLob, lSub, _cmbSubLob, lProj, _txtProject,
            _lblBranch,
        });

        parent.Resize += (_, _) => LayoutFields(parent);
        LayoutFields(parent);
    }

    void LayoutFields(Panel parent)
    {
        const int LBL_H = 14, GAP = 6, Y1 = 10, FLD_H = 26, ROW_GAP = 16;
        int y2    = Y1 + LBL_H + GAP + FLD_H + ROW_GAP;
        int pad   = parent.Padding.Left;
        int avail = parent.ClientSize.Width - pad * 2;
        const int BTN_W = 74, BTN_GAP = 6;

        _txtRepo.Location = new Point(pad, Y1 + LBL_H + GAP);
        _txtRepo.Width    = avail - BTN_W - BTN_GAP;

        _btnBrowse.Location = new Point(pad + avail - BTN_W, Y1 + LBL_H + GAP);
        _btnBrowse.Width    = BTN_W;

        int projX = pad + 388;
        _txtProject.Location = new Point(projX, y2 + LBL_H + GAP);
        _txtProject.Width    = Math.Max(60, pad + avail - projX);

        _lblBranch.Location = new Point(pad, y2 + LBL_H + GAP + FLD_H + 8);
    }

    // ── LOB Cascade ───────────────────────────────────────────────────────────
    void LoadLobs()
    {
        _cmbLob.Items.Add("Select LOB...");
        foreach (var name in LobData.Lobs) _cmbLob.Items.Add(name);
        _cmbLob.SelectedIndex = 0;
    }

    void CmbLob_Changed(object? sender, EventArgs evt)
    {
        _cmbSubLob.Items.Clear();
        _cmbSubLob.Enabled = false;
        if (_cmbLob.SelectedIndex <= 0) return;
        var subs = LobData.SubLobsFor(_cmbLob.SelectedItem!.ToString()!);
        if (subs.Count == 0) return;
        _cmbSubLob.Items.Add("Select Sub LOB...");
        foreach (var subName in subs) _cmbSubLob.Items.Add(subName);
        _cmbSubLob.SelectedIndex = 0;
        _cmbSubLob.Enabled       = true;
    }

    // ── Browse — OpenFileDialog trick (most reliable on .NET 9) ───────────────
    void BtnBrowse_Click(object? sender, EventArgs evt)
    {
        string? picked = null;
        string  initDir = Directory.Exists(_txtRepo.Text)
            ? _txtRepo.Text
            : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

        try
        {
            using var ofd = new OpenFileDialog
            {
                Title           = "Select Repository Root Folder",
                CheckFileExists = false,
                CheckPathExists = true,
                ValidateNames   = false,
                FileName        = "Select Folder",
                Filter          = "Folder|*.none",
                InitialDirectory = initDir,
            };
            if (ofd.ShowDialog(this) == DialogResult.OK)
                picked = Path.GetDirectoryName(ofd.FileName);
        }
        catch
        {
            try
            {
                using var fbd = new FolderBrowserDialog
                {
                    Description            = "Select Repository Root Folder",
                    UseDescriptionForTitle = true,
                    ShowNewFolderButton    = false,
                    InitialDirectory       = initDir,
                };
                if (fbd.ShowDialog(this) == DialogResult.OK)
                    picked = fbd.SelectedPath;
            }
            catch { /* give up */ }
        }

        if (string.IsNullOrWhiteSpace(picked)) return;
        _txtRepo.Text = picked;
        if (string.IsNullOrWhiteSpace(_txtProject.Text))
            _txtProject.Text = Path.GetFileName(picked);
    }

    // ── Validation ────────────────────────────────────────────────────────────
    bool ValidateInputs(out string repo, out string project, out string lob, out string subLob)
    {
        repo    = _txtRepo.Text.Trim();
        project = _txtProject.Text.Trim();
        lob     = _cmbLob.SelectedIndex > 0 ? _cmbLob.SelectedItem!.ToString()! : "";
        subLob  = _cmbSubLob.SelectedIndex > 0 ? _cmbSubLob.SelectedItem!.ToString()! : "";
        var errs = new List<string>();

        if (string.IsNullOrWhiteSpace(repo))
            errs.Add("Repository path is required.");
        else if (!Directory.Exists(repo))
            errs.Add($"Path does not exist:\n{repo}");
        else if (!Directory.Exists(Path.Combine(repo, ".git")))
            errs.Add("Not a git repository (.git folder not found).");

        if (string.IsNullOrWhiteSpace(lob) || lob.StartsWith("Select"))
            errs.Add("Please select a LOB.");
        if (_cmbSubLob.Enabled && (string.IsNullOrWhiteSpace(subLob) || subLob.StartsWith("Select")))
            errs.Add("Please select a Sub LOB.");
        if (string.IsNullOrWhiteSpace(project))
            errs.Add("Project / Repo Name is required.");

        if (errs.Count == 0) return true;
        using var dlg = new StyledMessageBox("Validation", string.Join("\n\n", errs), MsgBoxType.Warning);
        dlg.ShowDialog(this);
        return false;
    }

    // ── Run ───────────────────────────────────────────────────────────────────
    void BtnRun_Click(object? sender, EventArgs evt)
    {
        if (_running)
        {
            try { _proc?.Kill(entireProcessTree: true); } catch { /* ignore */ }
            SetRunning(false);
            AppendLog("Audit cancelled by user.", CL_WARN);
            return;
        }

        if (!ValidateInputs(out var repo, out var project, out var lob, out var subLob)) return;

        var nodeExe = FindNode();
        if (nodeExe == null)
        {
            using var d = new StyledMessageBox("Node.js Not Found",
                "node.exe was not found on PATH.\n\nInstall Node.js v16+ and restart.",
                MsgBoxType.Error);
            d.ShowDialog(this); return;
        }

        var auditJs = FindAuditJs();
        if (auditJs == null)
        {
            using var d = new StyledMessageBox("Audit Engine Not Found",
                "audit.js was not found.\n\nEnsure the automation-audit folder is next to this exe.",
                MsgBoxType.Error);
            d.ShowDialog(this); return;
        }

        _rtbLog.Clear();
        _branchWarningShown = false;
        _lblBranch.Visible  = false;

        var lobArg = string.IsNullOrWhiteSpace(subLob) || subLob.StartsWith("Select")
            ? lob : $"{lob} / {subLob}";
        var nodeArgs = $"\"{auditJs}\" -r \"{repo}\" -p \"{project}\" -l \"{lobArg}\" --no-branch-check";

        AppendLog($"Project  : {project}", CL_INFO);
        AppendLog($"Repo     : {repo}",    CL_INFO);
        AppendLog($"LOB      : {lobArg}",  CL_INFO);
        AppendLog("", CL_DIM);

        SetRunning(true);

        _proc = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName               = nodeExe,
                Arguments              = nodeArgs,
                WorkingDirectory       = Path.GetDirectoryName(auditJs)!,
                UseShellExecute        = false,
                RedirectStandardOutput = true,
                RedirectStandardError  = true,
                CreateNoWindow         = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding  = Encoding.UTF8,
            },
            EnableRaisingEvents = true,
        };
        _proc.OutputDataReceived += ProcOut;
        _proc.ErrorDataReceived  += ProcErr;
        _proc.Exited             += (_, _) => Invoke(ProcDone);

        try
        {
            _proc.Start();
            _proc.BeginOutputReadLine();
            _proc.BeginErrorReadLine();
        }
        catch (Exception ex) { SetRunning(false); AppendLog($"Failed to start: {ex.Message}", CL_ERR); }
    }

    // ── Process callbacks ─────────────────────────────────────────────────────
    void ProcOut(object proc, DataReceivedEventArgs args)
    {
        if (args.Data == null) return;
        var line = args.Data;
        Invoke(() =>
        {
            if (!_branchWarningShown && line.Contains("NOT ON DEFAULT BRANCH"))
            {
                _branchWarningShown = true;
                ShowBranchPopup();
            }
            else if (line.Contains("Current branch") && line.Contains("Default branch"))
            {
                var cur = Between(line, "Current branch: '", "'");
                var def = Between(line, "Default branch: '", "'");
                if (!string.IsNullOrEmpty(cur) && cur != def)
                {
                    _lblBranch.Text    = $"  ⚠  On '{cur}' — default is '{def}'  ";
                    _lblBranch.Visible = true;
                }
            }
            ColorLog(line);
        });
    }

    void ProcErr(object proc, DataReceivedEventArgs args)
    {
        if (args.Data == null) return;
        var line = args.Data;
        Invoke(() => AppendLog(line, CL_ERR));
    }

    void ProcDone()
    {
        var code = _proc?.ExitCode ?? -1;
        AppendLog("");
        if (code == 0) { AppendLog("Audit complete — report saved to the shared drive.", CL_OK, bold: true); SetStatus("Complete", CL_OK); }
        else            { AppendLog($"Audit failed (exit {code}). See output above.",             CL_ERR); SetStatus($"Failed ({code})", CL_ERR); }
        SetRunning(false);
        _proc?.Dispose();
        _proc = null;
    }

    // ── Branch popup ──────────────────────────────────────────────────────────
    void ShowBranchPopup()
    {
        var cur = _lblBranch.Visible ? Between(_lblBranch.Text, "On '",      "'") : "";
        var def = _lblBranch.Visible ? Between(_lblBranch.Text, "default is '", "'") : "main";
        using var dlg = new BranchWarningDialog(cur, def);
        if (dlg.ShowDialog(this) == DialogResult.Cancel)
        {
            try { _proc?.Kill(entireProcessTree: true); } catch { /* ignore */ }
            AppendLog("Audit aborted — switch to the default branch and re-run.", CL_ERR);
            SetRunning(false);
        }
        else AppendLog($"Proceeding on non-default branch '{cur}' — recorded in GIT0.", CL_WARN);
    }

    // ── Log ───────────────────────────────────────────────────────────────────
    void ColorLog(string text) => AppendLog(text, Classify(text));

    void AppendLog(string text, Color? color = null, bool bold = false)
    {
        if (InvokeRequired) { Invoke(() => AppendLog(text, color, bold)); return; }
        color ??= CL_INFO;
        _rtbLog.SelectionStart  = _rtbLog.TextLength;
        _rtbLog.SelectionLength = 0;
        _rtbLog.SelectionColor  = color.Value;
        _rtbLog.SelectionFont   = bold ? new Font(_rtbLog.Font, FontStyle.Bold) : _rtbLog.Font;
        _rtbLog.AppendText(text + "\n");
        _rtbLog.ScrollToCaret();
    }

    Color Classify(string line)
    {
        if (string.IsNullOrWhiteSpace(line)) return CL_INFO;
        if (line.Contains("✅") || line.Contains("✔") || line.Contains("complete") || line.Contains("done")) return CL_OK;
        if (line.Contains("✖") || line.Contains("error") || line.Contains("Error") || line.Contains("failed")) return CL_ERR;
        if (line.Contains("⚠") || line.Contains("~") || line.Contains("Manual") || line.Contains("WARNING")) return CL_WARN;
        if (line.TrimStart().StartsWith("─") || line.TrimStart().StartsWith("═") ||
            line.TrimStart().StartsWith("╔") || line.TrimStart().StartsWith("║") ||
            line.TrimStart().StartsWith("╚")) return CL_DIM;
        if (line.TrimStart().StartsWith("📁") || line.TrimStart().StartsWith("📋") ||
            line.TrimStart().StartsWith("📂") || line.TrimStart().StartsWith("📊") ||
            line.TrimStart().StartsWith("🔍") || line.TrimStart().StartsWith("🔎") ||
            line.TrimStart().StartsWith("📐") || line.TrimStart().StartsWith("🏗") ||
            line.TrimStart().StartsWith("⚙")  || line.TrimStart().StartsWith("🌿")) return CL_CMD;
        return CL_INFO;
    }

    void SetStatus(string text, Color color)
    {
        if (InvokeRequired) { Invoke(() => SetStatus(text, color)); return; }
        _lblStatus.Text = text; _lblStatus.ForeColor = color;
    }

    void SetRunning(bool isRunning)
    {
        if (InvokeRequired) { Invoke(() => SetRunning(isRunning)); return; }
        _running             = isRunning;
        _btnRun.Text         = isRunning ? "Stop" : "Run Audit";
        _btnRun.BackColor    = isRunning ? C_DANGER : C_ACCENT;
        _progress.Visible    = isRunning;
        _btnBrowse.Enabled   = !isRunning;
        _cmbLob.Enabled      = !isRunning;
        _cmbSubLob.Enabled   = !isRunning && _cmbLob.SelectedIndex > 0;
        _txtRepo.Enabled     = !isRunning;
        _txtProject.Enabled  = !isRunning;
        if (isRunning) SetStatus("Running…", CL_WARN);
    }

    // ── Locate node / audit.js ────────────────────────────────────────────────
    static string? FindNode()
    {
        foreach (var dir in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
        {
            if (string.IsNullOrWhiteSpace(dir)) continue;
            var c = Path.Combine(dir.Trim(), "node.exe");
            if (File.Exists(c)) return c;
        }
        string[] known =
        [
            @"C:\Program Files\nodejs\node.exe",
            @"C:\Program Files (x86)\nodejs\node.exe",
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), @"nvm\current\node.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"nodejs\node.exe"),
        ];
        return known.FirstOrDefault(File.Exists);
    }

    static string? FindAuditJs()
    {
        var baseDir = AppContext.BaseDirectory;
        string[] candidates =
        [
            Path.Combine(baseDir, "automation-audit", "audit.js"),
            Path.Combine(baseDir, "..", "automation-audit", "audit.js"),
            Path.Combine(baseDir, "audit.js"),
        ];
        return candidates.Select(Path.GetFullPath).FirstOrDefault(File.Exists);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    static Label MakeLbl(string text, int x, int y) => new()
    {
        Text = text, Location = new Point(x, y), AutoSize = true,
        Font = new Font("Segoe UI", 8f, FontStyle.Bold),
        ForeColor = Color.FromArgb(71, 85, 105),
    };

    static string Between(string input, string open, string close)
    {
        var i = input.IndexOf(open, StringComparison.Ordinal);
        if (i < 0) return "";
        i += open.Length;
        var j = input.IndexOf(close, i, StringComparison.Ordinal);
        return j < 0 ? "" : input[i..j];
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (_running)
        {
            using var dlg = new StyledMessageBox("Confirm Exit",
                "An audit is still running. Stop it and exit?",
                MsgBoxType.Warning, showCancel: true);
            if (dlg.ShowDialog(this) != DialogResult.OK) { e.Cancel = true; return; }
            try { _proc?.Kill(entireProcessTree: true); } catch { /* ignore */ }
        }
        base.OnFormClosing(e);
    }
}

// ── Branch Warning Dialog ─────────────────────────────────────────────────────
public class BranchWarningDialog : Form
{
    static readonly Color D_DARK = Color.FromArgb(30,  58, 138);
    static readonly Color D_RED  = Color.FromArgb(220,  38,  38);
    static readonly Color D_BG   = Color.FromArgb(255, 251, 235);
    static readonly Color D_LINE = Color.FromArgb(217, 119,   6);
    static readonly Color D_WARN = Color.FromArgb(146,  64,  14);

    public BranchWarningDialog(string current, string defaultBranch)
    {
        Text = "Branch Warning"; Size = new Size(460, 252);
        FormBorderStyle = FormBorderStyle.FixedDialog; StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false; MinimizeBox = false; BackColor = D_BG; Font = new Font("Segoe UI", 9f);

        var bar      = new Panel { Dock = DockStyle.Left, Width = 5, BackColor = D_LINE };
        var iconLbl  = new Label { Text = "⚠", Font = new Font("Segoe UI", 26f), ForeColor = D_LINE, AutoSize = true, Location = new Point(20, 18) };
        var titleLbl = new Label { Text = "Not on Default Branch", Font = new Font("Segoe UI", 11f, FontStyle.Bold), ForeColor = D_DARK, AutoSize = true, Location = new Point(66, 18) };
        var bodyLbl  = new Label
        {
            Text      = $"Current branch  :  {(string.IsNullOrEmpty(current) ? "(unknown)" : current)}\n" +
                        $"Default branch  :  {defaultBranch}\n\n" +
                        "Results may not reflect the production codebase.\nThis is recorded in GIT0 in the report.",
            Font = new Font("Segoe UI", 9f), ForeColor = D_WARN,
            AutoSize = false, Size = new Size(370, 72), Location = new Point(66, 48),
        };
        var hintLbl = new Label
        {
            Text = $"To switch:  git checkout {defaultBranch}",
            Font = new Font("Consolas", 8f), ForeColor = Color.FromArgb(120, 120, 120),
            AutoSize = true, Location = new Point(66, 128),
        };
        var btnContinue = new Button
        {
            Text = "Continue Anyway", Size = new Size(136, 30), Location = new Point(66, 162),
            DialogResult = DialogResult.OK, BackColor = D_DARK, ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9f, FontStyle.Bold), Cursor = Cursors.Hand,
        };
        btnContinue.FlatAppearance.BorderSize = 0;
        var btnAbort = new Button
        {
            Text = "Abort", Size = new Size(74, 30), Location = new Point(210, 162),
            DialogResult = DialogResult.Cancel, BackColor = D_RED, ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9f, FontStyle.Bold), Cursor = Cursors.Hand,
        };
        btnAbort.FlatAppearance.BorderSize = 0;

        Controls.AddRange(new Control[] { bar, iconLbl, titleLbl, bodyLbl, hintLbl, btnContinue, btnAbort });
        AcceptButton = btnContinue; CancelButton = btnAbort;
    }
}

// ── Styled Message Box ────────────────────────────────────────────────────────
public enum MsgBoxType { Info, Warning, Error }

public class StyledMessageBox : Form
{
    static readonly Color MB_DARK = Color.FromArgb(30, 41, 59);
    static readonly Color MB_RED  = Color.FromArgb(220, 38, 38);

    public StyledMessageBox(string title, string message, MsgBoxType msgType, bool showCancel = false)
    {
        var (accentClr, iconChar, iconClr) = msgType switch
        {
            MsgBoxType.Error   => (MB_RED,                       "✕", MB_RED),
            MsgBoxType.Warning => (Color.FromArgb(217, 119, 6),  "⚠", Color.FromArgb(146, 64, 14)),
            _                  => (Color.FromArgb(37,  99, 235), "i", Color.FromArgb(37,  99, 235)),
        };

        Text = title; Size = new Size(400, 200);
        FormBorderStyle = FormBorderStyle.FixedDialog; StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false; MinimizeBox = false; BackColor = Color.White; Font = new Font("Segoe UI", 9f);

        var topBar   = new Panel { Dock = DockStyle.Top, Height = 3, BackColor = accentClr };
        var iconLbl  = new Label { Text = iconChar, Font = new Font("Segoe UI", 16f, FontStyle.Bold), ForeColor = iconClr, AutoSize = true, Location = new Point(14, 16) };
        var titleLbl = new Label { Text = title, Font = new Font("Segoe UI", 10f, FontStyle.Bold), ForeColor = MB_DARK, AutoSize = true, Location = new Point(44, 14) };
        var msgLbl   = new Label
        {
            Text = message, Font = new Font("Segoe UI", 9f), ForeColor = Color.FromArgb(71, 85, 105),
            AutoSize = false, Size = new Size(356, 70), Location = new Point(44, 42),
        };
        var btnOk = new Button
        {
            Text = showCancel ? "Stop Audit" : "OK", Size = new Size(90, 28),
            Location = new Point(showCancel ? 196 : 292, 144),
            DialogResult = DialogResult.OK, BackColor = accentClr, ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9f, FontStyle.Bold), Cursor = Cursors.Hand,
        };
        btnOk.FlatAppearance.BorderSize = 0;
        Controls.AddRange(new Control[] { topBar, iconLbl, titleLbl, msgLbl, btnOk });

        if (showCancel)
        {
            var btnNo = new Button
            {
                Text = "Cancel", Size = new Size(76, 28), Location = new Point(294, 144),
                DialogResult = DialogResult.Cancel, BackColor = Color.White, ForeColor = MB_DARK,
                FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9f), Cursor = Cursors.Hand,
            };
            btnNo.FlatAppearance.BorderColor = Color.FromArgb(203, 213, 225);
            btnNo.FlatAppearance.BorderSize  = 1;
            Controls.Add(btnNo); CancelButton = btnNo;
        }
        AcceptButton = btnOk;
    }
}

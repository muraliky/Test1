CATS Team Automation Audit Tool v3.0  |  .NET 9
=================================================
See CATS_Audit_Tool_Setup_Guide_v5.docx for full instructions.

BUILD THE EXE (organiser, requires .NET 9 SDK):
  cd CATSAuditLauncher
  dotnet publish -c Release -r win-x64 --self-contained false
  Output: bin\Release\net9.0-windows\win-x64\publish\CATSAuditLauncher.exe

  To include the .NET 9 runtime (no runtime install needed on user machines):
  dotnet publish -c Release -r win-x64 --self-contained true

SETUP:
  1. Edit automation-audit/config/output.config.js  (set shared drive path)
  2. cd automation-audit && npm install
  3. Place CATSAuditLauncher.exe next to the automation-audit/ folder
  4. Distribute the folder to users

USERS: Double-click CATSAuditLauncher.exe, fill 4 fields, click Run Audit.

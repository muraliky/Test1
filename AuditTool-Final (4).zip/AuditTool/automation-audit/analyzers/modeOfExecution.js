'use strict';
const fs   = require('fs');
const path = require('path');
const { collectFiles, readFile, searchInFiles } = require('./fileScanner');

function runModeOfExecution(repoInfo) {
  const { repoPath, type } = repoInfo;
  const isQAF = type === 'qaf';
  const isPW  = type === 'playwright';

  const allYamls = collectFiles(repoPath, ['.yml', '.yaml']);
  const srcExts  = isQAF ? ['.java','.xml'] : ['.ts','.js','.json'];
  const srcFiles = collectFiles(repoPath, srcExts);
  const features = collectFiles(repoPath, ['.feature']);

  return {
    MOE1: checkHyperExecute(repoPath, allYamls),
    MOE2: checkSmoke(repoPath, allYamls, srcFiles, features),
    MOE3: checkRegression(repoPath, allYamls, srcFiles, features),
    MOE4: { result: 'Manual', evidence: 'Manual check — verify QMetry/email report distribution list and confirm reports are sent to correct stakeholders after each HyperExecute run', violations: [] },
    MOE5: checkParallel(repoPath, allYamls, srcFiles, isQAF, isPW),
  };
}

// MOE1 — HyperExecute setup
function checkHyperExecute(repoPath, allYamls) {
  const heNames = [
    'hyperexecute.yaml','hyperexecute.yml','he.yaml','he.yml',
    'hyperexecute_config.yaml','hyperexecute_config.yml',
    '.hyperexecute.yaml','.hyperexecute.yml'
  ];
  const subDirs = ['ci','.ci','hyperexecute','he','.he','lambdatest','lt'];

  // Check root
  for (const name of heNames) {
    const full = path.join(repoPath, name);
    if (fs.existsSync(full)) return _heFound(repoPath, full);
  }
  // Check sub-folders
  for (const dir of subDirs) {
    for (const name of heNames) {
      const full = path.join(repoPath, dir, name);
      if (fs.existsSync(full)) return _heFound(repoPath, full);
    }
  }
  // Scan all YAMLs for HE keywords
  for (const f of allYamls) {
    const c = readFile(f);
    if (/hyperexecute|smartGrid|runson:\s*(win|linux|mac)/i.test(c)) return _heFound(repoPath, f);
  }

  return {
    result:   'No',
    evidence: 'No HyperExecute config file found. Repo not onboarded to HyperExecute.',
    violations: [{
      file: '', lineNo: '',
      issue: 'Create hyperexecute.yaml at repo root to onboard to HyperExecute',
      snippet: ''
    }]
  };
}

function _heFound(repoPath, filePath) {
  const content  = readFile(filePath);
  const details  = [];
  const m1 = content.match(/concurrency\s*:\s*(\d+)/i);
  const m2 = content.match(/runson\s*:\s*(\S+)/i);
  const m3 = content.match(/framework\s*[:\n]\s*(?:name\s*:\s*)?(\S+)/i);
  const m4 = content.match(/testSuiteTimeout\s*:\s*(\d+)/i);
  if (m1) details.push(`concurrency: ${m1[1]}`);
  if (m2) details.push(`runson: ${m2[1]}`);
  if (m3) details.push(`framework: ${m3[1]}`);
  if (m4) details.push(`timeout: ${m4[1]}min`);
  return {
    result:   'Yes',
    evidence: `HyperExecute config found: ${path.relative(repoPath,filePath)}${details.length ? ' | '+details.join(', ') : ''}`,
    violations: []
  };
}

// MOE2 — Smoke suite
function checkSmoke(repoPath, yamls, srcFiles, features) {
  const heYamls = yamls.filter(f => /hyperexecute|he\./i.test(path.basename(f)));
  const pool    = heYamls.length ? heYamls : yamls;

  const inHE   = searchInFiles(pool,     /smoke|sanity/i, repoPath);
  const inTags = searchInFiles(features, /@smoke|@sanity/i, repoPath);
  const inSrc  = searchInFiles(srcFiles, /groups\s*=.*smoke|@smoke|test.*smoke/i, repoPath);

  const found = inHE.length > 0 || inTags.length > 0 || inSrc.length > 0;
  const parts = [
    inHE.length   && `${inHE.length} reference(s) in HyperExecute YAML`,
    inTags.length && `${inTags.length} @smoke tag(s) in feature files`,
    inSrc.length  && `${inSrc.length} smoke group(s) in source`,
  ].filter(Boolean);

  return found
    ? { result: 'Yes', evidence: `Smoke suite found: ${parts.join(', ')}`, violations: [] }
    : { result: 'No',  evidence: 'No smoke suite or @smoke tags found', violations: [{
        file: '', lineNo: '', issue: 'Add @smoke tags to tests and reference smoke suite in HyperExecute YAML', snippet: ''
      }]};
}

// MOE3 — Regression suite
function checkRegression(repoPath, yamls, srcFiles, features) {
  const heYamls = yamls.filter(f => /hyperexecute|he\./i.test(path.basename(f)));
  const pool    = heYamls.length ? heYamls : yamls;

  const inHE   = searchInFiles(pool,     /regression|release/i, repoPath);
  const inTags = searchInFiles(features, /@regression|@regress/i, repoPath);
  const xmlSuites = collectFiles(path.join(repoPath,'src')||repoPath, ['.xml'])
    .filter(f => /regression|suite/i.test(path.basename(f)));

  const found = inHE.length > 0 || inTags.length > 0 || xmlSuites.length > 0;
  const parts = [
    inHE.length      && `${inHE.length} reference(s) in HyperExecute YAML`,
    inTags.length    && `${inTags.length} @regression tag(s) in feature files`,
    xmlSuites.length && `${xmlSuites.length} regression XML suite(s)`,
  ].filter(Boolean);

  return found
    ? { result: 'Yes', evidence: `Regression suite found: ${parts.join(', ')}`, violations: [] }
    : { result: 'No',  evidence: 'No regression suite or @regression tags found', violations: [{
        file: '', lineNo: '', issue: 'Add @regression tags and reference regression suite in HyperExecute YAML', snippet: ''
      }]};
}

// MOE5 — Parallel execution
function checkParallel(repoPath, allYamls, srcFiles, isQAF, isPW) {
  // HyperExecute concurrency = parallel for both repo types
  const heConcurrency = searchInFiles(allYamls, /concurrency\s*:\s*[2-9]|concurrency\s*:\s*\d{2,}/i, repoPath);
  if (heConcurrency.length > 0) {
    const m = readFile(heConcurrency[0].file).match(/concurrency\s*:\s*(\d+)/i);
    return { result: 'Yes', evidence: `Parallel via HyperExecute concurrency${m ? ': '+m[1]+' sessions' : ''}`, violations: [] };
  }

  if (isQAF) {
    const xmlFiles  = collectFiles(repoPath, ['.xml']);
    const inXML     = searchInFiles(xmlFiles,  /parallel\s*=\s*["'](methods|tests|classes|instances)/i, repoPath);
    const inPom     = searchInFiles(collectFiles(repoPath,[]).filter(f=>path.basename(f)==='pom.xml'), /<parallel>|<forkCount>/i, repoPath);
    if (inXML.length > 0) return { result: 'Yes', evidence: 'Parallel configured in TestNG XML (parallel attribute found)', violations: [] };
    if (inPom.length > 0) return { result: 'Yes', evidence: 'Parallel configured in Maven Surefire plugin', violations: [] };
    return {
      result:   'No',
      evidence: 'No parallel execution configured (optional — implement when test isolation allows)',
      violations: [{
        file: '', lineNo: '',
        issue: 'Parallel execution not configured (optional) — if test isolation allows, add parallel="methods" to TestNG suite XML or set concurrency in HyperExecute config to reduce run time',
        snippet: ''
      }]
    };
  }

  if (isPW) {
    const cfgFiles = collectFiles(repoPath, ['.ts','.js']).filter(f => /playwright\.config/i.test(path.basename(f)));
    const inConfig = searchInFiles(cfgFiles, /workers\s*:\s*[2-9]|fullyParallel\s*:\s*true/, repoPath);
    if (inConfig.length > 0) return { result: 'Yes', evidence: 'Parallel workers configured in playwright.config', violations: [] };
    return {
      result:   'No',
      evidence: 'No parallel execution configured (optional — implement when test isolation allows)',
      violations: [{
        file: 'playwright.config.ts', lineNo: '',
        issue: 'Parallel execution not configured (optional) — if test isolation allows, set workers: 4 or fullyParallel: true in playwright.config.ts, or set concurrency in HyperExecute config',
        snippet: ''
      }]
    };
  }

  return { result: 'N/A', evidence: 'Unknown repo type', violations: [] };
}

module.exports = { runModeOfExecution };

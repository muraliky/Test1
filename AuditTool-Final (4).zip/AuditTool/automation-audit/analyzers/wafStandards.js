'use strict';
const fs   = require('fs');
const path = require('path');
const { collectFiles, readFile, searchInFiles, makeViolation } = require('./fileScanner');

// ─── Router ───────────────────────────────────────────────────────────────────
function runFrameworkStandards(repoInfo) {
  return repoInfo.type === 'playwright'
    ? runPlaywrightStandards(repoInfo)
    : runQAFStandards(repoInfo);
}

// ═══════════════════════════════════════════════════════════════════════════════
// WAF/GAF SELENIUM (JAVA/QAF) — FW1–FW13
// ═══════════════════════════════════════════════════════════════════════════════
function runQAFStandards(repoInfo) {
  const { repoPath } = repoInfo;
  const javaFiles   = collectFiles(repoPath, ['.java']);
  const featureFiles= collectFiles(repoPath, ['.feature']);

  return {
    FW1:  checkQAFPageObjects(repoPath, javaFiles),
    FW2:  _manual('Manual check — open pom.xml / build.gradle and verify dependency versions against Maven Central'),
    FW3:  checkGradle(repoPath),
    FW4:  checkWFElements(repoPath, javaFiles),
    FW5:  checkQAFPageDeclarations(repoPath, javaFiles),
    FW6:  checkQAFFrameworkMethods(repoPath, javaFiles),
    FW7:  checkEnvHardcoding(repoPath, javaFiles),
    FW8:  checkPasswords(repoPath, javaFiles),
    FW9:  checkStaticWaitsJava(repoPath, javaFiles),
    FW10: checkBDD(repoPath, featureFiles),
    FW11: checkQAFAssertions(repoPath, javaFiles),
    FW12: checkQAFScreenshots(repoPath, javaFiles),
    FW13: checkOctaneIntegrationQAF(repoPath),
  };
}

function checkQAFPageObjects(repoPath, files) {
  const dirs = ['pageobjects','pageObjects','PageObjects','pages','page_objects'];
  for (const dir of dirs) {
    const candidates = [
      path.join(repoPath, 'src','main','java', dir),
      path.join(repoPath, 'src','test','java', dir),
      path.join(repoPath, 'src', dir),
      path.join(repoPath, dir),
    ];
    for (const c of candidates) {
      if (fs.existsSync(c)) {
        const count = collectFiles(c, ['.java']).length;
        return _yes(`Page object directory found: ${path.relative(repoPath,c)} (${count} file(s))`);
      }
    }
  }
  const pageFiles = files.filter(f => /page|screen/i.test(path.basename(f)));
  if (pageFiles.length > 0) return _yes(`${pageFiles.length} page class file(s) found by naming pattern`);
  return _no('No page object directory or *Page.java files found', [{
    file: '', lineNo: '', issue: 'Create a pageobjects/ directory with WAF/GAF page classes', snippet: ''
  }]);
}

function checkGradle(repoPath) {
  const hasGradle = fs.existsSync(path.join(repoPath,'build.gradle')) || fs.existsSync(path.join(repoPath,'build.gradle.kts'));
  const hasMaven  = fs.existsSync(path.join(repoPath,'pom.xml'));
  if (hasGradle) return _yes('build.gradle found — project uses Gradle');
  if (hasMaven)  return _no('pom.xml found — project still uses Maven. Migration to Gradle pending.', [{
    file: 'pom.xml', lineNo: '', issue: 'Migrate build tool from Maven (pom.xml) to Gradle (build.gradle)', snippet: ''
  }]);
  return { result: 'N/A', evidence: 'No build file found at repo root', violations: [] };
}

function checkWFElements(repoPath, files) {
  const wfHits  = searchInFiles(files, /WFWebElement|WFDropDownListWebElement|WFCheckBoxWebElement|WFRadioButtonWebElement/, repoPath);
  const rawHits = searchInFiles(files, /\bWebElement\b/, repoPath).filter(h => !/WFWebElement/.test(h.line));

  if (wfHits.length > 0) {
    const violations = rawHits.map(h => ({
      file: h.relativePath, lineNo: h.lineNo,
      issue: 'Raw WebElement used — replace with WFWebElement',
      snippet: h.line
    }));
    return {
      result:   rawHits.length > 0 ? 'No' : 'Yes',
      evidence: `${wfHits.length} WFWebElement declaration(s) found. ${rawHits.length > 0 ? rawHits.length+' raw WebElement usage(s) also found.' : ''}`,
      violations,
    };
  }
  const violations = rawHits.map(h => ({
    file: h.relativePath, lineNo: h.lineNo,
    issue: 'Raw WebElement used — replace with WFWebElement or WFDropDownListWebElement',
    snippet: h.line
  }));
  return _no('No WFWebElement declarations found — raw WebElement being used', violations);
}

function checkQAFPageDeclarations(repoPath, files) {
  const hits = searchInFiles(files, /@Page\b|extends\s+\w*Page\b|implements\s+\w*Page\b/, repoPath);
  if (hits.length > 0) return _yes(`${hits.length} WAF/GAF Page declaration(s) found`);
  const violations = files.filter(f => /page/i.test(path.basename(f))).slice(0,5).map(f => ({
    file: path.relative(repoPath,f), lineNo: '', issue: 'Page class not declared with @Page annotation or extends WAF base page', snippet: ''
  }));
  return _no('Pages not declared as per WAF/GAF standards (@Page / extends XxxPage)', violations);
}

function checkQAFFrameworkMethods(repoPath, files) {
  const hits = searchInFiles(files, /GAFWebPage\.|WAFWebPage\.|gafPage\.|wafPage\.|QAFWebElement\.|@QAFWebElement/, repoPath);
  if (hits.length > 0) return _yes(`${hits.length} GAF/WAF framework method usage(s) found`);

  // Provide actionable details: list the Java files that should be using framework methods
  const pageFiles = files.filter(f => {
    const n = path.basename(f).toLowerCase();
    return n.includes('page') || n.includes('step') || n.includes('helper') || n.endsWith('.java');
  });
  const violations = pageFiles.map(f => ({
    file:    path.relative(repoPath, f),
    lineNo:  '',
    issue:   'No GAFWebPage./WAFWebPage. framework method calls found in this file — replace direct WebDriver calls with WAF framework methods',
    snippet: ''
  }));
  // If no specific files identified, give at least one actionable item
  if (violations.length === 0) {
    violations.push({
      file: '', lineNo: '', issue: 'No Java source files scanned or no WAF framework calls found — ensure GAFWebPage./WAFWebPage. methods are used instead of raw WebDriver/Selenium calls', snippet: ''
    });
  }
  return {
    result:   'No',
    evidence: `No GAFWebPage./WAFWebPage. framework method usage found across ${files.length} Java file(s). Scanned for: GAFWebPage., WAFWebPage., QAFWebElement.`,
    violations,
  };
}

function checkEnvHardcoding(repoPath, files) {
  const hits = searchInFiles(files,
    /(https?:\/\/)(sit|uat|dev|prod|qa|staging)[.\-\/][a-zA-Z0-9.\/\-]+|server\s*[:=]\s*["'](sit|uat|prod|dev)/i,
    repoPath
  );
  const violations = hits.map(h => ({
    file: h.relativePath, lineNo: h.lineNo,
    issue: `Hardcoded environment URL/reference: ${h.line.substring(0,80)}`,
    snippet: h.line
  }));
  return hits.length === 0
    ? _yes('No hardcoded environment URLs found')
    : _no(`${hits.length} hardcoded environment reference(s) found`, violations);
}

function checkPasswords(repoPath, files) {
  const hits = searchInFiles(files,
    /(?:password|passwd|pwd)\s*[:=]\s*["'][a-zA-Z0-9!@#$%^&*()_+]{4,}["']/i,
    repoPath
  );
  const violations = hits.map(h => ({
    file: h.relativePath, lineNo: h.lineNo,
    issue: `Plaintext password found`,
    snippet: h.line.replace(/["'][^"']{4,}["']/, '"***"')
  }));
  return hits.length === 0
    ? _yes('No plaintext passwords found in scripts')
    : _no(`${hits.length} plaintext password(s) found`, violations);
}

function checkStaticWaitsJava(repoPath, files) {
  const hits = searchInFiles(files, /Thread\.sleep\s*\(|TimeUnit\.\w+\.sleep\s*\(/, repoPath);
  const violations = hits.map(h => ({
    file: h.relativePath, lineNo: h.lineNo,
    issue: 'Static wait used — replace with explicit/smart waits',
    snippet: h.line
  }));
  return hits.length === 0
    ? _yes('No Thread.sleep() / TimeUnit.sleep() static waits found')
    : _no(`${hits.length} static wait(s) found`, violations);
}

function checkBDD(repoPath, featureFiles) {
  if (!featureFiles.length) return { result: 'N/A', evidence: 'No .feature files found — BDD not used', violations: [] };

  const violations = [];
  let totalScenarios = 0;

  for (const file of featureFiles) {
    const content = readFile(file);
    const rel     = path.relative(repoPath, file);
    const lines   = content.split('\n');

    // Strip BOM and normalize line endings before checking Feature: keyword.
    // Also allow optional leading whitespace — some editors add indentation.
    const normalised = content.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    const hasFeatureKeyword = /^\s*Feature\s*:/m.test(normalised);
    if (!hasFeatureKeyword)
      violations.push({ file: rel, lineNo: 1, issue: 'Missing Feature: keyword at top of file', snippet: lines[0]?.trim() || '' });

    const scenarios = (content.match(/^\s*Scenario(\s+Outline)?:/gm) || []).length;
    totalScenarios += scenarios;

    lines.forEach((line, idx) => {
      if (/^\s*(Given|When|Then|And)\s.*(click\s+the\s+button|enter\s+text|navigate\s+to\s+URL)/i.test(line)) {
        violations.push({ file: rel, lineNo: idx+1, issue: 'Step uses UI-level language instead of business language', snippet: line.trim() });
      }
    });
  }

  return {
    result:     violations.length === 0 ? 'Yes' : 'No',
    evidence:   `${featureFiles.length} feature file(s), ${totalScenarios} scenario(s). ${violations.length} issue(s) found.`,
    violations: violations.slice(0, 20),
  };
}

function checkQAFAssertions(repoPath, files) {
  const hits = searchInFiles(files,
    /Assert\.(assertEquals|assertTrue|assertFalse|assertNotNull|assertNull|assertThat)|assertThat\s*\(/,
    repoPath
  );

  // WAF/QAF framework assertion patterns:
  // - Validator.assertTrue / Validator.assertEquals (WAF Validator class)
  // - Reporter.logWithScreenShot + assertion message
  // - SoftAssertions, verifyThat, Assertions.assertThat (AssertJ)
  // - QAFTestStep verification methods (verifyXxx, assertXxx in step defs)
  const wafHits = searchInFiles(files,
    /Validator\.(assertTrue|assertEquals|assertFalse|assertNotNull|assertNull|assertContains|assertMatches)|SoftAssertions|verifyThat\s*\(|Assertions\.assertThat|\.(verify|assert)[A-Z]\w+\s*\(/,
    repoPath
  );

  const allHits = hits.length + wafHits.length;
  if (allHits > 0) return _yes(`${allHits} assertion(s) found (${hits.length} JUnit/TestNG, ${wafHits.length} WAF/Validator)`);

  const testFiles = files.filter(f => /test|step/i.test(path.basename(f)));
  const violations = testFiles.map(f => ({
    file: path.relative(repoPath,f), lineNo: '', issue: 'No Assert.* or Validator.assert* calls found — test has no validation', snippet: ''
  }));
  return _no('No TestNG/JUnit/WAF assertions found in test files', violations);
}

function checkQAFScreenshots(repoPath, files) {
  const shots = searchInFiles(files, /takeScreenshot\s*\(|\.screenshot\s*\(/i, repoPath);
  if (shots.length === 0) return _yes('No explicit screenshots — framework handles on failure (acceptable)');

  let nearAssert = 0;
  for (const file of files) {
    const content = readFile(file);
    const lines   = content.split('\n');
    lines.forEach((line, idx) => {
      if (/takeScreenshot\s*\(|\.screenshot\s*\(/i.test(line)) {
        const window = lines.slice(Math.max(0,idx-3), idx+4).join(' ');
        if (/assert|verify|validate|expect/i.test(window)) nearAssert++;
      }
    });
  }

  const ratio = Math.round((nearAssert / shots.length) * 100);
  const violations = shots.filter((_, i) => i >= nearAssert).slice(0,10).map(h => ({
    file: h.relativePath, lineNo: h.lineNo,
    issue: 'Screenshot taken outside of assertion/validation context',
    snippet: h.line
  }));

  return {
    result:     ratio >= 70 ? 'Yes' : 'No',
    evidence:   `${shots.length} screenshot call(s); ${nearAssert} near assertions (${ratio}%)`,
    violations: ratio >= 70 ? [] : violations,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// PLAYWRIGHT (TYPESCRIPT) — FW1–FW14
// ═══════════════════════════════════════════════════════════════════════════════
function runPlaywrightStandards(repoInfo) {
  const { repoPath } = repoInfo;
  const tsFiles      = collectFiles(repoPath, ['.ts', '.js']);
  const featureFiles = collectFiles(repoPath, ['.feature']);

  return {
    FW1:  checkPWConfig(repoPath),
    FW2:  checkPWPageObjects(repoPath, tsFiles),
    FW3:  checkFixtures(repoPath, tsFiles),
    FW4:  checkLocators(repoPath, tsFiles),
    FW5:  checkTSStrict(repoPath),
    FW6:  checkEnvHardcoding(repoPath, tsFiles),
    FW7:  checkHardcodedTestData(repoPath, tsFiles),
    FW8:  checkPasswords(repoPath, tsFiles),
    FW9:  checkStaticWaitsTS(repoPath, tsFiles),
    FW10: checkBDD(repoPath, featureFiles),
    FW11: checkPWAssertions(repoPath, tsFiles),
    FW12: checkPWScreenshots(repoPath, tsFiles),
    FW13: checkPWDependencies(repoPath),
    FW14: checkOctaneIntegrationPlaywright(repoPath),
  };
}

function checkPWConfig(repoPath) {
  const candidates = ['playwright.config.ts','playwright.config.js'].map(f => path.join(repoPath,f));
  let configFile = null, content = '';
  for (const c of candidates) { if (fs.existsSync(c)) { configFile = c; content = readFile(c); break; } }
  if (!configFile) return _no('playwright.config.ts not found at repo root', [{
    file: 'playwright.config.ts', lineNo: '', issue: 'Create playwright.config.ts with baseURL, timeout, retries, reporter', snippet: ''
  }]);

  const required = [
    { key: 'baseURL',  pat: /baseURL\s*:/ },
    { key: 'timeout',  pat: /timeout\s*:/  },
    { key: 'retries',  pat: /retries\s*:/  },
    { key: 'reporter', pat: /reporter\s*:/ },
  ];
  const missing = required.filter(r => !r.pat.test(content));
  const present = required.filter(r =>  r.pat.test(content)).map(r => r.key);

  if (missing.length === 0) return _yes(`playwright.config.ts found — all required fields present: [${present.join(', ')}]`);

  const violations = missing.map(m => ({
    file: path.relative(repoPath, configFile), lineNo: '',
    issue: `playwright.config.ts missing required field: '${m.key}'`, snippet: ''
  }));
  return _no(`playwright.config.ts missing: [${missing.map(m=>m.key).join(', ')}]`, violations);
}

function checkPWPageObjects(repoPath, files) {
  const pageDirs = ['pages','pageObjects','page-objects','screens','components'];
  for (const dir of pageDirs) {
    const full = path.join(repoPath, dir);
    if (fs.existsSync(full)) {
      const count = collectFiles(full, ['.ts','.js']).length;
      return _yes(`Page object directory found: ${dir}/ (${count} file(s))`);
    }
  }
  const hits = searchInFiles(files, /export\s+(?:default\s+)?class\s+\w+(?:Page|Screen|Component)\b/, repoPath);
  if (hits.length > 0) return _yes(`${hits.length} Page/Screen class(es) found following POM pattern`);

  return _no('No POM structure found — no pages/ directory or XxxPage class exports', [{
    file: '', lineNo: '', issue: "Create a pages/ directory with 'export class LoginPage' pattern", snippet: ''
  }]);
}

function checkFixtures(repoPath, files) {
  const fixtureDefs = searchInFiles(files, /(?:test|base)\.extend\s*</, repoPath);
  const fixtureFiles = files.filter(f => /fixture/i.test(path.basename(f)));

  if (fixtureDefs.length > 0 || fixtureFiles.length > 0) {
    return _yes(`Fixtures found: ${fixtureDefs.length} extend<> definition(s), ${fixtureFiles.length} fixture file(s)`);
  }

  const beforeEachHits = searchInFiles(files, /beforeEach\s*\(\s*async/, repoPath);
  if (beforeEachHits.length > 3) {
    const violations = beforeEachHits.map(h => ({
      file: h.relativePath, lineNo: h.lineNo,
      issue: 'Repeated beforeEach block — consider replacing with Playwright fixture',
      snippet: h.line
    }));
    return _no(`${beforeEachHits.length} beforeEach block(s) found, no fixtures defined`, violations);
  }
  return _yes('No excessive beforeEach duplication detected');
}

function checkLocators(repoPath, files) {
  const goodHits = searchInFiles(files, /\.(getByRole|getByTestId|getByLabel|getByText|getByPlaceholder)\s*\(/, repoPath);
  const xpathHits = searchInFiles(files, /\.locator\s*\(\s*['"`]\/\//, repoPath);
  const cssHits   = searchInFiles(files, /\.locator\s*\(\s*['"`][#.\[][^'"`]{5,}/, repoPath);

  const total   = goodHits.length + xpathHits.length + cssHits.length;
  const ratio   = total > 0 ? Math.round((goodHits.length / total) * 100) : 100;
  const passed  = ratio >= 60 || total === 0;

  const violations = [
    ...xpathHits.map(h => ({ file: h.relativePath, lineNo: h.lineNo, issue: 'XPath locator — use getByRole/getByTestId instead', snippet: h.line })),
    ...cssHits.map(h  => ({ file: h.relativePath, lineNo: h.lineNo, issue: 'Fragile CSS locator — prefer semantic locator', snippet: h.line })),
  ];

  return {
    result:   passed ? 'Yes' : 'No',
    evidence: total === 0
      ? 'No locators found to evaluate'
      : `${goodHits.length} semantic / ${xpathHits.length+cssHits.length} fragile locator(s) — ${ratio}% best practice`,
    violations: passed ? [] : violations,
  };
}

function checkTSStrict(repoPath) {
  const tscPath = path.join(repoPath, 'tsconfig.json');
  if (!fs.existsSync(tscPath)) return _no('tsconfig.json not found at repo root', [{
    file: 'tsconfig.json', lineNo: '', issue: 'Add tsconfig.json with "strict": true in compilerOptions', snippet: ''
  }]);

  let parsed;
  try { parsed = JSON.parse(readFile(tscPath).replace(/\/\/.*/g,'')); } catch { return _no('tsconfig.json could not be parsed', []); }

  const strict = parsed?.compilerOptions?.strict === true;
  const noImpl = parsed?.compilerOptions?.noImplicitAny === true;

  if (strict || noImpl) return _yes(`TypeScript strict mode enabled (${strict ? '"strict": true' : '"noImplicitAny": true'})`);
  return _no('TypeScript strict mode not enabled', [{
    file: 'tsconfig.json', lineNo: '', issue: 'Add "strict": true to compilerOptions in tsconfig.json', snippet: ''
  }]);
}

function checkHardcodedTestData(repoPath, files) {
  const patterns = [
    { p: /(?<![a-zA-Z])\d{10,}(?![a-zA-Z])/,   label: 'Long numeric literal (possible account/card number)' },
    { p: /\d{3}-\d{2}-\d{4}/,                   label: 'SSN-like pattern' },
    { p: /amount\s*[:=]\s*\d{4,}/i,             label: 'Hardcoded monetary amount' },
    { p: /accountNumber\s*[:=]\s*["'`]\d{5,}/i, label: 'Hardcoded account number' },
  ];

  const violations = [];
  for (const { p, label } of patterns) {
    searchInFiles(files, p, repoPath).forEach(h => {
      if (!h.line.startsWith('//') && !h.line.startsWith('*')) {
        violations.push({ file: h.relativePath, lineNo: h.lineNo, issue: `${label}: ${h.line.substring(0,80)}`, snippet: h.line });
      }
    });
  }

  return violations.length === 0
    ? _yes('No hardcoded test data detected')
    : _no(`${violations.length} potential hardcoded test data instance(s)`, violations);
}

function checkStaticWaitsTS(repoPath, files) {
  const hits = searchInFiles(files, /waitForTimeout\s*\(\s*\d{3,}|setTimeout\s*\([^,]+,\s*\d{4,}\)/, repoPath);
  const violations = hits.map(h => ({
    file: h.relativePath, lineNo: h.lineNo,
    issue: 'Static wait with hardcoded ms — use waitFor() smart waits instead',
    snippet: h.line
  }));
  return hits.length === 0
    ? _yes('No hardcoded waitForTimeout() / setTimeout() static waits found')
    : _no(`${hits.length} static wait(s) found`, violations);
}

function checkPWAssertions(repoPath, files) {
  const hits = searchInFiles(files, /await\s+expect\s*\(|expect\s*\(.*\)\.(toHave|toBe|toContain|toBeVisible|toBeEnabled)/, repoPath);
  if (hits.length > 0) return _yes(`${hits.length} Playwright expect() assertion(s) found`);

  const testFiles = files.filter(f => /spec|test/i.test(path.basename(f)));
  const violations = testFiles.map(f => ({
    file: path.relative(repoPath,f), lineNo: '', issue: 'No expect() assertions found — test has no validation', snippet: ''
  }));
  return _no('No Playwright expect() assertions found in test files', violations);
}

function checkPWScreenshots(repoPath, files) {
  const configFile = ['playwright.config.ts','playwright.config.js']
    .map(f => path.join(repoPath,f)).find(f => fs.existsSync(f));
  const config = configFile ? readFile(configFile) : '';

  if (/screenshot\s*:\s*['"`]only-on-failure['"`]/i.test(config))
    return _yes("Screenshots set to 'only-on-failure' in playwright.config — correct pattern");

  if (/screenshot\s*:\s*['"`]on['"`]/i.test(config)) {
    return _no("Screenshots set to 'on' (always) — change to 'only-on-failure'", [{
      file: path.relative(repoPath, configFile), lineNo: '',
      issue: "Set screenshot: 'only-on-failure' in playwright.config.ts use object", snippet: ''
    }]);
  }

  const explicitShots = searchInFiles(files, /(?<!toHave)Screenshot\s*\(/, repoPath);
  if (explicitShots.length > 5) {
    const violations = explicitShots.map(h => ({
      file: h.relativePath, lineNo: h.lineNo,
      issue: 'Explicit .screenshot() call — should only be at validation steps',
      snippet: h.line
    }));
    return _no(`${explicitShots.length} explicit screenshot call(s) found`, violations);
  }

  return _yes('No excessive screenshot usage detected');
}

function checkPWDependencies(repoPath) {
  const pkgPath = path.join(repoPath, 'package.json');
  if (!fs.existsSync(pkgPath)) return _no('package.json not found', []);

  let pkg;
  try { pkg = JSON.parse(readFile(pkgPath)); } catch { return _no('package.json could not be parsed', []); }

  const deps = { ...pkg.dependencies, ...pkg.devDependencies };
  const pwVer = deps['@playwright/test'] || deps['playwright'] || 'not found';

  const pinned = Object.entries(deps)
    .filter(([, v]) => /^\d/.test(v))
    .map(([name, ver]) => ({
      file: 'package.json', lineNo: '',
      issue: `${name}@${ver} pinned to exact version — use ^${ver} for patch updates`,
      snippet: `"${name}": "${ver}"`
    }));

  return {
    result:   pinned.length <= 3 ? 'Yes' : 'No',
    evidence: `@playwright/test: ${pwVer}. ${pinned.length} package(s) with exact-pinned versions.`,
    violations: pinned,
  };
}

// ─── Shared helpers ───────────────────────────────────────────────────────────
function _yes(evidence)            { return { result: 'Yes',    evidence, violations: [] }; }
function _no(evidence, violations) { return { result: 'No',     evidence, violations: violations || [] }; }
function _manual(hint)             { return { result: 'Manual', evidence: hint,     violations: [] }; }

module.exports = {
  runFrameworkStandards,
  checkOctaneIntegrationQAF,
  checkOctaneIntegrationPlaywright,
};

// ═══════════════════════════════════════════════════════════════════════════════
// OCTANE INTEGRATION CHECKS — used by both QAF (FW13) and Playwright (FW14)
// Two integration methods supported:
//   Method 1 — application.properties (QAF) or playwright.config.ts reporter (PW)
//   Method 2 — ResultLogger post block in hyperexecute.yaml (both)
// ═══════════════════════════════════════════════════════════════════════════════

function checkOctaneIntegrationQAF(repoPath) {
  const violations = [];
  const passing    = [];

  // ── Method 1: application.properties keys ────────────────────────────────
  const propFiles = collectFiles(repoPath, ['.properties'])
    .filter(f => path.basename(f).toLowerCase().includes('application'));

  // octane.test.suite.id is OPTIONAL — some teams don't use test suites
  const REQUIRED_OCTANE_KEYS = [
    'result.updator',
    'octane.testcase.mapper',
    'octane.space',
    'octane.workspace',
    'octane.application.module',
    'octane.release.name',
  ];
  const OPTIONAL_OCTANE_KEYS = [
    'octane.test.suite.id',   // optional — only needed if using Octane test suites
  ];

  let method1Found = false;

  for (const file of propFiles) {
    const content  = readFile(file);
    const rel      = path.relative(repoPath, file);
    const lines    = content.split('\n');

    // Check if this file has any octane keys at all
    if (!/octane\.|result\.updator/i.test(content)) continue;

    method1Found = true;

    // Validate each required key exists and is not commented out
    for (const key of REQUIRED_OCTANE_KEYS) {
      const keyRegex = new RegExp(`^\\s*${key.replace('.','\\.')}\\s*=`, 'm');
      const commentedRegex = new RegExp(`^\\s*#.*${key.replace('.','\\.')}\\s*=`, 'm');

      if (!keyRegex.test(content)) {
        // Check if it's there but commented out
        const isCommented = commentedRegex.test(content);
        violations.push({
          file:    rel,
          lineNo:  '',
          issue:   isCommented
            ? `Octane key '${key}' is commented out — uncomment to enable Octane integration`
            : `Missing required Octane key: '${key}'`,
          snippet: ''
        });
      } else {
        // Key exists — check it has a value
        const valueMatch = content.match(new RegExp(`^${key.replace('.','\\.')}\\s*=\\s*(.+)$`, 'm'));
        if (valueMatch) {
          passing.push(`${key}=${valueMatch[1].trim()}`);
        }
      }
    }

    // Validate specific class values
    const updatorLine = lines.find(l => /^result\.updator\s*=/.test(l));
    if (updatorLine && !updatorLine.includes('OctaneUpdator')) {
      violations.push({
        file: rel, lineNo: lines.indexOf(updatorLine) + 1,
        issue: `result.updator should be 'com.wellsfargo.waf.integration.octane.OctaneUpdator'`,
        snippet: updatorLine.trim()
      });
    }

    const mapperLine = lines.find(l => /^octane\.testcase\.mapper\s*=/.test(l));
    if (mapperLine && !mapperLine.includes('AlmIDFromTestNameMapper')) {
      violations.push({
        file: rel, lineNo: lines.indexOf(mapperLine) + 1,
        issue: `octane.testcase.mapper should be 'com.wellsfargo.waf.integration.octane.AlmIDFromTestNameMapper'`,
        snippet: mapperLine.trim()
      });
    }
  }

  // ── Method 2: ResultLogger in hyperexecute.yaml ───────────────────────────
  const method2Result = checkResultLoggerInHE(repoPath, 'WAF');
  if (method2Result.found) passing.push('ResultLogger post block found in HyperExecute YAML');

  // ── Evaluate overall result ───────────────────────────────────────────────
  if (method1Found && violations.length === 0) {
    return {
      result:   'Yes',
      evidence: `Octane integration via application.properties ✔. Keys configured: ${passing.length}. ${method2Result.found ? 'ResultLogger also configured.' : ''}`,
      violations: []
    };
  }

  if (method2Result.found && !method1Found) {
    return {
      result:   'Yes',
      evidence: `Octane integration via ResultLogger post block in HyperExecute YAML ✔. ${method2Result.evidence}`,
      violations: []
    };
  }

  if (method1Found && violations.length > 0) {
    return {
      result:   'No',
      evidence: `application.properties found but ${violations.length} Octane key issue(s) detected`,
      violations
    };
  }

  return {
    result:   'No',
    evidence: 'No Octane integration found — neither application.properties octane keys nor ResultLogger in hyperexecute.yaml',
    violations: [
      { file: '', lineNo: '', issue: 'Method 1: Add octane.* keys to application.properties — required: result.updator, octane.testcase.mapper, octane.space, octane.workspace, octane.application.module, octane.release.name | optional: octane.test.suite.id', snippet: '' },
      { file: '', lineNo: '', issue: 'Method 2: Add ResultLogger post block to hyperexecute.yaml with curl to apigw.wellsfargo.net/EngEnbl/QTE/TLM/ResultConsumerAPI/v1/result', snippet: '' },
    ]
  };
}

function checkOctaneIntegrationPlaywright(repoPath) {
  const passing    = [];
  const violations = [];

  // ── Method 1: test-run-playwright-reporter in playwright.config.ts ────────
  const configCandidates = ['playwright.config.ts', 'playwright.config.js']
    .map(f => path.join(repoPath, f)).filter(f => fs.existsSync(f));

  let method1Found = false;

  for (const configFile of configCandidates) {
    const content = readFile(configFile);
    const rel     = path.relative(repoPath, configFile);
    const lines   = content.split('\n');

    // Check for the WF playwright reporter
    const reporterPattern = /test-run-playwright-reporter|test-run-lib-js.*playwright.*reporter/i;
    if (reporterPattern.test(content)) {
      // Make sure it's not commented out
      const activeReporterLine = lines.find((l, i) => reporterPattern.test(l) && !l.trim().startsWith('//'));
      if (activeReporterLine) {
        method1Found = true;
        passing.push(`WF playwright reporter configured in ${path.basename(configFile)}`);
      } else {
        // Found but commented out
        const commentedLine = lines.find(l => reporterPattern.test(l) && l.trim().startsWith('//'));
        if (commentedLine) {
          violations.push({
            file:    rel,
            lineNo:  lines.indexOf(commentedLine) + 1,
            issue:   'WF test-run-playwright-reporter is commented out — uncomment to enable Octane result reporting',
            snippet: commentedLine.trim()
          });
        }
      }
    }
  }

  // ── Method 2: ResultLogger post block in hyperexecute.yaml ───────────────
  const method2Result = checkResultLoggerInHE(repoPath, 'Playwright');
  if (method2Result.found) passing.push('ResultLogger post block found in HyperExecute YAML');

  // ── Evaluate overall result ───────────────────────────────────────────────
  if (method1Found) {
    return {
      result:   'Yes',
      evidence: `Octane integration via WF playwright reporter in playwright.config ✔. ${method2Result.found ? 'ResultLogger also configured.' : ''}`,
      violations: []
    };
  }

  if (method2Result.found) {
    return {
      result:   'Yes',
      evidence: `Octane integration via ResultLogger post block in HyperExecute YAML ✔. ${method2Result.evidence}`,
      violations: []
    };
  }

  // Neither method found
  const allViolations = [...violations,
    { file: '', lineNo: '', issue: "Method 1: Add '@wellsfargo/test-run-lib-js/lib/playwright/test-run-playwright-reporter' to reporter array in playwright.config.ts", snippet: '' },
    { file: '', lineNo: '', issue: 'Method 2: Add ResultLogger post block to hyperexecute.yaml with curl to apigw.wellsfargo.net/EngEnbl/QTE/TLM/ResultConsumerAPI/v1/result', snippet: '' },
  ];

  return {
    result:   'No',
    evidence: 'No Octane integration found — neither WF playwright reporter in playwright.config nor ResultLogger in hyperexecute.yaml',
    violations: allViolations
  };
}

// ── Shared: ResultLogger detection in hyperexecute.yaml ─────────────────────
// Looks for the post: block with the WF ResultConsumer API curl call
// Works for both WAF (source: WAF) and Playwright (source: HE)
function checkResultLoggerInHE(repoPath, repoTypeLabel) {
  const yamlFiles = collectFiles(repoPath, ['.yml', '.yaml'])
    .filter(f => {
      const base = path.basename(f).toLowerCase();
      return base.includes('hyperexecute') || base.includes('he.y') || base.startsWith('he.');
    });

  // Fallback: check all YAMLs if no HE-named file found
  const filesToCheck = yamlFiles.length > 0
    ? yamlFiles
    : collectFiles(repoPath, ['.yml', '.yaml']);

  for (const file of filesToCheck) {
    const content = readFile(file);
    const rel     = path.relative(repoPath, file);

    // Must have a post: block
    if (!/^post\s*:/m.test(content)) continue;

    // Must have the ResultConsumer API endpoint
    const hasResultAPI  = /ResultConsumerAPI\/v1\/result/i.test(content);
    // Must have WF OAuth token fetch
    const hasOAuthToken = /apiidp\.wellsfargo\.net\/oauth\/token/i.test(content);
    // Must have bearer_command or similar curl
    const hasBearerCmd  = /bearer_command|CONS_KEY|CONS_SECRET/i.test(content);

    if (hasResultAPI && hasOAuthToken && hasBearerCmd) {
      // Extract source to confirm it matches repo type expectation
      const sourceMatch = content.match(/"source"\s*:\s*"([^"]+)"/i);
      const source      = sourceMatch ? sourceMatch[1] : 'unknown';

      return {
        found:    true,
        file:     rel,
        evidence: `ResultLogger configured in ${rel} (source: ${source}). Calls ResultConsumerAPI with OAuth token.`
      };
    }
  }

  return { found: false, evidence: '' };
}

// Export the two octane functions for use in the framework check routers
module.exports.checkOctaneIntegrationQAF        = checkOctaneIntegrationQAF;
module.exports.checkOctaneIntegrationPlaywright  = checkOctaneIntegrationPlaywright;

'use strict';
const { execSync } = require('child_process');
const fs   = require('fs');
const path = require('path');

function runGITMaintenance(repoInfo) {
  const { repoPath } = repoInfo;
  return {
    GIT0: checkDefaultBranch(repoPath),
    GIT1: checkEnterpriseGit(repoPath),
    GIT2: checkRepoMaintenance(repoPath),
    GIT3: checkFrequentCommits(repoPath),
    GIT4: checkBranchingStrategy(repoPath),
    GIT5: checkCodeReviews(repoPath),
    GIT6: {
      result: 'Manual',
      evidence: 'Manual check — review last 10 merge commits in GitHub and confirm onsite counterparts/stakeholders are listed as reviewers before merging to main',
      violations: []
    },
  };
}

function git(repoPath, cmd) {
  try {
    return execSync(
      `git -C "${repoPath}" ${cmd}`,
      { encoding: 'utf8', timeout: 10000, stdio: ['pipe', 'pipe', 'pipe'] }
    ).trim();
  } catch { return null; }
}

/**
 * Robustly determine the remote default branch using multiple strategies:
 *
 * Strategy 1 — symbolic-ref: git symbolic-ref refs/remotes/origin/HEAD
 *   Works when origin/HEAD is set (most clones). Returns "refs/remotes/origin/main" etc.
 *
 * Strategy 2 — remote set-head: git remote set-head origin --auto
 *   Queries GitHub API to resolve default. Requires network. Then re-tries strategy 1.
 *
 * Strategy 3 — .git/config init.defaultBranch
 *   Reads the local git config for an explicit defaultBranch override.
 *
 * Strategy 4 — branch listing heuristic
 *   If all else fails, looks for branches in priority order:
 *   main > master > develop > trunk > any single branch present
 *
 * Returns { defaultBranch, method } where method describes how it was found.
 */
function resolveDefaultBranch(repoPath) {
  // Strategy 1: symbolic-ref (fast, offline)
  let symRef = git(repoPath, 'symbolic-ref refs/remotes/origin/HEAD');
  if (symRef) {
    const branch = symRef.replace(/^refs\/remotes\/origin\//, '').trim();
    if (branch && !branch.includes(' ')) {
      return { defaultBranch: branch, method: 'symbolic-ref (origin/HEAD)' };
    }
  }

  // Strategy 2: try to auto-detect from remote (needs network — fail silently)
  git(repoPath, 'remote set-head origin --auto');
  symRef = git(repoPath, 'symbolic-ref refs/remotes/origin/HEAD');
  if (symRef) {
    const branch = symRef.replace(/^refs\/remotes\/origin\//, '').trim();
    if (branch && !branch.includes(' ')) {
      return { defaultBranch: branch, method: 'remote set-head origin --auto' };
    }
  }

  // Strategy 3: read .git/config for init.defaultBranch
  const gitConfig = path.join(repoPath, '.git', 'config');
  if (fs.existsSync(gitConfig)) {
    const configContent = fs.readFileSync(gitConfig, 'utf8');
    const match = configContent.match(/defaultBranch\s*=\s*(\S+)/i);
    if (match) {
      return { defaultBranch: match[1].trim(), method: '.git/config defaultBranch' };
    }
  }

  // Strategy 4: branch listing heuristic
  const allBranchesRaw = git(repoPath, 'branch -a') || '';
  const allBranches = allBranchesRaw
    .split('\n')
    .map(b => b.trim().replace(/^\*\s*/, '').replace(/^remotes\/origin\//, '').trim())
    .filter(b => b && !b.startsWith('HEAD ->') && !b.includes(' -> '));

  const priority = ['main', 'master', 'develop', 'trunk'];
  for (const p of priority) {
    if (allBranches.includes(p)) {
      return { defaultBranch: p, method: 'branch heuristic (common name)' };
    }
  }

  // Last resort: only one branch exists
  const uniqueBranches = [...new Set(allBranches)].filter(b => !b.includes('/'));
  if (uniqueBranches.length === 1) {
    return { defaultBranch: uniqueBranches[0], method: 'only branch present' };
  }

  return { defaultBranch: 'main', method: 'fallback default' };
}

// GIT0 — Default branch check
// Exported so audit.js can call it independently for the pre-run popup
function checkDefaultBranch(repoPath) {
  const currentBranch = git(repoPath, 'rev-parse --abbrev-ref HEAD');

  if (!currentBranch) {
    return {
      result: 'No',
      evidence: 'Unable to determine current branch — ensure the repo is properly initialised',
      currentBranch: null,
      defaultBranch: null,
      isDefault: false,
      violations: [{ file: '', lineNo: '', issue: 'Cannot read current branch from .git/HEAD', snippet: '' }]
    };
  }

  const { defaultBranch, method } = resolveDefaultBranch(repoPath);
  const isDefault = currentBranch === defaultBranch;

  return {
    result:        isDefault ? 'Yes' : 'No',
    evidence:      `Current branch: '${currentBranch}' | Default branch: '${defaultBranch}' (detected via: ${method})`,
    currentBranch,
    defaultBranch,
    isDefault,
    violations: isDefault ? [] : [{
      file:    '',
      lineNo:  '',
      issue:   `Audit is running on '${currentBranch}', not the default branch '${defaultBranch}'. Switch with: git checkout ${defaultBranch}`,
      snippet: ''
    }]
  };
}

// GIT1 — Enterprise git remote
function checkEnterpriseGit(repoPath) {
  const gitConfig = path.join(repoPath, '.git', 'config');
  if (!fs.existsSync(gitConfig)) return {
    result: 'No',
    evidence: 'Not a git repository (.git folder missing)',
    violations: [{ file: '', lineNo: '', issue: 'Initialise a git repository and push to enterprise GitHub', snippet: '' }]
  };

  const content  = fs.readFileSync(gitConfig, 'utf8');
  const urlMatch = content.match(/url\s*=\s*(.+)/);
  if (!urlMatch) return {
    result: 'No',
    evidence: 'No remote URL configured in .git/config',
    violations: [{ file: '.git/config', lineNo: '', issue: 'Add a remote origin pointing to the enterprise GitHub URL', snippet: '' }]
  };

  const url          = urlMatch[1].trim();
  const isEnterprise = /wellsfargo|wf\.com|github\..*\.internal/i.test(url);
  const isGit        = /github|gitlab|bitbucket|\.git$/.test(url);

  return {
    result:   isGit ? 'Yes' : 'No',
    evidence: `Remote URL: ${url}${isEnterprise ? ' (Enterprise GitHub ✔)' : ''}`,
    violations: isGit ? [] : [{
      file: '.git/config', lineNo: '',
      issue: `Remote URL does not appear to be a git hosting service: ${url}`,
      snippet: url
    }]
  };
}

// GIT2 — Repo maintenance / recent activity
function checkRepoMaintenance(repoPath) {
  const lastDate = git(repoPath, 'log -1 --format="%ci"');
  if (!lastDate) return {
    result: 'No',
    evidence: 'No commits found in repository',
    violations: [{ file: '', lineNo: '', issue: 'Repository has no commits — ensure code is committed and pushed', snippet: '' }]
  };

  const daysSince = Math.floor((Date.now() - new Date(lastDate).getTime()) / 86400000);
  const lastRel   = git(repoPath, 'log -1 --format="%ar"');
  const count     = (git(repoPath, 'log --oneline -30') || '').split('\n').filter(Boolean).length;
  const passed    = daysSince <= 90 && count >= 3;

  return {
    result:   passed ? 'Yes' : 'No',
    evidence: `Last commit: ${lastRel} (${daysSince} day(s) ago). ${count} recent commit(s).`,
    violations: passed ? [] : [{
      file: '', lineNo: '',
      issue: `Last commit was ${daysSince} day(s) ago — repository appears stale or inactive`,
      snippet: ''
    }]
  };
}

// GIT3 — Frequent check-ins
function checkFrequentCommits(repoPath) {
  const log30 = git(repoPath, 'log --oneline --since="30 days ago"');
  const log7  = git(repoPath, 'log --oneline --since="7 days ago"');
  const c30   = log30 ? log30.split('\n').filter(Boolean).length : 0;
  const c7    = log7  ? log7.split('\n').filter(Boolean).length  : 0;
  const passed = c30 >= 4;

  return {
    result:   passed ? 'Yes' : 'No',
    evidence: `${c30} commit(s) in last 30 days, ${c7} in last 7 days`,
    violations: passed ? [] : [{
      file: '', lineNo: '',
      issue: `Only ${c30} commit(s) in 30 days — aim for at least weekly check-ins`,
      snippet: ''
    }]
  };
}

// GIT4 — Branching strategy
function checkBranchingStrategy(repoPath) {
  const raw = git(repoPath, 'branch -a');
  if (!raw) return {
    result: 'No',
    evidence: 'Unable to list branches',
    violations: [{ file: '', lineNo: '', issue: 'Ensure git is installed and the repo has at least one branch', snippet: '' }]
  };

  // Collect all unique branch names (local + remote, deduplicated)
  const branches = [...new Set(
    raw.split('\n')
      .map(b => b.trim().replace(/^\*\s*/, '').replace(/^remotes\/origin\//, '').trim())
      .filter(b => b && !b.includes('HEAD ->') && !b.includes(' -> ') && b !== '')
  )];

  // Resolve the actual default branch via the same 4-strategy detection as GIT0
  const { defaultBranch } = resolveDefaultBranch(repoPath);

  // If resolveDefaultBranch fell back to a heuristic and that branch is not present,
  // use the current checked-out branch as the default (covers local-only repos
  // where origin/HEAD is not set).
  const currentBranch = (git(repoPath, 'rev-parse --abbrev-ref HEAD') || '').trim();
  const effectiveDefault = branches.some(b => b === defaultBranch)
    ? defaultBranch
    : (currentBranch || defaultBranch);

  // ── Check 1: Default branch exists ───────────────────────────────────────
  const hasDefault   = branches.some(b => b === effectiveDefault);

  // ── Check 2: At least one OTHER branch besides default (any name) ─────────
  const otherBranches = branches.filter(b => b !== defaultBranch);
  const hasOther      = otherBranches.length > 0;

  // ── Check 3: PRs are being raised — evidence of merge commits into default ─
  // PR merges leave merge commits with recognisable messages in git log.
  const mergeLog   = git(repoPath, 'log --merges --oneline -20') || '';
  const mergeCount = mergeLog.split('\n').filter(Boolean).length;
  const prLog      = git(repoPath, 'log --oneline -50 --format="%s"') || '';
  const prRefs     = prLog.split('\n').filter(l =>
    /Merge pull request|Merge branch .* into|PR #|\(#\d+\)|Reviewed-by:/i.test(l)
  ).length;
  const hasPRs = mergeCount >= 1 || prRefs >= 1;

  // Total commit count — used to decide if this is a brand-new repo
  const commitCount = (git(repoPath, 'rev-list --count HEAD') || '0').trim();
  const isNewRepo   = parseInt(commitCount, 10) <= 5;

  // ── Overall pass/fail ─────────────────────────────────────────────────────
  // PASS: default branch exists + at least 1 other branch + PRs evident
  // New repos (<=5 commits) get a grace pass on PRs — they may not have had any yet
  const passed = hasDefault && hasOther && (hasPRs || isNewRepo);

  const violations = [];
  if (!hasDefault) {
    violations.push({
      file: '', lineNo: '',
      issue: `Default branch '${effectiveDefault}' not found in repository`,
      snippet: ''
    });
  }
  if (!hasOther) {
    violations.push({
      file: '', lineNo: '',
      issue: `Only the default branch '${effectiveDefault}' exists — create separate branches for each piece of work and raise PRs to merge back into '${effectiveDefault}'`,
      snippet: ''
    });
  }
  if (hasDefault && hasOther && !hasPRs && !isNewRepo) {
    violations.push({
      file: '', lineNo: '',
      issue: `No PR merge commits found in git log — ensure all code changes go through Pull Requests before merging into '${effectiveDefault}'. Direct pushes to the default branch bypass code review.`,
      snippet: ''
    });
  }

  const evidenceParts = [
    `Default: '${effectiveDefault}'`,
    `Other branches: ${otherBranches.length} (${otherBranches.slice(0,5).join(', ')}${otherBranches.length > 5 ? '…' : ''})`,
    `PR merge commits: ${mergeCount}`,
  ];

  return {
    result:   passed ? 'Yes' : 'No',
    evidence: evidenceParts.join(' | '),
    violations: passed ? [] : violations,
  };
}

// GIT5 — Code reviews via PR merges
function checkCodeReviews(repoPath) {
  const merges     = git(repoPath, 'log --merges --oneline -20');
  const mergeCount = merges ? merges.split('\n').filter(Boolean).length : 0;
  const recent     = git(repoPath, 'log --oneline -30 --format="%s"') || '';
  const prRefs     = recent.split('\n').filter(l => /Merge pull request|PR #|\(#\d+\)|Reviewed-by:/i.test(l)).length;
  const passed     = mergeCount >= 3 || prRefs >= 2;

  return {
    result:   passed ? 'Yes' : 'No',
    evidence: `${mergeCount} merge commit(s), ${prRefs} PR reference(s) in recent commit messages`,
    violations: passed ? [] : [{
      file: '', lineNo: '',
      issue: `Only ${mergeCount} merge commit(s) found — ensure PRs are raised and reviewed before merging to main`,
      snippet: ''
    }]
  };
}

module.exports = { runGITMaintenance, checkDefaultBranch };

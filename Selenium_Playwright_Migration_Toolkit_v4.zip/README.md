# Selenium → Playwright Migration Toolkit

Migrate an entire Selenium + Java + QAF + Cucumber repository to Playwright + TypeScript — output as plain Playwright tests, no `playwright-bdd` required.

## Features

- **Whole-repo scanning** — point it at your entire Java source tree (not just `pages/`, `steps/`, `features/`) and it classifies every file automatically.
- **Plain Playwright output** — each Gherkin step in a `.feature` file becomes a `test.step()` inside a normal `test()`. No `playwright-bdd`, no `.feature-gen`, no Given/When/Then runtime DSL.
- **Auto-classification** — every `.java` file is classified as `page`, `steps`, `infra`, `config`, `type`, `util`, or `unknown`, and routed to a clean, standards-based folder structure.
- **Desktop Chrome** — uses installed Chrome, not bundled Playwright browsers.
- **Secure Auth** — credentials encrypted, session reused across test runs.
- **CoVe Verification** — `scripts/verify.js` cross-checks generated output against the source files and the migration manifest before you trust it.

---

## How It Works

```
@pw-orchestrator start
      │
      ├── node scripts/migrate.js
      │     ├── Walk _source-java/ recursively (entire repo, any folder layout)
      │     ├── classifyJavaFile() → page | steps | infra | config | type | util | unknown
      │     ├── Page objects   → src/pages/*.page.ts        (skeleton, locators mapped)
      │     ├── Step defs      → src/steps/*.steps.ts        (skeleton, plain async functions)
      │     ├── Utils          → src/utils/*.utils.ts        (skeleton)
      │     ├── Config/consts  → src/config/*.config.ts      (auto-converted, no TODOs)
      │     ├── Models/DTOs    → src/types/*.types.ts        (auto-converted, no TODOs)
      │     ├── Infra/runners  → docs/migration-notes/infrastructure.md (documented, not ported — Playwright replaces this natively)
      │     ├── Unrecognized   → src/legacy/**/*.legacy.ts   (flagged for manual review)
      │     └── *.feature      → tests/specs/*.spec.ts       (compiled directly — each step → test.step())
      │
      ├── Convert each pending page/step/util method, one file at a time
      │
      └── node scripts/verify.js   (CoVe check — re-run after every file)
```

A feature file's steps are matched to your step-definition functions using the same Cucumber-expression matching Java/Cucumber uses (`{string}`, `{int}`, quoted literals, etc.), so existing step text doesn't need to be rewritten. Unmatched steps are still emitted as a `test.step()` with a `// TODO: Step not implemented` body rather than failing the whole file, so `verify.js` can point you at exactly what's left.

---

## Quick Start

```bash
# 1. Setup
./setup.sh        # or setup.bat on Windows

# 2. Copy your ENTIRE Java source repo in — any structure, any depth
cp -r /your/project/* _source-java/

# 3. Run migration (in VS Code with Copilot)
@pw-orchestrator start
```

### After migration

```bash
# 1. Setup authentication (REQUIRED before running tests)
npm run auth:setup
# Opens browser → you log in manually → session saved to auth.json

# 2. Run tests
npm test

# 3. Debug failures
# Use your existing Playwright MCP / debugging agents for this —
# this toolkit's job ends once migration + verification pass.
```

---

## Secure Authentication

**Your credentials are never stored in plain text or exposed to test/debug tooling.**

```bash
npm run auth:setup    # Interactive login (recommended)
npm run auth:check    # Check auth status
npm run auth:clear    # Clear auth when done
```

See `docs/AUTHENTICATION.md` for full details, including how `auth.json` is wired into `playwright.config.ts` via `storageState`.

---

## Agents

| Agent | Purpose |
|-------|---------|
| `@pw-orchestrator` | Drives the full migration — processes pages → steps → utils, one file/method at a time, then runs verification |
| `@pw-migrate` | Re-convert a single file (page, step, or util) |
| `@pw-verify` | Run CoVe verification across all categories, or a single file |

Agents related to Playwright MCP debugging and the old `@pw-debug` workflow have been removed from this toolkit. Once migration and verification are complete, use whatever Playwright execution/debugging agents your team already has for test running and failure triage — that's a separate concern from migration.

---

## Configuration

### Login Page Settings

Edit `scripts/auth-setup.js`:

```javascript
const CONFIG = {
  loginUrl: 'https://your-app.com/login',
  selectors: {
    usernameInput: '#username',
    passwordInput: '#password',
    loginButton: 'button[type="submit"]',
    loggedInIndicator: '.user-menu',
  },
};
```

---

## Directory Structure

```
├── _source-java/                     # INPUT: your entire Java repo, any layout
├── src/
│   ├── pages/                        # OUTPUT: page objects (*.page.ts)
│   ├── steps/                        # OUTPUT: step definitions as plain async functions (*.steps.ts)
│   ├── utils/                        # OUTPUT: utility/helper classes (*.utils.ts)
│   ├── config/                       # OUTPUT: constants/config, auto-converted (*.config.ts)
│   ├── types/                        # OUTPUT: models/DTOs, auto-converted (*.types.ts)
│   ├── fixtures/                     # Playwright fixtures wiring pages/steps together
│   └── legacy/                       # Unclassified files, ported as-is for manual review (*.legacy.ts)
├── tests/
│   └── specs/                        # OUTPUT: generated Playwright tests (*.spec.ts) — replaces playwright-bdd
├── features/                         # Original .feature files, kept for traceability
├── docs/
│   ├── AUTHENTICATION.md
│   └── migration-notes/
│       └── infrastructure.md         # Notes on infra/runner files Playwright replaces natively
├── scripts/
│   ├── migrate.js                    # Classifies & scaffolds the entire repo
│   ├── verify.js                     # CoVe verification
│   └── auth-setup.js
├── .github/agents/                   # Copilot agent definitions (single source — no duplication)
├── migration-manifest.json           # Full audit trail: every source file → classification → output path
├── pending-methods.json              # Tracks remaining TODO methods per file, drives the orchestrator loop
├── auth.json                         # Saved auth state (gitignored)
└── playwright.config.ts
```

---

## Classification Categories

`scripts/migrate.js` classifies every `.java` file under `_source-java/` using content and naming heuristics, in this order:

| Category | Detected by | Output |
|----------|-------------|--------|
| `steps` | `@Given`/`@When`/`@Then` annotations | `src/steps/*.steps.ts` — skeleton |
| `infra` | Test runner / driver-lifecycle / reporting plumbing (`@RunWith`, `CucumberOptions`, `WebDriverManager`, `ExtentReports`, hooks, etc.) | Documented in `docs/migration-notes/infrastructure.md`, not ported — Playwright replaces this natively |
| `page` | `@FindBy`, `WebElement` + `By.*`, or `*Page` naming convention | `src/pages/*.page.ts` — skeleton |
| `config` | Mostly `static final` fields, no real methods | `src/config/*.config.ts` — auto-converted |
| `type` | Private fields + matching getters (POJO/DTO), no Selenium | `src/types/*.types.ts` — auto-converted |
| `util` | Everything else with reusable static/helper methods | `src/utils/*.utils.ts` — skeleton |
| `unknown` | Doesn't match any of the above | `src/legacy/**/*.legacy.ts` — ported as-is, flagged for manual review |

Every classification decision is recorded in `migration-manifest.json` (source path → category → output path → review status), so nothing is silently dropped — `verify.js` cross-checks the manifest against disk on every run.

---

## Requirements

- Node.js 18+
- VS Code with GitHub Copilot (for the agents)
- Desktop Chrome installed

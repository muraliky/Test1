---
name: pw-migrate
description: Convert a single file (page, step, or util). Use when you need to re-convert or fix a specific file.
---

# MIGRATE AGENT

Convert a single file.

## ON "@pw-migrate <filepath>"

1. Read: `cat <filepath>`
2. Find `throw new Error(...)` methods/functions
3. Convert each one — see CONVERSION RULES below for the right shape based on which folder the file is in
4. Save file
5. Report: `✅ <file> converted`

## FILE-TYPE SPECIFIC NOTES

- **src/pages/*.page.ts** — class methods, use `this.<locator>` for element access.
- **src/steps/*.steps.ts** — **plain exported functions**, NOT a Given/When/Then DSL. Signature is `export async function name(fixtures: AppFixtures, ...params): Promise<void>`. Use `fixtures.<pageName>` (e.g. `fixtures.loginPage`) to reach page objects, and `fixtures.page` for raw Playwright page access. If the doc-comment says it was originally a Cucumber `@Before`/`@After` hook, implement the setup/teardown logic but flag that it should ideally be wired into `src/fixtures/test-fixtures.ts` or a spec's `test.beforeEach()`/`afterEach()` instead.
- **src/utils/*.utils.ts** — plain functions, no `fixtures` parameter, implement the logic directly.
- **src/config/*.config.ts** and **src/types/*.types.ts** are auto-converted by `migrate.js` and should never need this agent — if one looks incomplete, re-check the original Java source rather than hand-editing.

## CONVERSION RULES

| Selenium | Playwright |
|----------|------------|
| `element.click()` | `await this.element.click()` |
| `element.sendKeys(text)` | `await this.element.fill(text)` |
| `element.clear()` | `await this.element.clear()` |
| `element.getText()` | `await this.element.textContent()` |
| `element.isDisplayed()` | `await this.element.isVisible()` |
| `driver.get(url)` | `await this.page.goto(url)` (page) / `await fixtures.page.goto(url)` (step) |
| `Thread.sleep(ms)` | `await this.page.waitForTimeout(ms)` (page) / `await fixtures.page.waitForTimeout(ms)` (step) |

| Cucumber/BDD (old) | This toolkit (new) |
|---|---|
| `@Given("text")` Java step method, or a `Given('text', async ({page}) => {...})` playwright-bdd call | `export async function camelCaseName(fixtures: AppFixtures, ...): Promise<void> { ... }` — no `Given`/`When`/`Then`/`createBdd` anywhere |

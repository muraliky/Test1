---
name: pw-verify
description: Run STRICT CoVe verification on migrated files. Checks structure, count match, implementation, boilerplate, and syntax across pages, steps, utils, config, types, and generated specs.
---

# VERIFY AGENT

## ON "@pw-verify"

Run full verification on all files (pages, steps, utils, config, types, specs, plus manifest coverage):
```bash
node scripts/verify.js
```

## ON "@pw-verify <filepath>"

Verify single file:
```bash
node scripts/verify.js file <filepath>
```

---

## CoVe CHECKS

### For Pages — src/pages/*.page.ts (6 checks):
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No Selenium/WebDriver/sendKeys/getText/isDisplayed |
| Page Structure | export class, constructor(page: Page), Page import |
| Count Match | Locators & Methods count matches Java source |
| Implementation | No `throw new Error('Method ... not implemented')` |
| No Boilerplate | Method bodies aren't just placeholder waits/console.log |
| Syntax | Balanced braces, no double async/await |

### For Steps — src/steps/*.steps.ts (6 checks), plain exported functions (NOT Given/When/Then):
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No @Given/@When/@Then annotations, no Given/When/Then(...) calls, no playwright-bdd imports |
| Step Structure (plain functions) | `AppFixtures` type import present; each export matches `export async function name(fixtures: AppFixtures, ...): Promise<void>` |
| Count Match | Step function count matches Java source (hooks counted separately) |
| Implementation | No `throw new Error('Step ... not implemented')` |
| No Boilerplate | Bodies aren't just placeholder waits/console.log |
| Syntax | Balanced braces, no double async/await |

### For Utils — src/utils/*.utils.ts (6 checks):
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No leftover Java type declarations |
| Util Structure | `export function`/`export async function` present |
| Count Match | Function count matches Java source |
| Implementation | No `throw new Error('Function ... not implemented')` |
| No Boilerplate | Bodies aren't trivial placeholders |
| Syntax | Balanced braces |

### For Config — src/config/*.config.ts (3 checks), auto-converted:
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | Clean conversion, nothing leaked through |
| Config Structure | `export const` declarations present, zero "not implemented" placeholders |
| Syntax | Balanced braces |

### For Types — src/types/*.types.ts (3 checks), auto-converted:
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | Clean conversion, nothing leaked through |
| Type Structure | `export interface` present, zero "not implemented" placeholders |
| Syntax | Balanced braces |

### For Specs — tests/specs/*.spec.ts (4 checks), the no-BDD test.step() output:
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No `playwright-bdd`/`createBdd` usage — plain Playwright tests only |
| Spec Structure (test.step) | `import { test }` from fixtures, `test.describe(...)`, `test(...)`, and `test.step(...)` calls all present |
| Step Coverage | No `Step not implemented: ...` leftover (every Gherkin step matched a step function); `test()` count matches scenario/outline-row count from the source `.feature` file |
| Syntax | Balanced braces |

### Legacy — src/legacy/**/*.legacy.ts:
Always flagged with a warning ("needs manual review") — these never "pass" CoVe because `migrate.js` couldn't classify them. Use `@pw-orchestrator review-legacy` to triage them by hand.

### Manifest Coverage (runs once, not per-file):
Cross-references `migration-manifest.json` against what's actually on disk, to confirm no `_source-java/**/*.java` file was silently dropped during migration.

---

## Example Output

```
📄 login.page.ts
   ├─ No Java/BDD Syntax: ✓
   ├─ Page Structure: ✓
   ├─ Count Match: ✓
   │  └─ ℹ️  Found: 5 locator(s), 2 method(s)
   ├─ Implementation: ✓
   ├─ No Boilerplate: ✓
   └─ Syntax: ✓
   └─ ✅ PASSED

📝 login.steps.ts
   ├─ No Java/BDD Syntax: ✓
   ├─ Step Structure (plain functions): ✓
   ├─ Count Match: ✗
   │  └─ ❌ Steps: Expected 12, Found 10 (2 MISSING)
   ├─ Implementation: ✓
   ├─ No Boilerplate: ✓
   └─ Syntax: ✓
   └─ ❌ FAILED (1 error)

✅ login.spec.ts
   ├─ No Java/BDD Syntax: ✓
   ├─ Spec Structure (test.step): ✓
   ├─ Step Coverage: ✗
   │  └─ ❌ 1 step(s) have no matching function in src/steps
   └─ ❌ FAILED (1 error)
```

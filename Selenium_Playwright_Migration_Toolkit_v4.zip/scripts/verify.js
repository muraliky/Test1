#!/usr/bin/env node
/**
 * Chain of Verification (CoVe) - STRICT Migration Validation
 *
 * Verifies every category of generated output: pages, steps, utils,
 * config, types, and generated Playwright spec files (tests/specs/*.spec.ts).
 *
 * This is a no-BDD toolkit: step files are plain exported functions
 * (NOT Given/When/Then), and feature files compile straight to
 * tests/specs/*.spec.ts with every Gherkin step wrapped in test.step().
 * The checks below enforce exactly that shape and flag any leftover
 * playwright-bdd usage as an error.
 *
 * USAGE:
 *   npm run verify              - Run full CoVe across every category
 *   npm run verify:file <path>  - Verify a single file
 */

const fs = require('fs');
const path = require('path');

// ═══════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════

const CONFIG = {
  pagesOut: './src/pages',
  stepsOut: './src/steps',
  utilsOut: './src/utils',
  configOut: './src/config',
  typesOut: './src/types',
  legacyOut: './src/legacy',
  specsOut: './tests/specs',
  reportFile: './cove-report.json',
  pendingFile: './pending-methods.json',
  manifestFile: './migration-manifest.json',
  sourceDir: './_source-java',
};

// ═══════════════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════

function getAllFiles(dir, suffix) {
  let results = [];
  if (!fs.existsSync(dir)) return results;

  const items = fs.readdirSync(dir);
  for (const item of items) {
    const fullPath = path.join(dir, item);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      results = results.concat(getAllFiles(fullPath, suffix));
    } else if (item.endsWith(suffix)) {
      results.push(fullPath);
    }
  }
  return results;
}

function loadJsonSafe(filePath) {
  if (!fs.existsSync(filePath)) return null;
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch (e) {
    return null;
  }
}

function findPendingKey(map, fileName, stripSuffix) {
  return Object.keys(map || {}).find(
    (k) =>
      k.toLowerCase().includes(fileName.toLowerCase()) ||
      fileName.toLowerCase().includes(k.replace(stripSuffix, '').toLowerCase())
  );
}

// ═══════════════════════════════════════════════════════════════
// NO JAVA / NO SELENIUM / NO PLAYWRIGHT-BDD SYNTAX CHECK
// (applies to every generated TypeScript category)
// ═══════════════════════════════════════════════════════════════

function checkNoJavaSyntax(content) {
  const issues = [];

  const javaPatterns = [
    { pattern: /\bpublic\s+void\b/, msg: 'Java: public void' },
    { pattern: /\bprivate\s+void\b/, msg: 'Java: private void' },
    { pattern: /\bpublic\s+static\b/, msg: 'Java: public static' },
    { pattern: /\bprivate\s+static\b/, msg: 'Java: private static' },

    { pattern: /\bWebElement\b/, msg: 'Selenium: WebElement' },
    { pattern: /\bWebDriver\b/, msg: 'Selenium: WebDriver' },
    { pattern: /@FindBy/, msg: 'Selenium: @FindBy annotation' },
    { pattern: /\bBy\.xpath\s*\(/, msg: 'Selenium: By.xpath()' },
    { pattern: /\bBy\.id\s*\(/, msg: 'Selenium: By.id()' },
    { pattern: /\bBy\.name\s*\(/, msg: 'Selenium: By.name()' },
    { pattern: /\bBy\.className\s*\(/, msg: 'Selenium: By.className()' },
    { pattern: /\bBy\.cssSelector\s*\(/, msg: 'Selenium: By.cssSelector()' },
    { pattern: /\bBy\.linkText\s*\(/, msg: 'Selenium: By.linkText()' },
    { pattern: /\bBy\.tagName\s*\(/, msg: 'Selenium: By.tagName()' },

    { pattern: /\.sendKeys\s*\(/, msg: 'Selenium: .sendKeys() → use .fill()' },
    { pattern: /\.getText\s*\(\)/, msg: 'Selenium: .getText() → use .textContent()' },
    { pattern: /\.isDisplayed\s*\(\)/, msg: 'Selenium: .isDisplayed() → use .isVisible()' },
    { pattern: /\.findElement\s*\(/, msg: 'Selenium: .findElement()' },
    { pattern: /\.findElements\s*\(/, msg: 'Selenium: .findElements()' },

    { pattern: /\bdriver\.get\s*\(/, msg: 'Java: driver.get() → use page.goto()' },
    { pattern: /\bdriver\.navigate\s*\(/, msg: 'Java: driver.navigate()' },
    { pattern: /\bdriver\.findElement/, msg: 'Java: driver.findElement' },
    { pattern: /\bdriver\.getCurrentUrl/, msg: 'Java: driver.getCurrentUrl → use page.url()' },
    { pattern: /\bdriver\.getTitle/, msg: 'Java: driver.getTitle → use page.title()' },

    { pattern: /Thread\.sleep/, msg: 'Java: Thread.sleep → use page.waitForTimeout()' },
    { pattern: /\bWebDriverWait\b/, msg: 'Java: WebDriverWait' },
    { pattern: /\bExpectedConditions\b/, msg: 'Java: ExpectedConditions' },

    // Cucumber/BDD annotations and playwright-bdd — this toolkit no longer uses BDD glue
    { pattern: /@Given\s*\(/, msg: 'Java: @Given annotation' },
    { pattern: /@When\s*\(/, msg: 'Java: @When annotation' },
    { pattern: /@Then\s*\(/, msg: 'Java: @Then annotation' },
    { pattern: /@And\s*\(/, msg: 'Java: @And annotation' },
    { pattern: /@But\s*\(/, msg: 'Java: @But annotation' },
    { pattern: /from\s*['"]playwright-bdd['"]/, msg: "playwright-bdd import — this toolkit generates plain Playwright tests, not BDD glue" },
    { pattern: /\bcreateBdd\s*\(/, msg: 'playwright-bdd: createBdd() — no longer used' },
    { pattern: /\bdefineBddConfig\s*\(/, msg: 'playwright-bdd: defineBddConfig() — no longer used' },
    { pattern: /^\s*(Given|When|Then)\s*\(\s*['"`]/m, msg: 'Given/When/Then(...) DSL call — steps must be plain exported functions' },

    { pattern: /\bString\s+\w+\s*=/, msg: 'Java: String declaration → use const/let' },
    { pattern: /\bint\s+\w+\s*=/, msg: 'Java: int declaration → use let/const' },
    { pattern: /\bboolean\s+\w+\s*=/, msg: 'Java: boolean declaration → use let/const' },
    { pattern: /\bList</, msg: 'Java: List<> → use array []' },
    { pattern: /\bMap</, msg: 'Java: Map<> → use object {}' },

    { pattern: /\.size\s*\(\)/, msg: 'Java: .size() → use .length' },
    { pattern: /\.equals\s*\(/, msg: 'Java: .equals() → use ===' },
    { pattern: /\.contains\s*\(/, msg: 'Java: .contains() → use .includes()' },
    { pattern: /\.isEmpty\s*\(\)/, msg: 'Java: .isEmpty() → use .length === 0' },

    { pattern: /\bAssert\.\w+/, msg: 'Java: Assert.* → use expect()' },
    { pattern: /\bassertTrue\s*\(/, msg: 'Java: assertTrue → use expect().toBeTruthy()' },
    { pattern: /\bassertEquals\s*\(/, msg: 'Java: assertEquals → use expect().toBe()' },
  ];

  for (const jp of javaPatterns) {
    if (jp.pattern.test(content)) {
      const lines = content.split('\n');
      let lineNum = 0;
      for (let i = 0; i < lines.length; i++) {
        const trimmed = lines[i].trim();
        if (jp.pattern.test(lines[i]) && !trimmed.startsWith('//') && !trimmed.startsWith('*')) {
          lineNum = i + 1;
          break;
        }
      }
      // Skip matches that only occur inside "Original Java:" comment blocks / @source headers
      if (lineNum > 0) {
        issues.push({ severity: 'error', message: jp.msg, line: lineNum });
      }
    }
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// PAGE CHECKS
// ═══════════════════════════════════════════════════════════════

function checkPageStructure(content) {
  const issues = [];

  if (!/export\s+class\s+\w+/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: export class' });
  }
  if (!/import.*{[^}]*Page[^}]*}.*from\s*['"]@playwright\/test['"]/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: Page import from @playwright/test' });
  }
  if (!/constructor\s*\([^)]*page\s*:\s*Page/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: constructor(page: Page)' });
  }
  if (!/readonly\s+page\s*:\s*Page/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: page property' });
  }
  if (!/Locator/.test(content) && /readonly\s+\w+/.test(content)) {
    issues.push({ severity: 'warning', message: 'Locators should be typed as Locator' });
  }

  return issues;
}

function checkPageCountMatch(tsFilePath, tsContent) {
  const issues = [];
  const fileName = path.basename(tsFilePath, '.page.ts');

  let expectedMethods = 0;
  const pending = loadJsonSafe(CONFIG.pendingFile);
  if (pending) {
    const pageKey = findPendingKey(pending.pages, fileName, '.page.ts');
    if (pageKey) expectedMethods = pending.pages[pageKey].length;
  }

  const tsLocators = (tsContent.match(/readonly\s+\w+\s*:\s*Locator/g) || []).length;
  const tsMethods = (tsContent.match(/async\s+\w+\s*\([^)]*\)\s*:\s*Promise/g) || []).length;

  let expectedLocators = 0;
  const sourceMatch = tsContent.match(/@source\s+([^\n\r]+)/);
  if (sourceMatch) {
    const javaPath = sourceMatch[1].trim();
    if (fs.existsSync(javaPath)) {
      const javaContent = fs.readFileSync(javaPath, 'utf-8');
      // Every locator is declared exactly once as a WebElement field, whether or not it
      // carries an @FindBy annotation — count the field declarations themselves as the
      // single source of truth (avoids double-counting an @FindBy line + its field line).
      const javaLocators = (javaContent.match(/(?:private|public)\s+WebElement\s+\w+\s*;/g) || []).length;
      const javaClass = javaContent.match(/class\s+(\w+)/)?.[1] || '';
      // Count public methods, excluding only the constructor (same name as the class).
      // Earlier versions also excluded any method containing "get"/"set", which wrongly
      // dropped legitimate Page Object methods like getErrorMessage() — a real action
      // method, not a POJO accessor. Constructor exclusion alone is correct here.
      const javaMethods = (javaContent.match(/public\s+\w+\s+(\w+)\s*\(/g) || [])
        .filter((m) => !new RegExp(`\\b${javaClass}\\s*\\(`).test(m)).length;
      if (javaLocators > 0) expectedLocators = javaLocators;
      if (javaMethods > 0) expectedMethods = javaMethods;
    }
  }

  if (expectedLocators > 0 && tsLocators !== expectedLocators) {
    const diff = expectedLocators - tsLocators;
    issues.push(
      diff > 0
        ? { severity: 'error', message: `Locators: Expected ${expectedLocators}, Found ${tsLocators} (${diff} MISSING)` }
        : { severity: 'warning', message: `Locators: Expected ${expectedLocators}, Found ${tsLocators} (${Math.abs(diff)} extra)` }
    );
  }

  if (expectedMethods > 0 && tsMethods !== expectedMethods) {
    const diff = expectedMethods - tsMethods;
    issues.push(
      diff > 0
        ? { severity: 'error', message: `Methods: Expected ${expectedMethods}, Found ${tsMethods} (${diff} MISSING)` }
        : { severity: 'warning', message: `Methods: Expected ${expectedMethods}, Found ${tsMethods} (${Math.abs(diff)} extra)` }
    );
  }

  if (expectedLocators === 0 && expectedMethods === 0) {
    issues.push({ severity: 'info', message: `Found: ${tsLocators} locator(s), ${tsMethods} method(s)` });
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// STEP CHECKS (plain exported functions — NOT Given/When/Then)
// ═══════════════════════════════════════════════════════════════

function countStepFunctions(content) {
  // A function is treated as a "hook" (not a step) if its doc-comment
  // mentions it was originally a Cucumber @Before/@After hook.
  const fnRegex = /(\/\*\*[\s\S]*?\*\/\s*)?export\s+async\s+function\s+(\w+)\s*\(([^)]*)\)\s*:\s*Promise<void>/g;
  let m;
  let stepCount = 0;
  let hookCount = 0;
  let malformedCount = 0;
  while ((m = fnRegex.exec(content))) {
    const docblock = m[1] || '';
    const params = m[3] || '';
    const isHook = /originally a cucumber/i.test(docblock) || /@Before|@After/.test(docblock);
    const hasFixturesParam = /^\s*fixtures\s*:\s*AppFixtures/.test(params);
    if (!hasFixturesParam) {
      malformedCount++;
    } else if (isHook) {
      hookCount++;
    } else {
      stepCount++;
    }
  }
  return { stepCount, hookCount, malformedCount };
}

function checkStepStructure(content) {
  const issues = [];

  if (!/import\s+(?:type\s+)?\{[^}]*AppFixtures[^}]*\}\s*from\s*['"][^'"]*fixtures['"]/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: AppFixtures type import from fixtures' });
  }

  const allExported = (content.match(/export\s+async\s+function\s+\w+\s*\(/g) || []).length;
  const { stepCount, hookCount, malformedCount } = countStepFunctions(content);

  if (allExported === 0) {
    issues.push({ severity: 'error', message: 'No exported step functions found (expected: export async function name(fixtures: AppFixtures, ...): Promise<void>)' });
  }
  if (malformedCount > 0) {
    issues.push({ severity: 'error', message: `${malformedCount} exported function(s) don't take (fixtures: AppFixtures, ...) as their first parameter` });
  }
  if (stepCount === 0 && hookCount === 0 && allExported > 0) {
    issues.push({ severity: 'warning', message: 'Could not confirm any well-formed step/hook functions' });
  }

  return issues;
}

function checkStepCountMatch(tsFilePath, tsContent) {
  const issues = [];
  const fileName = path.basename(tsFilePath, '.steps.ts');

  let expectedSteps = 0;
  const pending = loadJsonSafe(CONFIG.pendingFile);
  if (pending) {
    const stepKey = findPendingKey(pending.steps, fileName, '.steps.ts');
    if (stepKey) expectedSteps = pending.steps[stepKey].length;
  }

  const { stepCount: tsSteps, hookCount: tsHooks } = countStepFunctions(tsContent);

  const sourceMatch = tsContent.match(/@source\s+([^\n\r]+)/);
  let javaHooks = 0;
  if (sourceMatch) {
    const javaPath = sourceMatch[1].trim();
    if (fs.existsSync(javaPath)) {
      const javaContent = fs.readFileSync(javaPath, 'utf-8');
      const javaSteps = (javaContent.match(/@(Given|When|Then|And|But)\s*\(/g) || []).length;
      javaHooks = (javaContent.match(/@(Before|After)\b/g) || []).length;
      if (javaSteps > 0) expectedSteps = javaSteps;
    }
  }

  if (expectedSteps > 0 && tsSteps !== expectedSteps) {
    const diff = expectedSteps - tsSteps;
    issues.push(
      diff > 0
        ? { severity: 'error', message: `Steps: Expected ${expectedSteps}, Found ${tsSteps} (${diff} MISSING)` }
        : { severity: 'warning', message: `Steps: Expected ${expectedSteps}, Found ${tsSteps} (${Math.abs(diff)} extra)` }
    );
  } else if (expectedSteps === 0) {
    issues.push({ severity: 'info', message: `Found: ${tsSteps} step function(s)` });
  }

  if (javaHooks > 0 && tsHooks !== javaHooks) {
    const diff = javaHooks - tsHooks;
    issues.push(
      diff > 0
        ? { severity: 'warning', message: `Hooks: Expected ${javaHooks} (@Before/@After), Found ${tsHooks} (${diff} missing — wire into fixtures or beforeEach/afterEach)` }
        : { severity: 'info', message: `Hooks: ${tsHooks} found` }
    );
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// UTIL CHECKS
// ═══════════════════════════════════════════════════════════════

function checkUtilStructure(content) {
  const issues = [];
  if (!/export\s+(async\s+)?function\s+\w+/.test(content)) {
    issues.push({ severity: 'error', message: 'No exported utility function(s) found' });
  }
  return issues;
}

function checkUtilCountMatch(tsFilePath, tsContent) {
  const issues = [];
  const fileName = path.basename(tsFilePath, '.utils.ts');

  let expected = 0;
  const pending = loadJsonSafe(CONFIG.pendingFile);
  if (pending) {
    const key = findPendingKey(pending.utils, fileName, '.utils.ts');
    if (key) expected = pending.utils[key].length;
  }

  const found = (tsContent.match(/export\s+(async\s+)?function\s+\w+\s*\(/g) || []).length;

  if (expected > 0 && found !== expected) {
    const diff = expected - found;
    issues.push(
      diff > 0
        ? { severity: 'error', message: `Functions: Expected ${expected}, Found ${found} (${diff} MISSING)` }
        : { severity: 'warning', message: `Functions: Expected ${expected}, Found ${found} (${Math.abs(diff)} extra)` }
    );
  } else if (expected === 0) {
    issues.push({ severity: 'info', message: `Found: ${found} function(s)` });
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// CONFIG / TYPES CHECKS (auto-converted — should have zero TODOs)
// ═══════════════════════════════════════════════════════════════

function checkConfigStructure(content) {
  const issues = [];
  if (!/export\s+const\s+\w+/.test(content)) {
    issues.push({ severity: 'error', message: 'No exported const declarations found' });
  }
  if (/throw\s+new\s+Error\s*\(\s*['"`].*not\s+implemented/i.test(content)) {
    issues.push({ severity: 'error', message: 'Config files are auto-converted and should never contain a "not implemented" placeholder' });
  }
  return issues;
}

function checkTypeStructure(content) {
  const issues = [];
  if (!/export\s+interface\s+\w+/.test(content)) {
    issues.push({ severity: 'error', message: 'No exported interface found' });
  }
  if (/throw\s+new\s+Error\s*\(\s*['"`].*not\s+implemented/i.test(content)) {
    issues.push({ severity: 'error', message: 'Type files are auto-converted and should never contain a "not implemented" placeholder' });
  }
  return issues;
}

// ═══════════════════════════════════════════════════════════════
// SPEC CHECKS (tests/specs/*.spec.ts — the core requirement #4 output)
// ═══════════════════════════════════════════════════════════════

function checkSpecStructure(content) {
  const issues = [];

  if (!/import\s*\{\s*test\s*\}\s*from\s*['"][^'"]*fixtures[^'"]*['"]/.test(content)) {
    issues.push({ severity: 'error', message: "Missing: import { test } from '<path>/fixtures/test-fixtures'" });
  }
  if (!/test\.describe\s*\(/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: test.describe(...) wrapper' });
  }
  if (/from\s*['"]playwright-bdd['"]/.test(content) || /createBdd\s*\(/.test(content)) {
    issues.push({ severity: 'error', message: 'playwright-bdd usage found — generated specs must be plain Playwright tests' });
  }

  const testStepCount = (content.match(/test\.step\s*\(/g) || []).length;
  if (testStepCount === 0) {
    issues.push({ severity: 'error', message: 'No test.step() calls found — every Given/When/Then line should be wrapped in test.step()' });
  }

  const testCount = (content.match(/\btest\s*\(\s*['"`]/g) || []).length;
  if (testCount === 0) {
    issues.push({ severity: 'error', message: 'No test(...) blocks found' });
  }

  return issues;
}

function checkSpecStepCoverage(specContent) {
  const issues = [];

  const unresolvedCount = (specContent.match(/Step not implemented:/g) || []).length;
  if (unresolvedCount > 0) {
    issues.push({
      severity: 'error',
      message: `${unresolvedCount} step(s) have no matching function in src/steps (feature step text didn't match any @Given/@When/@Then Cucumber-expression) — add/fix the matching step function`,
    });
  }

  const sourceMatch = specContent.match(/@source\s+([^\n\r]+)/);
  if (sourceMatch) {
    const featurePath = sourceMatch[1].trim();
    if (fs.existsSync(featurePath)) {
      const featureContent = fs.readFileSync(featurePath, 'utf-8');
      const scenarioCount = (featureContent.match(/^\s*Scenario(?: Outline)?:/gm) || []).length;
      const testCount = (specContent.match(/\btest\s*\(\s*['"`]/g) || []).length;
      if (scenarioCount > 0 && testCount < scenarioCount) {
        issues.push({
          severity: 'error',
          message: `Feature has ${scenarioCount} scenario definition(s) but spec only has ${testCount} test() block(s) — Scenario Outline Examples rows should each expand into their own test()`,
        });
      } else if (scenarioCount > 0) {
        issues.push({ severity: 'info', message: `${testCount} test() block(s) generated from ${scenarioCount} scenario definition(s)` });
      }
    }
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// IMPLEMENTATION / TODO CHECK (page, step, util)
// ═══════════════════════════════════════════════════════════════

function checkImplementation(content) {
  const issues = [];

  const todoMatches = content.match(/throw\s+new\s+Error\s*\(\s*['"`](Method|Step|Hook|Function).*not\s+implemented/g) || [];
  if (todoMatches.length > 0) {
    issues.push({ severity: 'error', message: `${todoMatches.length} method(s)/step(s)/function(s) NOT implemented` });
  }

  const todoComments = content.match(/\/\/\s*TODO:/gi) || [];
  if (todoComments.length > 0) {
    issues.push({ severity: 'warning', message: `${todoComments.length} TODO comment(s) remaining` });
  }

  const originalJava = content.match(/\/\/\s*Original\s*Java:/gi) || [];
  if (originalJava.length > 0) {
    issues.push({ severity: 'warning', message: `${originalJava.length} "Original Java" comment(s) not cleaned up` });
  }

  const lines = content.split('\n');
  const playwrightMethods = [
    'click(', 'fill(', 'clear(', 'hover(', 'focus(',
    'press(', 'selectOption(', 'check(', 'uncheck(',
    'waitFor(', 'goto(', 'reload(', 'goBack(', 'goForward(',
    'textContent(', 'innerText(', 'getAttribute(',
    'isVisible(', 'isEnabled(', 'isChecked(',
    'scrollIntoViewIfNeeded(', 'dblclick(', 'type(',
    'screenshot(', 'evaluate(', 'waitForSelector(',
    'waitForTimeout(', 'waitForLoadState(', 'waitForURL(',
  ];

  const missingAwaits = [];
  lines.forEach((line, idx) => {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed.startsWith('*') || trimmed.startsWith('/*')) return;
    for (const method of playwrightMethods) {
      if (line.includes('.' + method) && !line.includes('await ') && !line.includes('await(') && !line.includes('return await')) {
        missingAwaits.push({ line: idx + 1, method });
      }
    }
  });

  if (missingAwaits.length > 0) {
    issues.push({
      severity: 'error',
      message: `${missingAwaits.length} missing await(s): lines ${missingAwaits.slice(0, 3).map((m) => m.line).join(', ')}${missingAwaits.length > 3 ? '...' : ''}`,
    });
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// BOILERPLATE/PLACEHOLDER DETECTION (page, step, util)
// ═══════════════════════════════════════════════════════════════

function extractBodies(content, category) {
  const bodies = [];

  if (category === 'page') {
    const methodRegex = /async\s+(\w+)\s*\([^)]*\)\s*(?::\s*Promise<[^>]+>)?\s*\{([\s\S]*?)\n\s{2}\}/g;
    let match;
    while ((match = methodRegex.exec(content))) {
      bodies.push({ name: match[1], body: match[2].trim() });
    }
  } else {
    // step / util files: top-level exported functions
    const fnRegex = /export\s+(?:async\s+)?function\s+(\w+)\s*\([^)]*\)[^{]*\{([\s\S]*?)\n\}/g;
    let match;
    while ((match = fnRegex.exec(content))) {
      bodies.push({ name: match[1], body: match[2].trim() });
    }
  }

  return bodies;
}

function isBoilerplateOnly(body) {
  if (!body || body.length === 0) return true;

  const withoutComments = body.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').trim();
  if (!withoutComments) return true;

  const boilerplatePatterns = [
    /^await\s+page\.waitForLoadState\s*\(\s*['"`]\w+['"`]\s*\)\s*;?$/,
    /^await\s+page\.waitForTimeout\s*\(\s*\d+\s*\)\s*;?$/,
    /^await\s+page\.waitForSelector\s*\([^)]+\)\s*;?$/,
    /^await\s+page\.waitForNavigation\s*\([^)]*\)\s*;?$/,
    /^await\s+page\.waitForURL\s*\([^)]+\)\s*;?$/,
    /^console\.log\s*\([^)]*\)\s*;?$/,
    /^await\s+Promise\.resolve\s*\(\s*\)\s*;?$/,
    /^return\s*;?$/,
    /^\/\/.*$/,
    /^\s*$/,
  ];

  const statements = withoutComments.split(/;|\n/).map((s) => s.trim()).filter((s) => s.length > 0);
  if (statements.length === 0) return true;

  return statements.every((stmt) => boilerplatePatterns.some((pattern) => pattern.test(stmt)));
}

function checkBoilerplate(content, category) {
  const issues = [];
  const bodies = extractBodies(content, category);

  let boilerplateOnlyCount = 0;
  const boilerplateNames = [];
  for (const item of bodies) {
    if (isBoilerplateOnly(item.body)) {
      boilerplateOnlyCount++;
      boilerplateNames.push(item.name);
    }
  }
  if (boilerplateOnlyCount > 0) {
    const examples = boilerplateNames.slice(0, 3).join(', ');
    issues.push({
      severity: 'error',
      message: `${boilerplateOnlyCount} method(s)/function(s) have ONLY boilerplate code: ${examples}${boilerplateNames.length > 3 ? '...' : ''}`,
    });
  }

  let emptyCount = 0;
  for (const item of bodies) {
    const cleaned = item.body.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').trim();
    if (!cleaned || cleaned === '{}') emptyCount++;
  }
  if (emptyCount > 0) {
    issues.push({ severity: 'error', message: `${emptyCount} empty method(s)/function(s) — no implementation` });
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// SYNTAX CHECK (all categories)
// ═══════════════════════════════════════════════════════════════

function checkSyntax(content) {
  const issues = [];

  const openBraces = (content.match(/\{/g) || []).length;
  const closeBraces = (content.match(/\}/g) || []).length;
  if (openBraces !== closeBraces) {
    issues.push({ severity: 'error', message: `Unbalanced braces: {=${openBraces}, }=${closeBraces}` });
  }

  const openParens = (content.match(/\(/g) || []).length;
  const closeParens = (content.match(/\)/g) || []).length;
  if (openParens !== closeParens) {
    issues.push({ severity: 'error', message: `Unbalanced parentheses: (=${openParens}, )=${closeParens}` });
  }

  if (/async\s+async/.test(content)) issues.push({ severity: 'error', message: 'Double async keyword' });
  if (/await\s+await/.test(content)) issues.push({ severity: 'error', message: 'Double await keyword' });

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// LEGACY (unclassified) FILES — informational only
// ═══════════════════════════════════════════════════════════════

function checkLegacyFile() {
  return [{
    severity: 'warning',
    message: 'Unclassified source file — could not be auto-categorized as page/step/util/config/type. Original Java kept in a comment; needs manual review (see migration-manifest.json → needsManualReview).',
  }];
}

// ═══════════════════════════════════════════════════════════════
// MANIFEST COVERAGE CHECK — ensures nothing was silently skipped
// ═══════════════════════════════════════════════════════════════

function checkManifestCoverage() {
  const manifest = loadJsonSafe(CONFIG.manifestFile);
  if (!manifest) {
    return { ran: false, issues: [{ severity: 'warning', message: 'migration-manifest.json not found — run `node scripts/migrate.js` first' }] };
  }

  const issues = [];
  for (const f of manifest.files || []) {
    if (f.category === 'infra') continue; // infra is intentionally documentation-only, no output file
    if (f.output && !fs.existsSync(f.output)) {
      issues.push({ severity: 'error', message: `${f.source} (${f.category}) → expected output ${f.output} but it is MISSING on disk` });
    }
  }

  if (manifest.needsManualReview && manifest.needsManualReview.length > 0) {
    issues.push({
      severity: 'warning',
      message: `${manifest.needsManualReview.length} source file(s) need manual review: ${manifest.needsManualReview.join(', ')}`,
    });
  }

  if (issues.length === 0) {
    issues.push({ severity: 'info', message: `All ${manifest.files?.length || 0} scanned source file(s) accounted for — nothing silently dropped` });
  }

  return { ran: true, issues };
}

// ═══════════════════════════════════════════════════════════════
// CATEGORY DETECTION
// ═══════════════════════════════════════════════════════════════

function detectCategory(filePath) {
  if (filePath.includes('.page.ts')) return 'page';
  if (filePath.includes('.steps.ts')) return 'step';
  if (filePath.includes('.utils.ts')) return 'util';
  if (filePath.includes('.config.ts')) return 'config';
  if (filePath.includes('.types.ts')) return 'type';
  if (filePath.includes('.legacy.ts')) return 'legacy';
  if (filePath.includes('.spec.ts')) return 'spec';
  return 'unknown';
}

const CATEGORY_LABELS = {
  page: '📄 PAGES',
  step: '📝 STEPS',
  util: '🔧 UTILS',
  config: '⚙️  CONFIG',
  type: '🧩 TYPES',
  spec: '✅ SPECS (test.step output)',
  legacy: '❓ LEGACY (needs manual review)',
};

// ═══════════════════════════════════════════════════════════════
// VERIFY SINGLE FILE
// ═══════════════════════════════════════════════════════════════

function verifyFile(filePath, silent = false) {
  const fileName = path.basename(filePath);

  if (!fs.existsSync(filePath)) {
    if (!silent) console.log(`   ❌ ${fileName} - File not found`);
    return { passed: false, file: fileName, error: 'File not found', checks: [] };
  }

  const content = fs.readFileSync(filePath, 'utf-8');
  const category = detectCategory(filePath);

  if (!silent) console.log(`\n   📄 ${fileName}`);

  const checks = [];

  if (category === 'legacy') {
    checks.push({ name: 'Manual Review Needed', passed: false, issues: checkLegacyFile() });
  } else {
    const javaSyntaxIssues = checkNoJavaSyntax(content);
    checks.push({ name: 'No Java/BDD Syntax', passed: !javaSyntaxIssues.some((i) => i.severity === 'error'), issues: javaSyntaxIssues });

    if (category === 'page') {
      const structureIssues = checkPageStructure(content);
      checks.push({ name: 'Page Structure', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
      const countIssues = checkPageCountMatch(filePath, content);
      checks.push({ name: 'Count Match', passed: !countIssues.some((i) => i.severity === 'error'), issues: countIssues });
    } else if (category === 'step') {
      const structureIssues = checkStepStructure(content);
      checks.push({ name: 'Step Structure (plain functions)', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
      const countIssues = checkStepCountMatch(filePath, content);
      checks.push({ name: 'Count Match', passed: !countIssues.some((i) => i.severity === 'error'), issues: countIssues });
    } else if (category === 'util') {
      const structureIssues = checkUtilStructure(content);
      checks.push({ name: 'Util Structure', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
      const countIssues = checkUtilCountMatch(filePath, content);
      checks.push({ name: 'Count Match', passed: !countIssues.some((i) => i.severity === 'error'), issues: countIssues });
    } else if (category === 'config') {
      const structureIssues = checkConfigStructure(content);
      checks.push({ name: 'Config Structure', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
    } else if (category === 'type') {
      const structureIssues = checkTypeStructure(content);
      checks.push({ name: 'Type Structure', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
    } else if (category === 'spec') {
      const structureIssues = checkSpecStructure(content);
      checks.push({ name: 'Spec Structure (test.step)', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
      const coverageIssues = checkSpecStepCoverage(content);
      checks.push({ name: 'Step Coverage', passed: !coverageIssues.some((i) => i.severity === 'error'), issues: coverageIssues });
    }

    if (['page', 'step', 'util'].includes(category)) {
      const implIssues = checkImplementation(content);
      checks.push({ name: 'Implementation', passed: !implIssues.some((i) => i.severity === 'error'), issues: implIssues });
      const boilerplateIssues = checkBoilerplate(content, category);
      checks.push({ name: 'No Boilerplate', passed: !boilerplateIssues.some((i) => i.severity === 'error'), issues: boilerplateIssues });
    }

    const syntaxIssues = checkSyntax(content);
    checks.push({ name: 'Syntax', passed: !syntaxIssues.some((i) => i.severity === 'error'), issues: syntaxIssues });
  }

  if (!silent) {
    for (const check of checks) {
      const icon = check.passed ? '✓' : '✗';
      console.log(`      ├─ ${check.name}: ${icon}`);
      for (const issue of check.issues.filter((i) => i.severity === 'error')) {
        console.log(`      │  └─ ❌ ${issue.message}${issue.line ? ` (line ${issue.line})` : ''}`);
      }
      for (const issue of check.issues.filter((i) => i.severity === 'warning')) {
        console.log(`      │  └─ ⚠️  ${issue.message}`);
      }
      for (const issue of check.issues.filter((i) => i.severity === 'info')) {
        console.log(`      │  └─ ℹ️  ${issue.message}`);
      }
    }
  }

  const hasError = checks.some((c) => !c.passed);
  const warningCount = checks.reduce((sum, c) => sum + c.issues.filter((i) => i.severity === 'warning').length, 0);
  const errorCount = checks.reduce((sum, c) => sum + c.issues.filter((i) => i.severity === 'error').length, 0);

  if (!silent) {
    if (!hasError && warningCount === 0) console.log('      └─ ✅ PASSED');
    else if (!hasError) console.log(`      └─ ⚠️  PASSED (${warningCount} warning${warningCount > 1 ? 's' : ''})`);
    else console.log(`      └─ ❌ FAILED (${errorCount} error${errorCount > 1 ? 's' : ''})`);
  }

  return { passed: !hasError, file: fileName, category, checks, errorCount, warningCount };
}

// ═══════════════════════════════════════════════════════════════
// VERIFY ALL FILES
// ═══════════════════════════════════════════════════════════════

function verifyAll() {
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('   CoVe - STRICT Chain of Verification (no-BDD architecture)');
  console.log('═══════════════════════════════════════════════════════════════');

  const groups = [
    { category: 'page', dir: CONFIG.pagesOut, suffix: '.page.ts' },
    { category: 'step', dir: CONFIG.stepsOut, suffix: '.steps.ts' },
    { category: 'util', dir: CONFIG.utilsOut, suffix: '.utils.ts' },
    { category: 'config', dir: CONFIG.configOut, suffix: '.config.ts' },
    { category: 'type', dir: CONFIG.typesOut, suffix: '.types.ts' },
    { category: 'spec', dir: CONFIG.specsOut, suffix: '.spec.ts' },
    { category: 'legacy', dir: CONFIG.legacyOut, suffix: '.legacy.ts' },
  ];

  const results = { byCategory: {}, files: [] };

  for (const group of groups) {
    console.log(`\n${CATEGORY_LABELS[group.category]}:`);
    const files = getAllFiles(group.dir, group.suffix);
    const stats = { total: 0, passed: 0, failed: 0, errors: 0, warnings: 0 };

    if (files.length === 0) {
      console.log('   (none found)');
    } else {
      for (const file of files) {
        const result = verifyFile(file);
        results.files.push(result);
        stats.total++;
        if (result.passed) stats.passed++;
        else stats.failed++;
        stats.errors += result.errorCount || 0;
        stats.warnings += result.warningCount || 0;
      }
    }
    results.byCategory[group.category] = stats;
  }

  // Manifest coverage — make sure nothing was silently skipped during migrate.js
  console.log('\n📋 MANIFEST COVERAGE:');
  const coverage = checkManifestCoverage();
  if (!coverage.ran) {
    console.log('   ⚠️  Skipped (no migration-manifest.json)');
  }
  for (const issue of coverage.issues) {
    const icon = issue.severity === 'error' ? '❌' : issue.severity === 'warning' ? '⚠️ ' : 'ℹ️ ';
    console.log(`   ${icon} ${issue.message}`);
  }
  const manifestHasErrors = coverage.issues.some((i) => i.severity === 'error');

  // Summary
  let totalPassed = 0, totalFailed = 0, totalFiles = 0, totalErrors = 0, totalWarnings = 0;
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('   SUMMARY');
  console.log('═══════════════════════════════════════════════════════════════\n');
  for (const group of groups) {
    const s = results.byCategory[group.category];
    totalPassed += s.passed;
    totalFailed += s.failed;
    totalFiles += s.total;
    totalErrors += s.errors;
    totalWarnings += s.warnings;
    if (s.total > 0) {
      console.log(`   ${CATEGORY_LABELS[group.category].padEnd(34)} ${s.passed}/${s.total} passed${s.failed > 0 ? ` (${s.failed} failed)` : ' ✅'}`);
    }
  }
  console.log('   ─────────────────────────────────────────────────────────');
  console.log(`   Total:    ${totalPassed}/${totalFiles} passed`);
  console.log(`   Errors:   ${totalErrors}`);
  console.log(`   Warnings: ${totalWarnings}\n`);

  const overallFailed = totalFailed > 0 || manifestHasErrors;

  if (!overallFailed) {
    console.log('   ✅ ALL CHECKS PASSED');
  } else {
    console.log('   ❌ VERIFICATION FAILED');
    if (totalFailed > 0) {
      console.log('\n   Failed files:');
      for (const file of results.files.filter((f) => !f.passed)) {
        console.log(`   - ${file.file}`);
      }
    }
    if (manifestHasErrors) {
      console.log('\n   Manifest coverage errors found — see above.');
    }
  }

  console.log('\n═══════════════════════════════════════════════════════════════\n');

  fs.writeFileSync(
    CONFIG.reportFile,
    JSON.stringify({ ...results, manifestCoverage: coverage.issues }, null, 2)
  );
  console.log(`   Report saved: ${CONFIG.reportFile}\n`);

  process.exit(overallFailed ? 1 : 0);
}

// ═══════════════════════════════════════════════════════════════
// CLI
// ═══════════════════════════════════════════════════════════════

const args = process.argv.slice(2);

if (args[0] === 'file' && args[1]) {
  const result = verifyFile(args[1]);
  process.exit(result.passed ? 0 : 1);
} else if (args[0] === 'help' || args[0] === '--help') {
  console.log(`
CoVe - STRICT Chain of Verification (no-BDD architecture)

Usage:
  npm run verify              Run full verification across all categories
  npm run verify:file <path>  Verify a single file

Categories checked:
  Pages    src/pages/*.page.ts        — class structure, locator/method counts
  Steps    src/steps/*.steps.ts       — plain exported functions (NOT Given/When/Then)
  Utils    src/utils/*.utils.ts       — exported helper functions
  Config   src/config/*.config.ts     — auto-converted constants (zero TODOs expected)
  Types    src/types/*.types.ts       — auto-converted interfaces (zero TODOs expected)
  Specs    tests/specs/*.spec.ts      — plain Playwright tests, every step in test.step()
  Legacy   src/legacy/**/*.legacy.ts  — flagged for manual review, never "passes"

Also checks migration-manifest.json to confirm no source file was silently
skipped during migration.

Exit codes:
  0 = All passed
  1 = Some failed
`);
} else {
  verifyAll();
}

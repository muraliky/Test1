#!/usr/bin/env node
/**
 * Selenium (Java) -> Playwright (TypeScript) Migration Script — v3
 *
 * Differences from v2:
 *  - Scans the ENTIRE `_source-java` tree (any folder layout), not just
 *    pages/steps/features. Every .java file is classified and routed.
 *  - Does NOT generate playwright-bdd. Feature files are compiled directly
 *    into standard Playwright spec files where every Gherkin step
 *    (Given/When/Then/And/But) becomes a `test.step()`.
 *  - Produces a migration-manifest.json describing how every source file
 *    was classified and where it ended up, so nothing is silently dropped.
 *
 * Creates SKELETON files with TODO markers for anything that needs real
 * logic (pages, steps, utils). Method implementation is done by the
 * @pw-orchestrator / @pw-migrate agents. Pure data (constants, POJOs) is
 * converted automatically since it requires no judgement.
 */

const fs = require('fs');
const path = require('path');

// ═══════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════

const CONFIG = {
  sourceDir: './_source-java',
  pagesOut: './src/pages',
  stepsOut: './src/steps',
  utilsOut: './src/utils',
  configOut: './src/config',
  typesOut: './src/types',
  legacyOut: './src/legacy',
  fixturesOut: './src/fixtures',
  featuresOut: './features',
  specsOut: './tests/specs',
  notesOut: './docs/migration-notes',
  pendingFile: './pending-methods.json',
  manifestFile: './migration-manifest.json',
};

// Tracks everything that still needs a human/agent to implement real logic
let pending = {
  pages: {},       // fileName -> [methodName, ...]
  steps: {},       // fileName -> [stepText, ...]
  utils: {},       // fileName -> [functionName, ...]
  pageFiles: [],
  stepFiles: [],
  utilFiles: [],
  totalMethods: 0,
  totalSteps: 0,
  totalUtilFunctions: 0,
};

// Full record of every source file and what happened to it
let manifest = {
  generatedAt: new Date().toISOString(),
  sourceRoot: CONFIG.sourceDir,
  files: [], // { source, category, output, notes }
  summary: {},
  needsManualReview: [],
};

// Step registry used to wire feature-file steps to generated step functions
// { pattern: RegExp, paramTypes: string[], importPath: string, functionName: string, stepText: string }
let stepRegistry = [];

// ═══════════════════════════════════════════════════════════════
// GENERIC UTILITIES
// ═══════════════════════════════════════════════════════════════

function toKebabCase(str) {
  return str
    .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
    .replace(/([A-Z])([A-Z][a-z])/g, '$1-$2')
    .toLowerCase();
}

function toCamelCase(str) {
  if (!str) return str;
  return str.charAt(0).toLowerCase() + str.slice(1);
}

function toPascalCase(str) {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function getAllFiles(dir, ext) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  for (const item of fs.readdirSync(dir)) {
    const full = path.join(dir, item);
    if (fs.statSync(full).isDirectory()) {
      results = results.concat(getAllFiles(full, ext));
    } else if (item.endsWith(ext)) {
      results.push(full);
    }
  }
  return results;
}

function toPosix(p) {
  return p.replace(/\\/g, '/');
}

/**
 * Strip a leading directory segment if it matches one of the given
 * synonyms (case-insensitive). Used so `_source-java/pages/auth/Foo.java`
 * lands at `src/pages/auth/foo.page.ts` instead of `src/pages/pages/auth/...`.
 */
function stripKnownPrefix(relDir, synonyms) {
  if (!relDir || relDir === '.') return '';
  const parts = relDir.split(/[/\\]/).filter(Boolean);
  if (parts.length && synonyms.includes(parts[0].toLowerCase())) {
    return parts.slice(1).join('/');
  }
  return parts.join('/');
}

function formatMethodDescription(methodName) {
  const words = methodName
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, (s) => s.toUpperCase())
    .trim();
  return words;
}

// ═══════════════════════════════════════════════════════════════
// LOCATOR CONVERSION (Selenium -> Playwright)
// ═══════════════════════════════════════════════════════════════

function convertLocator(loc) {
  let m;

  if ((m = loc.match(/\/\/button\[text\(\)\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByRole('button', { name: '${m[1]}' })`;
  if ((m = loc.match(/\/\/button\[contains\(text\(\),\s*['"]([^'"]+)['"]\)\]/)))
    return `getByRole('button', { name: /${m[1]}/i })`;
  if ((m = loc.match(/\/\/a\[text\(\)\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByRole('link', { name: '${m[1]}' })`;
  if ((m = loc.match(/\/\/input\[@placeholder\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByPlaceholder('${m[1]}')`;
  if ((m = loc.match(/\/\/label\[text\(\)\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByLabel('${m[1]}')`;
  if ((m = loc.match(/\/\/\*\[@data-testid\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByTestId('${m[1]}')`;
  if ((m = loc.match(/\/\/\w*\[@id\s*=\s*['"]([^'"]+)['"]\]/)))
    return `locator('#${m[1]}')`;
  if ((m = loc.match(/By\.id\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator('#${m[1]}')`;
  if ((m = loc.match(/By\.name\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator('[name="${m[1]}"]')`;
  if ((m = loc.match(/By\.className\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator('.${m[1]}')`;
  if ((m = loc.match(/By\.cssSelector\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator('${m[1]}')`;
  if ((m = loc.match(/By\.xpath\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator('${m[1]}')`;
  if (loc.startsWith('//')) return `locator('${loc}')`;

  return `locator('${loc}')`;
}

// ═══════════════════════════════════════════════════════════════
// TYPE CONVERSION (Java -> TypeScript)
// ═══════════════════════════════════════════════════════════════

function javaToTsType(t) {
  if (!t) return 'unknown';
  let type = t.trim();

  // Generics: List<X>, ArrayList<X>, Set<X> -> X[]
  let m = type.match(/^(?:List|ArrayList|LinkedList|Set|HashSet)\s*<\s*(.+)\s*>$/);
  if (m) return `${javaToTsType(m[1])}[]`;

  // Map<K,V> -> Record<K, V>
  m = type.match(/^(?:Map|HashMap)\s*<\s*([^,]+)\s*,\s*(.+)\s*>$/);
  if (m) return `Record<${javaToTsType(m[1])}, ${javaToTsType(m[2])}>`;

  // Arrays: Type[]
  m = type.match(/^(.+)\[\]$/);
  if (m) return `${javaToTsType(m[1])}[]`;

  const map = {
    String: 'string',
    CharSequence: 'string',
    char: 'string',
    Character: 'string',
    int: 'number',
    Integer: 'number',
    long: 'number',
    Long: 'number',
    short: 'number',
    Short: 'number',
    double: 'number',
    Double: 'number',
    float: 'number',
    Float: 'number',
    BigDecimal: 'number',
    boolean: 'boolean',
    Boolean: 'boolean',
    void: 'void',
    Void: 'void',
    Object: 'unknown',
    WebElement: 'Locator',
    List: 'any[]',
    DataTable: 'Record<string, string>[]',
  };
  return map[type] || type; // fall back to the original type name (might be a converted model)
}

function convertParams(params) {
  if (!params || !params.trim()) return { params: '', docs: '', names: [], types: [] };
  const result = { params: [], docs: [], names: [], types: [] };
  for (const p of params.split(',').map((x) => x.trim())) {
    const parts = p.split(/\s+/);
    if (parts.length >= 2) {
      const tsType = javaToTsType(parts[0]);
      const name = parts[parts.length - 1];
      result.params.push(`${name}: ${tsType}`);
      result.docs.push(`   * @param {${tsType}} ${name}`);
      result.names.push(name);
      result.types.push(tsType);
    }
  }
  return {
    params: result.params.join(', '),
    docs: result.docs.join('\n'),
    names: result.names,
    types: result.types,
  };
}

// ═══════════════════════════════════════════════════════════════
// CLASSIFICATION — decide what a .java file actually is
// ═══════════════════════════════════════════════════════════════

const SYNONYMS = {
  page: ['pages', 'page', 'pageobjects', 'pageobject', 'po'],
  steps: ['steps', 'stepdefs', 'stepdefinitions', 'stepdefinition', 'glue'],
  util: ['utils', 'util', 'helpers', 'helper', 'common'],
  config: ['config', 'configs', 'constants', 'properties', 'env'],
  type: ['models', 'model', 'pojo', 'pojos', 'dto', 'dtos', 'types', 'beans', 'entities', 'entity'],
};

function getClassOrInterfaceName(content, fallback) {
  const cm = content.match(/(?:public\s+)?(?:abstract\s+)?(?:final\s+)?class\s+(\w+)/);
  if (cm) return cm[1];
  const im = content.match(/(?:public\s+)?interface\s+(\w+)/);
  if (im) return im[1];
  return fallback;
}

/**
 * Classify a Java source file into one of:
 *   'steps' | 'page' | 'infra' | 'type' | 'config' | 'util' | 'unknown'
 */
function classifyJavaFile(content, fileName, relDir) {
  const dirSeg = (relDir.split(/[/\\]/)[0] || '').toLowerCase();

  // 1. STEP DEFINITIONS — strongest signal, check first.
  if (/@(Given|When|Then)\s*\(/.test(content)) {
    return 'steps';
  }

  // 2. INFRASTRUCTURE — test-runner / driver-lifecycle / reporting plumbing
  //    that Playwright replaces natively (config, fixtures, built-in reporters).
  const infraNameHints = /\b(Hooks?|Runner|Listener|DriverFactory|DriverManager|TestBase|BaseTest|TestSuite|ExtentReport\w*|WebDriverManager)\b/;
  const infraContentHints =
    /@RunWith\s*\(|CucumberOptions|WebDriverManager\.|new\s+ChromeDriver\s*\(|new\s+FirefoxDriver\s*\(|new\s+RemoteWebDriver\s*\(|implements\s+ITestListener|implements\s+WebDriverEventListener|ExtentReports|ExtentTest|@BeforeSuite|@AfterSuite/;
  if (infraNameHints.test(fileName) || infraContentHints.test(content)) {
    return 'infra';
  }

  // 3. PAGE OBJECTS — @FindBy annotations, or WebElement fields + By locators.
  const hasFindBy = /@FindBy\s*\(/.test(content);
  const hasWebElementAndBy = /\bWebElement\b/.test(content) && /By\.\w+\s*\(/.test(content);
  const looksLikePageByName = /Page$/.test(fileName.replace('.java', '')) && /By\s+\w+\s*=/.test(content);
  if (hasFindBy || hasWebElementAndBy || looksLikePageByName) {
    return 'page';
  }

  // 4. CONFIG / CONSTANTS — file is (almost) entirely `static final` fields.
  const constantFields = content.match(/(?:public|private|protected)?\s*static\s+final\s+\w[\w<>,\[\]]*\s+\w+\s*=\s*[^;]+;/g) || [];
  const anyMethods = /(?:public|private|protected)\s+[\w<>\[\],\s]+\s+\w+\s*\([^)]*\)\s*\{/.test(
    content.replace(/(?:public|private|protected)?\s*static\s+final\s+[^;]+;/g, '')
  );
  if (constantFields.length >= 2 && (dirSeg && SYNONYMS.config.includes(dirSeg) ? true : !anyMethods)) {
    return 'config';
  }
  if (SYNONYMS.config.includes(dirSeg) && constantFields.length >= 1) {
    return 'config';
  }

  // 5. POJO / MODEL / DTO — private fields + matching getters, no Selenium.
  const privateFields = content.match(/private\s+[\w<>\[\],\s]+\s+\w+\s*;/g) || [];
  const getters = content.match(/public\s+[\w<>\[\],\s]+\s+get\w+\s*\(\s*\)/g) || [];
  const noSelenium = !/\bWebElement\b|\bWebDriver\b|By\.\w+\s*\(/.test(content);
  if (noSelenium && privateFields.length >= 1 && getters.length >= 1 && getters.length >= privateFields.length - 1) {
    return 'type';
  }

  // 6. UTIL / HELPER — static utility methods, nothing Selenium-specific.
  const staticMethods = content.match(/(?:public|private|protected)?\s*static\s+(?!final)[\w<>\[\],\s]+\s+\w+\s*\([^)]*\)\s*\{/g) || [];
  if (noSelenium && (staticMethods.length >= 1 || SYNONYMS.util.includes(dirSeg))) {
    return 'util';
  }

  // 7. Unknown — converted as a flagged legacy stub so nothing is dropped silently.
  return 'unknown';
}

// ═══════════════════════════════════════════════════════════════
// PARSE: JAVA PAGE OBJECT
// ═══════════════════════════════════════════════════════════════

function parseJavaPage(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), locators: [], methods: [] };

  // Uses a backreference to the opening quote char so values that contain
  // the OTHER quote type (e.g. xpath text()='Sign In' inside a "..." value)
  // are captured in full instead of truncating at the first nested quote.
  const findByRe = /@FindBy\s*\(\s*(\w+)\s*=\s*(["'])((?:(?!\2).)*)\2\s*\)\s*(?:public|private|protected)?\s*\w+\s+(\w+)\s*;/g;
  let m;
  while ((m = findByRe.exec(content))) {
    const [, type, , val, name] = m;
    let conv;
    if (type === 'xpath') conv = convertLocator(val);
    else if (type === 'id') conv = `locator('#${val}')`;
    else if (type === 'name') conv = `locator('[name="${val}"]')`;
    else if (type === 'className' || type === 'css') conv = `locator('.${val}')`;
    else conv = `locator('${val}')`;
    result.locators.push({ name, original: `${type}="${val}"`, converted: conv });
  }

  const byRe = /(?:private|public|protected)?\s*By\s+(\w+)\s*=\s*(By\.\w+\s*\([^)]+\))\s*;/g;
  while ((m = byRe.exec(content))) {
    result.locators.push({ name: m[1], original: m[2], converted: convertLocator(m[2]) });
  }

  const methodRe = /public\s+(\w+)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{([\s\S]*?)\n\s{0,4}\}/g;
  while ((m = methodRe.exec(content))) {
    const [, ret, name, params, body] = m;
    if (name === result.className) continue; // skip constructor
    result.methods.push({ name, returnType: ret, params: params.trim(), body: body.trim() });
  }

  return result;
}

function generateSkeletonPage(parsed, javaFile) {
  const kebab = toKebabCase(parsed.className.replace(/Page$/, '')) || 'page';
  const methods = [];

  let out = `/**
 * @fileoverview ${parsed.className}
 * @source ${toPosix(javaFile)}
 */

import { Page, Locator, expect } from '@playwright/test';

export class ${parsed.className} {
  readonly page: Page;
`;

  for (const loc of parsed.locators) {
    out += `  /**
   * ${loc.name} locator
   * @type {Locator}
   */
  readonly ${loc.name}: Locator;
`;
  }

  out += `
  /**
   * Creates an instance of ${parsed.className}
   * @param {Page} page - Playwright page object
   */
  constructor(page: Page) {
    this.page = page;
`;
  for (const loc of parsed.locators) {
    out += `    this.${loc.name} = page.${loc.converted};\n`;
  }
  out += `  }\n`;

  for (const method of parsed.methods) {
    methods.push(method.name);
    const tp = convertParams(method.params);
    const ret = javaToTsType(method.returnType);

    out += `
  /**
   * ${formatMethodDescription(method.name)}
${tp.docs ? tp.docs + '\n' : ''}   * @returns {Promise<${ret}>}
   */
  async ${method.name}(${tp.params}): Promise<${ret}> {
    // TODO: Implement this method
    // Original Java:
    // ${method.body.split('\n').map((l) => l.trim()).filter((l) => l).join('\n    // ')}
    throw new Error('Method ${method.name} not implemented');
  }
`;
  }

  out += `}\n`;
  return { content: out, fileName: `${kebab}.page.ts`, className: parsed.className, methods };
}

// ═══════════════════════════════════════════════════════════════
// PARSE: JAVA STEP DEFINITIONS
// ═══════════════════════════════════════════════════════════════

function parseJavaSteps(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), steps: [], hooks: [] };

  const patterns = [
    /@(Given|When|Then|And|But)\s*\(\s*["'](.+?)["']\s*\)\s*(?:public\s+)?(?:void\s+)?(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{([\s\S]*?)\n\s{0,4}\}/g,
    /@(Given|When|Then|And|But)\s*\(\s*value\s*=\s*["'](.+?)["']\s*\)\s*(?:public\s+)?(?:void\s+)?(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{([\s\S]*?)\n\s{0,4}\}/g,
    /@(Given|When|Then|And|But)\s*\(\s*["']([\s\S]*?)["']\s*\)\s*(?:public\s+)?(?:void\s+)?(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{([\s\S]*?)\n\s{0,4}\}/g,
  ];

  const foundSteps = new Set();

  for (const stepRe of patterns) {
    let m;
    while ((m = stepRe.exec(content))) {
      let [, ann, text, name, params, body] = m;
      text = text.replace(/\s+/g, ' ').trim();
      if (foundSteps.has(text)) continue;
      foundSteps.add(text);

      if (ann === 'And' || ann === 'But') {
        const lower = text.toLowerCase();
        if (
          lower.includes('click') || lower.includes('enter') || lower.includes('select') ||
          lower.includes('type') || lower.includes('input') || lower.includes('fill') ||
          lower.includes('submit') || lower.includes('press') || lower.includes('navigate')
        ) {
          ann = 'When';
        } else if (
          lower.includes('should') || lower.includes('verify') || lower.includes('see') ||
          lower.includes('displayed') || lower.includes('visible') || lower.includes('assert') ||
          lower.includes('error') || lower.includes('message') || lower.includes('contains')
        ) {
          ann = 'Then';
        } else {
          ann = 'Given';
        }
      }

      result.steps.push({
        annotation: ann,
        stepText: text,
        methodName: name,
        params: params.trim(),
        body: body ? body.trim() : '',
      });
    }
  }

  // @Before / @After hooks inside a step-definition class (legal Cucumber pattern)
  const hookRe = /@(Before|After)(?:\s*\(\s*(?:["'][^"']*["'])?\s*\))?\s*(?:public\s+)?(?:void\s+)?(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{([\s\S]*?)\n\s{0,4}\}/g;
  let hm;
  while ((hm = hookRe.exec(content))) {
    const [, kind, name, params, body] = hm;
    result.hooks.push({ kind, methodName: name, params: params.trim(), body: body.trim() });
  }

  return result;
}

/**
 * Convert a Gherkin/Cucumber expression step text into a matching RegExp.
 * Supports {string}, {int}, {float}, {word} and the anonymous {}.
 */
function stepTextToRegex(stepText) {
  let escaped = stepText.replace(/[.*+?^${}()|[\]\\]/g, (c) => {
    // Don't escape the placeholder braces themselves, handle below instead
    return '\\' + c;
  });
  // Restore our placeholder markers (they were escaped above) then convert them
  escaped = escaped
    .replace(/\\\{string\\\}/g, '"([^"]*)"')
    .replace(/\\\{int\\\}/g, '(-?\\d+)')
    .replace(/\\\{float\\\}/g, '(-?\\d+\\.\\d+)')
    .replace(/\\\{word\\\}/g, '(\\S+)')
    .replace(/\\\{\\\}/g, '(.+)');
  return new RegExp('^' + escaped + '$', 'i');
}

function generateSkeletonSteps(parsed, javaFile, outFileName) {
  const steps = [];
  const stepTexts = [];

  let out = `/**
 * @fileoverview ${parsed.className} — step implementations
 * @source ${toPosix(javaFile)}
 *
 * These are plain exported functions (NOT a playwright-bdd glue file).
 * Each one is invoked from inside a generated tests/specs/*.spec.ts file,
 * wrapped in its own test.step() so it shows up individually in the
 * Playwright HTML report / trace viewer.
 */

import type { AppFixtures } from '../fixtures/test-fixtures';
import { expect } from '@playwright/test';

`;

  for (const step of parsed.steps) {
    steps.push(step.methodName);
    stepTexts.push(step.stepText);
    const tp = convertParams(step.params);
    const callParams = tp.params ? `fixtures: AppFixtures, ${tp.params}` : `fixtures: AppFixtures`;

    out += `/**
 * ${step.annotation}: ${step.stepText}
${tp.docs ? tp.docs + '\n' : ''} */
export async function ${step.methodName}(${callParams}): Promise<void> {
  // TODO: Implement this step
  // Original Java:
  // ${step.body.split('\n').map((l) => l.trim()).filter((l) => l).join('\n  // ')}
  throw new Error('Step ${step.methodName} not implemented');
}

`;

    stepRegistry.push({
      pattern: stepTextToRegex(step.stepText),
      paramNames: tp.names,
      paramTypes: tp.types,
      importPath: outFileName, // filled in by caller with the real relative path
      functionName: step.methodName,
      stepText: step.stepText,
    });
  }

  for (const hook of parsed.hooks) {
    const tp = convertParams(hook.params);
    out += `/**
 * NOTE: Originally a Cucumber @${hook.kind} hook.
 * Consider wiring this into src/fixtures/test-fixtures.ts (fixture setup/teardown)
 * or a test.beforeEach()/afterEach() in the relevant spec file instead of
 * calling it as a step.
 */
export async function ${hook.methodName}(fixtures: AppFixtures${tp.params ? ', ' + tp.params : ''}): Promise<void> {
  // TODO: Implement this hook
  // Original Java:
  // ${hook.body.split('\n').map((l) => l.trim()).filter((l) => l).join('\n  // ')}
  throw new Error('Hook ${hook.methodName} not implemented');
}

`;
  }

  return { content: out, steps, stepTexts, hookNames: parsed.hooks.map((h) => h.methodName) };
}

// ═══════════════════════════════════════════════════════════════
// PARSE + GENERATE: UTIL / HELPER CLASSES
// ═══════════════════════════════════════════════════════════════

function parseJavaUtil(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), methods: [] };
  const methodRe = /(?:public|private|protected)?\s*static\s+(?!final\b)([\w<>\[\],\s]+?)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{([\s\S]*?)\n\s{0,4}\}/g;
  let m;
  while ((m = methodRe.exec(content))) {
    const [, ret, name, params, body] = m;
    result.methods.push({ name, returnType: ret.trim(), params: params.trim(), body: body.trim() });
  }
  // Fall back to non-static public methods if no static utility methods found
  if (result.methods.length === 0) {
    const instRe = /public\s+([\w<>\[\],\s]+?)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{([\s\S]*?)\n\s{0,4}\}/g;
    while ((m = instRe.exec(content))) {
      const [, ret, name, params, body] = m;
      if (name === result.className) continue;
      result.methods.push({ name, returnType: ret.trim(), params: params.trim(), body: body.trim() });
    }
  }
  return result;
}

function generateSkeletonUtil(parsed, javaFile) {
  const functions = [];
  let out = `/**
 * @fileoverview ${parsed.className} — utility functions
 * @source ${toPosix(javaFile)}
 */

`;
  for (const method of parsed.methods) {
    functions.push(method.name);
    const tp = convertParams(method.params);
    const ret = javaToTsType(method.returnType);
    out += `/**
 * ${formatMethodDescription(method.name)}
${tp.docs ? tp.docs + '\n' : ''}   * @returns {${ret}}
 */
export function ${method.name}(${tp.params}): ${ret} {
  // TODO: Implement this function
  // Original Java:
  // ${method.body.split('\n').map((l) => l.trim()).filter((l) => l).join('\n  // ')}
  throw new Error('Function ${method.name} not implemented');
}

`;
  }
  return { content: out, functions };
}

// ═══════════════════════════════════════════════════════════════
// PARSE + GENERATE: CONFIG / CONSTANTS (fully automatic, no TODOs)
// ═══════════════════════════════════════════════════════════════

function convertJavaValueLiteral(raw) {
  let v = raw.trim();

  let m = v.match(/^System\.getenv\s*\(\s*["']([^"']+)["']\s*\)$/);
  if (m) return `process.env.${m[1]} ?? ''`;

  m = v.match(/^System\.getProperty\s*\(\s*["']([^"']+)["']\s*\)$/);
  if (m) return `process.env.${m[1].replace(/\./g, '_').toUpperCase()} ?? ''`;

  // Already a valid TS literal (string, number, boolean, simple array)
  if (/^["'].*["']$/.test(v) || /^-?\d+(\.\d+)?$/.test(v) || /^(true|false)$/.test(v)) {
    return v;
  }

  // new String[]{"a","b"} -> ["a","b"]
  m = v.match(/^new\s+\w+\[\]\s*\{([\s\S]*)\}$/);
  if (m) return `[${m[1]}]`;

  // Unrecognized expression — keep it but flag with a comment on the call site
  return `${v} /* TODO: verify converted value */`;
}

function parseJavaConfig(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), constants: [] };
  const fieldRe = /(?:public|private|protected)?\s*static\s+final\s+([\w<>\[\],\s]+?)\s+(\w+)\s*=\s*([\s\S]*?);/g;
  let m;
  while ((m = fieldRe.exec(content))) {
    const [, type, name, value] = m;
    result.constants.push({ name, type: type.trim(), value: value.trim() });
  }
  return result;
}

function generateConfigFile(parsed, javaFile) {
  let out = `/**
 * @fileoverview ${parsed.className} — configuration constants
 * @source ${toPosix(javaFile)}
 * Auto-converted 1:1 from \`static final\` fields. Review TODO markers (if any).
 */

`;
  for (const c of parsed.constants) {
    const tsType = javaToTsType(c.type);
    const tsValue = convertJavaValueLiteral(c.value);
    out += `export const ${c.name}: ${tsType} = ${tsValue};\n`;
  }
  return out;
}

// ═══════════════════════════════════════════════════════════════
// PARSE + GENERATE: POJO / MODEL / DTO (fully automatic)
// ═══════════════════════════════════════════════════════════════

function parseJavaType(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), fields: [] };
  const fieldRe = /private\s+([\w<>\[\],\s.]+?)\s+(\w+)\s*;/g;
  let m;
  while ((m = fieldRe.exec(content))) {
    const [, type, name] = m;
    result.fields.push({ name, type: type.trim() });
  }
  return result;
}

function generateTypeFile(parsed, javaFile) {
  let out = `/**
 * @fileoverview ${parsed.className} — data model
 * @source ${toPosix(javaFile)}
 * Auto-converted from a Java POJO/DTO's private fields.
 */

export interface ${parsed.className} {
`;
  for (const f of parsed.fields) {
    out += `  ${f.name}: ${javaToTsType(f.type)};\n`;
  }
  out += `}\n`;
  return out;
}

// ═══════════════════════════════════════════════════════════════
// LEGACY FALLBACK (unclassified files — never silently dropped)
// ═══════════════════════════════════════════════════════════════

function generateLegacyStub(content, javaFile, className) {
  return `/**
 * @fileoverview ${className} — UNCLASSIFIED SOURCE FILE
 * @source ${toPosix(javaFile)}
 *
 * ⚠️  This file could not be confidently classified as a page object, step
 * definition, utility, config, or model. The original Java source is kept
 * below for reference. Please review manually and move the converted logic
 * into src/pages, src/steps, src/utils, src/config, or src/types as
 * appropriate, then delete this file.
 *
 * Original Java:
 * ${content.split('\n').map((l) => l).join('\n * ')}
 */

export {}; // placeholder — remove once migrated
`;
}

// ═══════════════════════════════════════════════════════════════
// FEATURE FILE (GHERKIN) PARSING
// ═══════════════════════════════════════════════════════════════

function parseFeatureFile(content) {
  const lines = content.split('\n');
  const feature = { tags: [], name: '', description: [], background: null, scenarios: [] };

  let pendingTags = [];
  let mode = 'top'; // 'top' | 'description' | 'background' | 'scenario' | 'examples'
  let currentScenario = null;
  let currentExamples = null;
  let lastStepRef = null;

  for (let raw of lines) {
    const line = raw.replace(/\t/g, '  ');
    const trimmed = line.trim();

    if (!trimmed || trimmed.startsWith('#')) continue;

    if (trimmed.startsWith('@')) {
      pendingTags.push(...trimmed.split(/\s+/));
      continue;
    }

    if (/^Feature:/i.test(trimmed)) {
      feature.name = trimmed.replace(/^Feature:\s*/i, '').trim();
      feature.tags = pendingTags;
      pendingTags = [];
      mode = 'description';
      continue;
    }

    if (/^Background:/i.test(trimmed)) {
      feature.background = { steps: [] };
      mode = 'background';
      lastStepRef = null;
      continue;
    }

    if (/^Scenario Outline:|^Scenario Template:/i.test(trimmed)) {
      currentScenario = {
        type: 'outline',
        tags: pendingTags,
        name: trimmed.replace(/^Scenario Outline:|^Scenario Template:/i, '').trim(),
        steps: [],
        examples: [],
      };
      pendingTags = [];
      feature.scenarios.push(currentScenario);
      mode = 'scenario';
      lastStepRef = null;
      continue;
    }

    if (/^Scenario:/i.test(trimmed)) {
      currentScenario = {
        type: 'scenario',
        tags: pendingTags,
        name: trimmed.replace(/^Scenario:\s*/i, '').trim(),
        steps: [],
        examples: [],
      };
      pendingTags = [];
      feature.scenarios.push(currentScenario);
      mode = 'scenario';
      lastStepRef = null;
      continue;
    }

    if (/^Examples:|^Scenarios:/i.test(trimmed)) {
      currentExamples = { headers: [], rows: [] };
      currentScenario.examples.push(currentExamples);
      mode = 'examples';
      continue;
    }

    if (/^(Given|When|Then|And|But)\s+/.test(trimmed)) {
      const km = trimmed.match(/^(Given|When|Then|And|But)\s+(.*)$/);
      const stepObj = { keyword: km[1], text: km[2].trim(), docString: null, dataTable: null };
      if (mode === 'background') {
        feature.background.steps.push(stepObj);
      } else if (mode === 'scenario') {
        currentScenario.steps.push(stepObj);
      }
      lastStepRef = stepObj;
      continue;
    }

    if (trimmed.startsWith('|')) {
      const cells = trimmed
        .split('|')
        .slice(1, -1)
        .map((c) => c.trim());
      if (mode === 'examples') {
        if (currentExamples.headers.length === 0) currentExamples.headers = cells;
        else currentExamples.rows.push(cells);
      } else if (lastStepRef) {
        if (!lastStepRef.dataTable) lastStepRef.dataTable = { headers: [], rows: [] };
        if (lastStepRef.dataTable.headers.length === 0) lastStepRef.dataTable.headers = cells;
        else lastStepRef.dataTable.rows.push(cells);
      }
      continue;
    }

    if (trimmed.startsWith('"""')) {
      // DocString — best effort: not multi-line parsed, just flagged for manual review
      if (lastStepRef) lastStepRef.docString = '(doc string present — see original .feature file)';
      continue;
    }

    if (mode === 'description') {
      feature.description.push(trimmed);
    }
  }

  return feature;
}

function substitutePlaceholders(text, headers, row) {
  let out = text;
  headers.forEach((h, i) => {
    out = out.split(`<${h}>`).join(row[i] ?? '');
  });
  return out;
}

function escapeTsString(s) {
  return s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

/**
 * Find a registered step function matching a concrete (placeholder-free)
 * step text, returning the call expression args as TS literals.
 */
function matchStep(stepText) {
  for (const entry of stepRegistry) {
    const m = entry.pattern.exec(stepText);
    if (m) {
      const rawArgs = m.slice(1);
      const args = rawArgs.map((a, i) => {
        const t = entry.paramTypes[i];
        if (t === 'number') return a;
        if (t === 'boolean') return /^(true|false)$/i.test(a) ? a.toLowerCase() : `'${escapeTsString(a)}'`;
        return `'${escapeTsString(a)}'`;
      });
      return { entry, args };
    }
  }
  return null;
}

function stepCallStatement(stepObj, indent) {
  const match = matchStep(stepObj.text);
  const label = escapeTsString(`${stepObj.keyword} ${stepObj.text}`);
  if (!match) {
    return `${indent}await test.step('${label}', async () => {
${indent}  // TODO: no matching step implementation found in src/steps for this text.
${indent}  // Check src/steps/*.steps.ts for a function whose @source step text matches,
${indent}  // or implement the logic inline here.
${indent}  throw new Error('Step not implemented: ${label}');
${indent}});`;
  }
  const fnImportAlias = match.entry.moduleAlias;
  const argList = ['fixtures', ...match.args].join(', ');
  let extra = '';
  if (stepObj.dataTable) {
    extra = `\n${indent}  // NOTE: original step had a Cucumber DataTable — wire it in manually if needed.`;
  }
  if (stepObj.docString) {
    extra += `\n${indent}  // NOTE: original step had a Cucumber DocString — wire it in manually if needed.`;
  }
  return `${indent}await test.step('${label}', async () => {${extra}
${indent}  await ${fnImportAlias}.${match.entry.functionName}(${argList});
${indent}});`;
}

// ═══════════════════════════════════════════════════════════════
// SPEC FILE GENERATION (replaces playwright-bdd entirely)
// ═══════════════════════════════════════════════════════════════

function generateSpecFile(feature, sourceFeaturePath, specRelDir) {
  // Figure out which step modules are actually referenced so we only import those.
  const usedModules = new Map(); // importPath -> alias

  function ensureModuleAlias(importPath) {
    if (!usedModules.has(importPath)) {
      const alias = 'steps_' + usedModules.size;
      usedModules.set(importPath, alias);
    }
    return usedModules.get(importPath);
  }

  function annotateStepsWithAlias(steps) {
    for (const s of steps) {
      const m = matchStep(s.text);
      if (m) {
        const alias = ensureModuleAlias(m.entry.importPath);
        m.entry.moduleAlias = alias; // mutate registry entry for use in stepCallStatement
      }
    }
  }

  if (feature.background) annotateStepsWithAlias(feature.background.steps);
  for (const sc of feature.scenarios) annotateStepsWithAlias(sc.steps);

  const depth = specRelDir.split('/').filter(Boolean).length;
  const upToRoot = '../'.repeat(depth + 2); // tests/specs/<specRelDir>/ -> project root

  let out = `/**
 * @fileoverview ${feature.name}
 * @source ${toPosix(sourceFeaturePath)}
 *
 * Auto-generated from a Gherkin .feature file. Every Given/When/Then/And/But
 * step is wrapped in its own test.step() so each one shows up individually
 * in the Playwright HTML report and trace viewer — this is a plain
 * Playwright spec, not playwright-bdd.
 */

import { test } from '${upToRoot}src/fixtures/test-fixtures';
`;
  for (const [importPath, alias] of usedModules) {
    out += `import * as ${alias} from '${upToRoot}${importPath}';\n`;
  }

  out += `\ntest.describe('${escapeTsString(feature.name)}', () => {\n`;

  if (feature.background && feature.background.steps.length) {
    out += `  async function runBackground(fixtures: Parameters<Parameters<typeof test>[1]>[0]) {\n`;
    for (const s of feature.background.steps) {
      out += stepCallStatement(s, '    ') + '\n';
    }
    out += `  }\n\n`;
  }

  for (const sc of feature.scenarios) {
    if (sc.type === 'scenario') {
      out += `  test('${escapeTsString(sc.name)}', async (fixtures) => {\n`;
      if (feature.background && feature.background.steps.length) {
        out += `    await runBackground(fixtures);\n`;
      }
      for (const s of sc.steps) {
        out += stepCallStatement(s, '    ') + '\n';
      }
      out += `  });\n\n`;
    } else {
      // Scenario Outline -> one test per Examples row
      for (const ex of sc.examples) {
        ex.rows.forEach((row, idx) => {
          const title = `${sc.name} (Examples: ${ex.headers.map((h, i) => `${h}=${row[i]}`).join(', ')})`;
          out += `  test('${escapeTsString(title)}', async (fixtures) => {\n`;
          if (feature.background && feature.background.steps.length) {
            out += `    await runBackground(fixtures);\n`;
          }
          for (const s of sc.steps) {
            const concreteText = substitutePlaceholders(s.text, ex.headers, row);
            out += stepCallStatement({ ...s, text: concreteText }, '    ') + '\n';
          }
          out += `  });\n\n`;
        });
      }
    }
  }

  out += `});\n`;
  return out;
}

// ═══════════════════════════════════════════════════════════════
// FIXTURES + CONFIG GENERATION
// ═══════════════════════════════════════════════════════════════

function generateFixtures(pageRegistrations) {
  let imports = '';
  let types = '';
  let impl = '';

  for (const p of pageRegistrations) {
    imports += `import { ${p.className} } from '../pages/${p.importPath}';\n`;
    types += `  ${p.fixtureName}: ${p.className};\n`;
    impl += `  ${p.fixtureName}: async ({ page }, use) => { await use(new ${p.className}(page)); },\n`;
  }

  return `/**
 * @fileoverview Playwright custom fixtures
 *
 * Wires every generated Page Object into Playwright's test object as a
 * fixture. Step functions and spec files receive this as \`fixtures\`.
 */

import { test as base } from '@playwright/test';
${imports}
type CustomFixtures = {
${types}};

export const test = base.extend<CustomFixtures>({
${impl}});

export type AppFixtures = CustomFixtures & { page: import('@playwright/test').Page };

export { expect } from '@playwright/test';
`;
}

function generatePlaywrightConfig() {
  return `import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/specs',
  timeout: 30000,
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [['html'], ['list']],

  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:3000',

    // Use installed Desktop Chrome rather than the bundled Playwright browser
    channel: 'chrome',

    // Saved auth state (cookies/session, never credentials) — see docs/AUTHENTICATION.md
    storageState: './auth.json',

    headless: false, // set true for CI
    viewport: { width: 1280, height: 720 },

    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },

  projects: [
    {
      name: 'setup',
      testMatch: /.*\\.setup\\.ts/,
      use: { storageState: undefined },
    },
    {
      name: 'desktop-chrome',
      dependencies: ['setup'],
      use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    },
  ],

  // Uncomment to start a local server before tests:
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://localhost:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});
`;
}

// ═══════════════════════════════════════════════════════════════
// MAIN MIGRATION PASS
// ═══════════════════════════════════════════════════════════════

let pageRegistrations = []; // { className, importPath (relative to src/pages, no ext), fixtureName }
let infraNotes = [];
let legacyFiles = [];

function recordManifest(sourceFile, category, outputFile, notes) {
  manifest.files.push({ source: toPosix(sourceFile), category, output: outputFile ? toPosix(outputFile) : null, notes: notes || '' });
}

function migrateJavaFiles() {
  console.log('\n🔎 Scanning entire source repo...\n');
  const javaFiles = getAllFiles(CONFIG.sourceDir, '.java');
  if (!javaFiles.length) {
    console.log('   No .java files found under ' + CONFIG.sourceDir);
    return;
  }
  console.log(`   Found ${javaFiles.length} Java file(s)\n`);

  for (const file of javaFiles) {
    const fileName = path.basename(file);
    const relDir = path.relative(CONFIG.sourceDir, path.dirname(file));
    let content;
    try {
      content = fs.readFileSync(file, 'utf-8');
    } catch (e) {
      console.log(`   ❌ ${fileName}: could not read (${e.message})`);
      continue;
    }

    const category = classifyJavaFile(content, fileName, relDir);

    try {
      switch (category) {
        case 'page': {
          const parsed = parseJavaPage(content, fileName);
          const result = generateSkeletonPage(parsed, file);
          const outDir = path.join(CONFIG.pagesOut, stripKnownPrefix(relDir, SYNONYMS.page));
          ensureDir(outDir);
          const outPath = path.join(outDir, result.fileName);
          fs.writeFileSync(outPath, result.content);

          const relPath = toPosix(path.relative('.', outPath));
          pending.pages[result.fileName] = result.methods;
          pending.pageFiles.push(relPath);
          pending.totalMethods += result.methods.length;

          const importPath = toPosix(path.relative(CONFIG.pagesOut, outPath)).replace(/\.ts$/, '');
          pageRegistrations.push({
            className: result.className,
            importPath,
            fixtureName: toCamelCase(result.className),
          });

          recordManifest(file, 'page', outPath, `${result.methods.length} method(s) need implementation`);
          console.log(`   📄 PAGE   ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${relPath}`);
          break;
        }
        case 'steps': {
          const parsed = parseJavaSteps(content, fileName);
          const kebab = toKebabCase(parsed.className.replace(/Steps?$/, '')) || 'steps';
          const outFileName = `${kebab}.steps.ts`;
          const outDir = path.join(CONFIG.stepsOut, stripKnownPrefix(relDir, SYNONYMS.steps));
          ensureDir(outDir);
          const outPath = path.join(outDir, outFileName);
          const relImportFromRoot = toPosix(path.relative('.', outPath)).replace(/^.*?src\//, 'src/').replace(/\.ts$/, '');

          const result = generateSkeletonSteps(parsed, file, relImportFromRoot);
          fs.writeFileSync(outPath, result.content);

          const relPath = toPosix(path.relative('.', outPath));
          pending.steps[outFileName] = result.stepTexts;
          pending.stepFiles.push(relPath);
          pending.totalSteps += result.steps.length;

          recordManifest(
            file,
            'steps',
            outPath,
            `${result.steps.length} step(s)${result.hookNames.length ? `, ${result.hookNames.length} hook(s)` : ''} need implementation`
          );
          console.log(`   📝 STEPS  ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${relPath}`);
          break;
        }
        case 'util': {
          const parsed = parseJavaUtil(content, fileName);
          const kebab = toKebabCase(parsed.className) || 'util';
          const outFileName = `${kebab}.utils.ts`;
          const outDir = path.join(CONFIG.utilsOut, stripKnownPrefix(relDir, SYNONYMS.util));
          ensureDir(outDir);
          const outPath = path.join(outDir, outFileName);
          const result = generateSkeletonUtil(parsed, file);
          fs.writeFileSync(outPath, result.content);

          const relPath = toPosix(path.relative('.', outPath));
          pending.utils[outFileName] = result.functions;
          pending.utilFiles.push(relPath);
          pending.totalUtilFunctions += result.functions.length;

          recordManifest(file, 'util', outPath, `${result.functions.length} function(s) need implementation`);
          console.log(`   🔧 UTIL   ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${relPath}`);
          break;
        }
        case 'config': {
          const parsed = parseJavaConfig(content, fileName);
          const kebab = toKebabCase(parsed.className) || 'config';
          const outFileName = `${kebab}.config.ts`;
          const outDir = path.join(CONFIG.configOut, stripKnownPrefix(relDir, SYNONYMS.config));
          ensureDir(outDir);
          const outPath = path.join(outDir, outFileName);
          fs.writeFileSync(outPath, generateConfigFile(parsed, file));

          recordManifest(file, 'config', outPath, `${parsed.constants.length} constant(s) auto-converted`);
          console.log(`   ⚙️  CONFIG ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${toPosix(path.relative('.', outPath))}`);
          break;
        }
        case 'type': {
          const parsed = parseJavaType(content, fileName);
          const kebab = toKebabCase(parsed.className) || 'model';
          const outFileName = `${kebab}.types.ts`;
          const outDir = path.join(CONFIG.typesOut, stripKnownPrefix(relDir, SYNONYMS.type));
          ensureDir(outDir);
          const outPath = path.join(outDir, outFileName);
          fs.writeFileSync(outPath, generateTypeFile(parsed, file));

          recordManifest(file, 'type', outPath, `${parsed.fields.length} field(s) auto-converted`);
          console.log(`   🧩 TYPE   ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${toPosix(path.relative('.', outPath))}`);
          break;
        }
        case 'infra': {
          infraNotes.push({ file: toPosix(path.relative(CONFIG.sourceDir, file)), className: getClassOrInterfaceName(content, fileName) });
          recordManifest(file, 'infra', null, 'Superseded by Playwright config/fixtures/reporters — see docs/migration-notes/infrastructure.md');
          console.log(`   ⚠️  INFRA  ${toPosix(path.relative(CONFIG.sourceDir, file))} → (no TS output — see migration notes)`);
          break;
        }
        default: {
          const className = getClassOrInterfaceName(content, fileName.replace('.java', ''));
          const outDir = path.join(CONFIG.legacyOut, relDir === '.' ? '' : relDir);
          ensureDir(outDir);
          const outFileName = `${toKebabCase(className) || toKebabCase(fileName.replace('.java', ''))}.legacy.ts`;
          const outPath = path.join(outDir, outFileName);
          fs.writeFileSync(outPath, generateLegacyStub(content, file, className));

          legacyFiles.push(toPosix(path.relative('.', outPath)));
          manifest.needsManualReview.push(toPosix(path.relative(CONFIG.sourceDir, file)));
          recordManifest(file, 'unknown', outPath, 'Could not be classified — needs manual review');
          console.log(`   ❓ UNKNOWN ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${toPosix(path.relative('.', outPath))} (needs manual review)`);
          break;
        }
      }
    } catch (e) {
      console.log(`   ❌ ${fileName}: ${e.message}`);
      recordManifest(file, 'error', null, e.message);
    }
  }
}

function migrateFeatureFiles() {
  console.log('\n📋 Processing Feature Files...\n');
  const featureFiles = getAllFiles(CONFIG.sourceDir, '.feature');
  if (!featureFiles.length) {
    console.log('   No .feature files found');
    return;
  }

  for (const file of featureFiles) {
    const relDir = stripKnownPrefix(path.relative(CONFIG.sourceDir, path.dirname(file)), ['features', 'feature']);
    const fileName = path.basename(file);

    // 1. Copy original feature file (kept for traceability / diffing against source)
    const featOutDir = path.join(CONFIG.featuresOut, relDir);
    ensureDir(featOutDir);
    let content = fs.readFileSync(file, 'utf-8');
    fs.writeFileSync(path.join(featOutDir, fileName), content);

    // 2. Generate a standard Playwright spec with test.step() per Gherkin step
    const feature = parseFeatureFile(content);
    const specFileName = toKebabCase(fileName.replace('.feature', '')) + '.spec.ts';
    const specOutDir = path.join(CONFIG.specsOut, relDir);
    ensureDir(specOutDir);
    const specContent = generateSpecFile(feature, file, relDir);
    fs.writeFileSync(path.join(specOutDir, specFileName), specContent);

    const totalSteps =
      (feature.background ? feature.background.steps.length : 0) +
      feature.scenarios.reduce((sum, sc) => sum + sc.steps.length * (sc.type === 'outline' ? Math.max(1, sc.examples.reduce((s, e) => s + e.rows.length, 0)) : 1), 0);

    recordManifest(file, 'feature', path.join(specOutDir, specFileName), `${feature.scenarios.length} scenario(s), ~${totalSteps} step invocation(s)`);
    console.log(`   ✅ ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${toPosix(path.join(specOutDir, specFileName))} (${feature.scenarios.length} scenario(s))`);
  }
}

function generateInfraNotesDoc() {
  ensureDir(CONFIG.notesOut);
  if (infraNotes.length === 0) return;

  let out = `# Infrastructure Files — Not Converted 1:1

These Java source files implement test-framework plumbing (driver lifecycle,
test runner wiring, hooks, reporting/listeners). Playwright provides this
natively, so they were intentionally **not** transliterated into TypeScript.
Use the table below to find the Playwright equivalent for each one.

| Source file | Class | Playwright equivalent |
|---|---|---|
`;
  for (const n of infraNotes) {
    out += `| \`${n.file}\` | \`${n.className}\` | See notes below |\n`;
  }

  out += `
## Cheat sheet

| Java/Selenium concept | Playwright equivalent |
|---|---|
| \`Hooks.java\` (\`@Before\`/\`@After\`) | \`src/fixtures/test-fixtures.ts\` fixture setup/teardown, or \`test.beforeEach\`/\`test.afterEach\` in a spec file |
| \`DriverFactory\` / \`DriverManager\` | \`playwright.config.ts\` \`projects\` + \`use\` block (browser/channel is configured once, not per-test) |
| \`TestRunner\` (\`@RunWith(Cucumber.class)\`, \`@CucumberOptions\`) | \`playwright.config.ts\` \`testDir: './tests/specs'\` — Playwright's own test runner discovers and runs specs, no runner class needed |
| \`Listener\` (\`ITestListener\`, \`WebDriverEventListener\`) | Built-in reporters (\`html\`, \`list\`, \`json\`) configured in \`playwright.config.ts\`, plus the trace viewer (\`trace: 'on-first-retry'\`) |
| \`ExtentReports\` | Playwright's HTML reporter (\`npx playwright show-report\`) covers most of the same ground; for richer custom reports consider \`playwright-html-reporter\` plugins |
| \`WebDriverManager\` (binary management) | Not needed — Playwright manages/launches browsers itself, or use \`channel: 'chrome'\` to drive the installed Desktop Chrome |
`;

  fs.writeFileSync(path.join(CONFIG.notesOut, 'infrastructure.md'), out);
  console.log(`\n   📓 Wrote docs/migration-notes/infrastructure.md (${infraNotes.length} file(s))`);
}

function generateSupportFiles() {
  console.log('\n🔧 Generating Support Files...\n');

  ensureDir(CONFIG.fixturesOut);
  fs.writeFileSync(path.join(CONFIG.fixturesOut, 'test-fixtures.ts'), generateFixtures(pageRegistrations));
  console.log('   ✅ src/fixtures/test-fixtures.ts');

  fs.writeFileSync('playwright.config.ts', generatePlaywrightConfig());
  console.log('   ✅ playwright.config.ts');

  fs.writeFileSync(CONFIG.pendingFile, JSON.stringify(pending, null, 2));
  console.log(`   ✅ ${CONFIG.pendingFile}`);

  manifest.summary = {
    totalSourceFiles: manifest.files.length,
    pages: manifest.files.filter((f) => f.category === 'page').length,
    steps: manifest.files.filter((f) => f.category === 'steps').length,
    utils: manifest.files.filter((f) => f.category === 'util').length,
    config: manifest.files.filter((f) => f.category === 'config').length,
    types: manifest.files.filter((f) => f.category === 'type').length,
    infra: manifest.files.filter((f) => f.category === 'infra').length,
    features: manifest.files.filter((f) => f.category === 'feature').length,
    unknown: manifest.files.filter((f) => f.category === 'unknown').length,
    errors: manifest.files.filter((f) => f.category === 'error').length,
  };
  fs.writeFileSync(CONFIG.manifestFile, JSON.stringify(manifest, null, 2));
  console.log(`   ✅ ${CONFIG.manifestFile}`);

  generateInfraNotesDoc();
}

function runMigration() {
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('     SELENIUM (JAVA) → PLAYWRIGHT (TYPESCRIPT) MIGRATION');
  console.log('═══════════════════════════════════════════════════════════════');

  // Pass 1: classify and convert every .java file in the repo.
  migrateJavaFiles();

  // Pass 2: feature files need the step registry from pass 1 to be complete
  // before they can be matched against, so this always runs second.
  migrateFeatureFiles();

  generateSupportFiles();

  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('                    SKELETON GENERATION COMPLETE');
  console.log('═══════════════════════════════════════════════════════════════\n');
  console.log(`   Source files scanned:  ${manifest.summary.totalSourceFiles}`);
  console.log(`   ├─ Pages:              ${manifest.summary.pages}  (${pending.totalMethods} methods to implement)`);
  console.log(`   ├─ Step files:         ${manifest.summary.steps}  (${pending.totalSteps} steps to implement)`);
  console.log(`   ├─ Utils:              ${manifest.summary.utils}  (${pending.totalUtilFunctions} functions to implement)`);
  console.log(`   ├─ Config (auto):      ${manifest.summary.config}`);
  console.log(`   ├─ Types/POJOs (auto): ${manifest.summary.types}`);
  console.log(`   ├─ Feature files:      ${manifest.summary.features} → tests/specs/**/*.spec.ts`);
  console.log(`   ├─ Infra (notes only): ${manifest.summary.infra}`);
  console.log(`   └─ Unclassified:       ${manifest.summary.unknown}  ${manifest.summary.unknown ? '⚠️  see migration-manifest.json' : ''}`);
  console.log('');
  console.log('   Next Steps (ONE FILE, ONE METHOD at a time):');
  console.log('     @pw-orchestrator start');
  console.log('\n═══════════════════════════════════════════════════════════════\n');
}

function showStatus() {
  if (!fs.existsSync(CONFIG.pendingFile)) {
    console.log('No pending-methods.json found. Run: npm run migrate');
    return;
  }
  const p = JSON.parse(fs.readFileSync(CONFIG.pendingFile, 'utf-8'));

  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('                    MIGRATION STATUS');
  console.log('═══════════════════════════════════════════════════════════════\n');

  console.log('   PAGE FILES:');
  p.pageFiles.forEach((file, i) => {
    const methods = p.pages[path.basename(file)] || [];
    console.log(`     ${i + 1}. ${file}`);
    methods.forEach((m) => console.log(`        • ${m}`));
  });

  console.log('\n   STEP FILES:');
  p.stepFiles.forEach((file, i) => {
    const steps = p.steps[path.basename(file)] || [];
    console.log(`     ${i + 1}. ${file}`);
    steps.slice(0, 3).forEach((s) => console.log(`        • ${s.substring(0, 50)}...`));
    if (steps.length > 3) console.log(`        ... and ${steps.length - 3} more`);
  });

  console.log('\n   UTIL FILES:');
  (p.utilFiles || []).forEach((file, i) => {
    const fns = p.utils[path.basename(file)] || [];
    console.log(`     ${i + 1}. ${file}`);
    fns.forEach((f) => console.log(`        • ${f}`));
  });

  console.log('\n   TOTALS:');
  console.log(`     Methods:   ${p.totalMethods}`);
  console.log(`     Steps:     ${p.totalSteps}`);
  console.log(`     Functions: ${p.totalUtilFunctions || 0}`);
  console.log('\n═══════════════════════════════════════════════════════════════\n');
}

function showHelp() {
  console.log(`
Selenium to Playwright Migration Script

Usage:
  npm run migrate          - Run full migration (create skeletons)
  npm run migrate:status   - Show migration status
  npm run migrate:help     - Show this help
  npm run migrate:force    - Force re-run (DANGEROUS: overwrites existing files)

This script:
  1. Scans the ENTIRE _source-java/ tree (any folder layout)
  2. Classifies each .java file: page / steps / util / config / type / infra / unknown
  3. Converts locators to Playwright format
  4. Creates TypeScript skeleton files with TODO markers (pages, steps, utils)
  5. Auto-converts constants and POJOs (no judgement needed, no TODOs)
  6. Compiles each .feature file straight into a standard Playwright spec —
     no playwright-bdd — with every Given/When/Then/And/But step wrapped in
     its own test.step()
  7. Generates migration-manifest.json so every source file's fate is traceable

After running, use @pw-orchestrator to implement the TODO methods/steps/functions.

SAFETY: This script will NOT overwrite existing output unless --force is used.
`);
}

function checkExistingFiles() {
  const existingPages = getAllFiles(CONFIG.pagesOut, '.page.ts');
  const existingSteps = getAllFiles(CONFIG.stepsOut, '.steps.ts');
  const existingSpecs = getAllFiles(CONFIG.specsOut, '.spec.ts');

  if (existingPages.length > 0 || existingSteps.length > 0 || existingSpecs.length > 0) {
    console.log('\n═══════════════════════════════════════════════════════════════');
    console.log('   ⚠️  WARNING: EXISTING FILES DETECTED');
    console.log('═══════════════════════════════════════════════════════════════\n');

    if (existingPages.length > 0) console.log(`   📄 ${existingPages.length} page file(s) already exist`);
    if (existingSteps.length > 0) console.log(`   📝 ${existingSteps.length} step file(s) already exist`);
    if (existingSpecs.length > 0) console.log(`   🧪 ${existingSpecs.length} spec file(s) already exist`);

    console.log('\n   Running migrate.js will OVERWRITE these files!');
    console.log('\n   Options:');
    console.log('     1. Use @pw-orchestrator resume  - Continue from where you left off');
    console.log('     2. npm run migrate:force        - Force overwrite (DANGEROUS)');
    console.log('\n═══════════════════════════════════════════════════════════════\n');

    return true;
  }
  return false;
}

// ═══════════════════════════════════════════════════════════════
// CLI
// ═══════════════════════════════════════════════════════════════

const cmd = process.argv[2];
if (cmd === 'status') showStatus();
else if (cmd === 'help') showHelp();
else if (cmd === 'force') {
  console.log('\n⚠️  FORCE MODE: Overwriting existing files...\n');
  runMigration();
} else {
  if (checkExistingFiles()) {
    console.log('Migration aborted. Use --force to overwrite or resume to continue.\n');
    process.exit(1);
  } else {
    runMigration();
  }
}

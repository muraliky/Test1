Automation Audit Tool
=====================

ORGANISER SETUP (once per quarter):
  1. Edit automation-audit/config/output.config.js
     Set AUDIT_OUTPUT_PATH to your shared drive UNC path

  2. Install Node.js dependencies (one-time):
     cd automation-audit
     npm install

  3. Build the WinForms launcher (.NET 9 SDK required):
     cd Launcher
     dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
     Output: Launcher\bin\Release\net9.0-windows\win-x64\publish\AuditLauncher.exe

  4. Place AuditLauncher.exe next to the automation-audit\ folder

  5. Distribute AuditTool\ to project teams

RUNNING AN AUDIT (users):
  Double-click AuditLauncher.exe, fill in 4 fields, click Run Audit.
  The Excel report + _findings.json are saved to the shared drive automatically.
  Node.js must be installed on the user's machine.

REFRESHING THE DASHBOARD (organiser, after each audit cycle):
  cd automation-audit
  node build-dashboard.js

  This reads all *_findings.json from the shared drive and generates
  AuditDashboard.html in the same folder. Open it in any browser — 
  no server, no login, no dependencies needed.

FILES:
  automation-audit/
    audit.js                  Main CLI (called by launcher)
    build-dashboard.js        Builds the HTML dashboard from JSON files
    dashboard-template.html   Dashboard HTML template (do not edit)
    config/output.config.js   EDIT THIS — shared drive path
    config/rules.json         Audit checkpoint definitions
    analyzers/                Audit logic per category
    reporters/                Excel report generator
  Launcher/
    *.cs / *.csproj           WinForms source code

#!/usr/bin/env node
/**
 * Chain of Verification (CoVe) - STRICT Migration Validation
 *
 * Verifies every category of generated output: pages, steps, utils,
 * config, types, and playwright-bdd step coverage (features/*.feature
 * vs the Given/When/Then(...) definitions in src/steps/).
 *
 * Step files use playwright-bdd's Given/When/Then(...) calls (imported
 * from src/fixtures/test-fixtures.ts), matched against .feature step text
 * using the same Cucumber-expression syntax ({string}, {int}, etc.) as the
 * original Java step definitions. The checks below confirm every Gherkin
 * step in features/ has a matching definition, and flag any leftover
 * unconverted Java/Selenium syntax as an error.
 *
 * USAGE:
 *   npm run verify              - Run full CoVe across every category
 *   npm run verify:file <path>  - Verify a single file
 */

const fs = require('fs');
const path = require('path');
let yaml = null;
try {
  yaml = require('js-yaml');
} catch (e) {
  // js-yaml not installed yet (e.g. verify run before `npm install`) — yaml
  // page count checks below degrade gracefully to the info-only branch.
}

// ═══════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════

const CONFIG = {
  pagesOut: './src/pages',
  stepsOut: './src/steps',
  utilsOut: './src/utils',
  configOut: './src/config',
  typesOut: './src/types',
  legacyOut: './src/legacy',
  featuresOut: './features',
  reportFile: './cove-report.json',
  pendingFile: './pending-methods.json',
  manifestFile: './migration-manifest.json',
  sourceDir: './_source-java',
};

// ═══════════════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════

function getAllFiles(dir, suffix) {
  let results = [];
  if (!fs.existsSync(dir)) return results;

  const items = fs.readdirSync(dir);
  for (const item of items) {
    const fullPath = path.join(dir, item);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      results = results.concat(getAllFiles(fullPath, suffix));
    } else if (item.endsWith(suffix)) {
      results.push(fullPath);
    }
  }
  return results;
}

function loadJsonSafe(filePath) {
  if (!fs.existsSync(filePath)) return null;
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch (e) {
    return null;
  }
}

function findPendingKey(map, fileName, stripSuffix) {
  return Object.keys(map || {}).find(
    (k) =>
      k.toLowerCase().includes(fileName.toLowerCase()) ||
      fileName.toLowerCase().includes(k.replace(stripSuffix, '').toLowerCase())
  );
}

// ═══════════════════════════════════════════════════════════════
// NO JAVA / NO SELENIUM / NO PLAYWRIGHT-BDD SYNTAX CHECK
// (applies to every generated TypeScript category)
// ═══════════════════════════════════════════════════════════════

function checkNoJavaSyntax(content) {
  const issues = [];

  const javaPatterns = [
    { pattern: /\bpublic\s+void\b/, msg: 'Java: public void' },
    { pattern: /\bprivate\s+void\b/, msg: 'Java: private void' },
    { pattern: /\bpublic\s+static\b/, msg: 'Java: public static' },
    { pattern: /\bprivate\s+static\b/, msg: 'Java: private static' },

    { pattern: /\bWebElement\b/, msg: 'Selenium: WebElement' },
    { pattern: /\bWebDriver\b/, msg: 'Selenium: WebDriver' },
    { pattern: /@FindBy/, msg: 'Selenium: @FindBy annotation' },
    { pattern: /\bBy\.xpath\s*\(/, msg: 'Selenium: By.xpath()' },
    { pattern: /\bBy\.id\s*\(/, msg: 'Selenium: By.id()' },
    { pattern: /\bBy\.name\s*\(/, msg: 'Selenium: By.name()' },
    { pattern: /\bBy\.className\s*\(/, msg: 'Selenium: By.className()' },
    { pattern: /\bBy\.cssSelector\s*\(/, msg: 'Selenium: By.cssSelector()' },
    { pattern: /\bBy\.linkText\s*\(/, msg: 'Selenium: By.linkText()' },
    { pattern: /\bBy\.tagName\s*\(/, msg: 'Selenium: By.tagName()' },

    { pattern: /\.sendKeys\s*\(/, msg: 'Selenium: .sendKeys() → use .fill()' },
    { pattern: /\.getText\s*\(\)/, msg: 'Selenium: .getText() → use .textContent()' },
    { pattern: /\.isDisplayed\s*\(\)/, msg: 'Selenium: .isDisplayed() → use .isVisible()' },
    { pattern: /\.findElement\s*\(/, msg: 'Selenium: .findElement()' },
    { pattern: /\.findElements\s*\(/, msg: 'Selenium: .findElements()' },

    { pattern: /\bdriver\.get\s*\(/, msg: 'Java: driver.get() → use page.goto()' },
    { pattern: /\bdriver\.navigate\s*\(/, msg: 'Java: driver.navigate()' },
    { pattern: /\bdriver\.findElement/, msg: 'Java: driver.findElement' },
    { pattern: /\bdriver\.getCurrentUrl/, msg: 'Java: driver.getCurrentUrl → use page.url()' },
    { pattern: /\bdriver\.getTitle/, msg: 'Java: driver.getTitle → use page.title()' },

    { pattern: /Thread\.sleep/, msg: 'Java: Thread.sleep → use page.waitForTimeout()' },
    { pattern: /\bWebDriverWait\b/, msg: 'Java: WebDriverWait' },
    { pattern: /\bExpectedConditions\b/, msg: 'Java: ExpectedConditions' },

    // Leftover Java/Cucumber annotation syntax (not the TS Given/When/Then() calls,
    // which are the correct playwright-bdd output — this only flags the Java @-form).
    { pattern: /@Given\s*\(/, msg: 'Java: @Given annotation (leftover, not converted to a Given(...) call)' },
    { pattern: /@When\s*\(/, msg: 'Java: @When annotation (leftover, not converted to a When(...) call)' },
    { pattern: /@Then\s*\(/, msg: 'Java: @Then annotation (leftover, not converted to a Then(...) call)' },
    { pattern: /@And\s*\(/, msg: 'Java: @And annotation' },
    { pattern: /@But\s*\(/, msg: 'Java: @But annotation' },

    { pattern: /\bString\s+\w+\s*=/, msg: 'Java: String declaration → use const/let' },
    { pattern: /\bint\s+\w+\s*=/, msg: 'Java: int declaration → use let/const' },
    { pattern: /\bboolean\s+\w+\s*=/, msg: 'Java: boolean declaration → use let/const' },
    { pattern: /\bList</, msg: 'Java: List<> → use array []' },
    { pattern: /\bMap</, msg: 'Java: Map<> → use object {}' },

    { pattern: /\.size\s*\(\)/, msg: 'Java: .size() → use .length' },
    { pattern: /\.equals\s*\(/, msg: 'Java: .equals() → use ===' },
    { pattern: /\.contains\s*\(/, msg: 'Java: .contains() → use .includes()' },
    { pattern: /\.isEmpty\s*\(\)/, msg: 'Java: .isEmpty() → use .length === 0' },

    { pattern: /\bAssert\.\w+/, msg: 'Java: Assert.* → use expect()' },
    { pattern: /\bassertTrue\s*\(/, msg: 'Java: assertTrue → use expect().toBeTruthy()' },
    { pattern: /\bassertEquals\s*\(/, msg: 'Java: assertEquals → use expect().toBe()' },
  ];

  for (const jp of javaPatterns) {
    if (jp.pattern.test(content)) {
      const lines = content.split('\n');
      let lineNum = 0;
      for (let i = 0; i < lines.length; i++) {
        const trimmed = lines[i].trim();
        if (jp.pattern.test(lines[i]) && !trimmed.startsWith('//') && !trimmed.startsWith('*')) {
          lineNum = i + 1;
          break;
        }
      }
      // Skip matches that only occur inside "Original Java:" comment blocks / @source headers
      if (lineNum > 0) {
        issues.push({ severity: 'error', message: jp.msg, line: lineNum });
      }
    }
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// PAGE CHECKS
// ═══════════════════════════════════════════════════════════════

function checkPageStructure(content) {
  const issues = [];

  if (!/export\s+class\s+\w+/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: export class' });
  }
  if (!/import.*{[^}]*Page[^}]*}.*from\s*['"]@playwright\/test['"]/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: Page import from @playwright/test' });
  }
  if (!/constructor\s*\([^)]*page\s*:\s*Page/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: constructor(page: Page)' });
  }
  if (!/readonly\s+page\s*:\s*Page/.test(content)) {
    issues.push({ severity: 'error', message: 'Missing: page property' });
  }
  if (!/Locator/.test(content) && /readonly\s+\w+/.test(content)) {
    issues.push({ severity: 'warning', message: 'Locators should be typed as Locator' });
  }

  return issues;
}

function checkPageCountMatch(tsFilePath, tsContent) {
  const issues = [];
  const fileName = path.basename(tsFilePath, '.page.ts');

  let expectedMethods = 0;
  const pending = loadJsonSafe(CONFIG.pendingFile);
  if (pending) {
    const pageKey = findPendingKey(pending.pages, fileName, '.page.ts');
    if (pageKey) expectedMethods = pending.pages[pageKey].length;
  }

  const tsLocators = (tsContent.match(/readonly\s+\w+\s*:\s*Locator/g) || []).length;
  const tsMethods = (tsContent.match(/async\s+\w+\s*\([^)]*\)\s*:\s*Promise/g) || []).length;

  let expectedLocators = 0;
  const sourceMatch = tsContent.match(/@source\s+([^\n\r]+)/);
  if (sourceMatch) {
    const srcPath = sourceMatch[1].trim();
    if (fs.existsSync(srcPath) && /\.(ya?ml)$/i.test(srcPath)) {
      // Yaml-derived page object — every top-level yaml key became one
      // locator property, so the key count is the expected locator count.
      if (yaml) {
        try {
          const obj = yaml.load(fs.readFileSync(srcPath, 'utf-8'));
          if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
            expectedLocators = Object.keys(obj).length;
          }
        } catch (e) {
          // Unparseable yaml — leave expectedLocators at 0 (info-only branch below).
        }
      }
    } else if (fs.existsSync(srcPath)) {
      const javaContent = fs.readFileSync(srcPath, 'utf-8');
      // Every locator is declared exactly once as a WebElement field, whether or not it
      // carries an @FindBy annotation — count the field declarations themselves as the
      // single source of truth (avoids double-counting an @FindBy line + its field line).
      const javaLocators = (javaContent.match(/(?:private|public)\s+WebElement\s+\w+\s*;/g) || []).length;
      const javaClass = javaContent.match(/class\s+(\w+)/)?.[1] || '';
      // Count public methods, excluding only the constructor (same name as the class).
      // Earlier versions also excluded any method containing "get"/"set", which wrongly
      // dropped legitimate Page Object methods like getErrorMessage() — a real action
      // method, not a POJO accessor. Constructor exclusion alone is correct here.
      const javaMethods = (javaContent.match(/public\s+\w+\s+(\w+)\s*\(/g) || [])
        .filter((m) => !new RegExp(`\\b${javaClass}\\s*\\(`).test(m)).length;
      if (javaLocators > 0) expectedLocators = javaLocators;
      if (javaMethods > 0) expectedMethods = javaMethods;
    }
  }

  // A yaml-derived page may have had a same-named Java page class's methods
  // merged in separately (see @source-methods, written by migrate.js's
  // mergeMethodsIntoYamlPage). Count expected methods from that Java file —
  // independent of whether @source pointed at yaml or java above.
  const methodsSourceMatch = tsContent.match(/@source-methods\s+([^\n\r]+)/);
  if (methodsSourceMatch) {
    const javaPath = methodsSourceMatch[1].trim();
    if (fs.existsSync(javaPath)) {
      const javaContent = fs.readFileSync(javaPath, 'utf-8');
      const javaClass = javaContent.match(/class\s+(\w+)/)?.[1] || '';
      const javaMethods = (javaContent.match(/public\s+\w+\s+(\w+)\s*\(/g) || [])
        .filter((m) => !new RegExp(`\\b${javaClass}\\s*\\(`).test(m)).length;
      if (javaMethods > 0) expectedMethods = javaMethods;
    }
  }

  if (expectedLocators > 0 && tsLocators !== expectedLocators) {
    const diff = expectedLocators - tsLocators;
    issues.push(
      diff > 0
        ? { severity: 'error', message: `Locators: Expected ${expectedLocators}, Found ${tsLocators} (${diff} MISSING)` }
        : { severity: 'warning', message: `Locators: Expected ${expectedLocators}, Found ${tsLocators} (${Math.abs(diff)} extra)` }
    );
  }

  if (expectedMethods > 0 && tsMethods !== expectedMethods) {
    const diff = expectedMethods - tsMethods;
    issues.push(
      diff > 0
        ? { severity: 'error', message: `Methods: Expected ${expectedMethods}, Found ${tsMethods} (${diff} MISSING)` }
        : { severity: 'warning', message: `Methods: Expected ${expectedMethods}, Found ${tsMethods} (${Math.abs(diff)} extra)` }
    );
  }

  if (expectedLocators === 0 && expectedMethods === 0) {
    issues.push({ severity: 'info', message: `Found: ${tsLocators} locator(s), ${tsMethods} method(s)` });
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// STEP CHECKS (playwright-bdd Given/When/Then(...) step definitions)
// ═══════════════════════════════════════════════════════════════

function countStepFunctions(content) {
  // Count playwright-bdd Given/When/Then('text', async (...) => {...}) step
  // definitions. Steps that still throw "not implemented" still count —
  // they exist and are wired up, they just need real logic.
  const stepCallRegex = /^\s*(Given|When|Then)\s*\(\s*['"`]/gm;
  const matches = content.match(stepCallRegex) || [];
  return { stepCount: matches.length };
}

function checkStepStructure(content) {
  const issues = [];

  if (!/import\s*\{[^}]*\b(Given|When|Then)\b[^}]*\}\s*from\s*['"][^'"]*fixtures[^'"]*['"]/.test(content)) {
    issues.push({
      severity: 'error',
      message: "Missing: Given/When/Then import from fixtures (expected: import { Given, When, Then } from '.../fixtures/test-fixtures')",
    });
  }

  const { stepCount } = countStepFunctions(content);
  if (stepCount === 0) {
    issues.push({ severity: 'error', message: 'No Given/When/Then(...) step definitions found' });
  }

  // Each step's handler should destructure at least { page } from its first arg.
  const handlersWithoutPage = (content.match(/(?:Given|When|Then)\s*\(\s*['"`][^'"`]*['"`]\s*,\s*async\s*\(\s*\{(?![^}]*\bpage\b)[^}]*\}/g) || []).length;
  if (handlersWithoutPage > 0) {
    issues.push({ severity: 'warning', message: `${handlersWithoutPage} step handler(s) don't destructure { page } from their fixtures argument` });
  }

  return issues;
}

function checkStepCountMatch(tsFilePath, tsContent) {
  const issues = [];
  const fileName = path.basename(tsFilePath, '.steps.ts');

  let expectedSteps = 0;
  const pending = loadJsonSafe(CONFIG.pendingFile);
  if (pending) {
    const stepKey = findPendingKey(pending.steps, fileName, '.steps.ts');
    if (stepKey) expectedSteps = pending.steps[stepKey].length;
  }

  const { stepCount: tsSteps } = countStepFunctions(tsContent);

  const sourceMatch = tsContent.match(/@source\s+([^\n\r]+)/);
  let javaHooks = 0;
  if (sourceMatch) {
    const javaPath = sourceMatch[1].trim();
    if (fs.existsSync(javaPath)) {
      const javaContent = fs.readFileSync(javaPath, 'utf-8');
      const javaSteps = (javaContent.match(/@(Given|When|Then|And|But)\s*\(/g) || []).length;
      javaHooks = (javaContent.match(/@(Before|After)\b/g) || []).length;
      if (javaSteps > 0) expectedSteps = javaSteps;
    }
  }

  if (expectedSteps > 0 && tsSteps !== expectedSteps) {
    const diff = expectedSteps - tsSteps;
    issues.push(
      diff > 0
        ? { severity: 'error', message: `Steps: Expected ${expectedSteps}, Found ${tsSteps} (${diff} MISSING)` }
        : { severity: 'warning', message: `Steps: Expected ${expectedSteps}, Found ${tsSteps} (${Math.abs(diff)} extra)` }
    );
  } else if (expectedSteps === 0) {
    issues.push({ severity: 'info', message: `Found: ${tsSteps} step definition(s)` });
  }

  if (javaHooks > 0) {
    const tsHookComments = (tsContent.match(/Originally a Cucumber @(Before|After) hook/g) || []).length;
    if (tsHookComments < javaHooks) {
      issues.push({
        severity: 'warning',
        message: `Hooks: Expected ${javaHooks} (@Before/@After) noted, found ${tsHookComments} — wire remaining hooks into src/fixtures/test-fixtures.ts (fixture setup/teardown)`,
      });
    } else {
      issues.push({ severity: 'info', message: `Hooks: ${tsHookComments} noted for manual wiring into fixtures (not auto-implemented)` });
    }
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// UTIL CHECKS
// ═══════════════════════════════════════════════════════════════


function checkUtilStructure(content) {
  const issues = [];
  if (!/export\s+(async\s+)?function\s+\w+/.test(content)) {
    issues.push({ severity: 'error', message: 'No exported utility function(s) found' });
  }
  return issues;
}

function checkUtilCountMatch(tsFilePath, tsContent) {
  const issues = [];
  const fileName = path.basename(tsFilePath, '.utils.ts');

  let expected = 0;
  const pending = loadJsonSafe(CONFIG.pendingFile);
  if (pending) {
    const key = findPendingKey(pending.utils, fileName, '.utils.ts');
    if (key) expected = pending.utils[key].length;
  }

  const found = (tsContent.match(/export\s+(async\s+)?function\s+\w+\s*\(/g) || []).length;

  if (expected > 0 && found !== expected) {
    const diff = expected - found;
    issues.push(
      diff > 0
        ? { severity: 'error', message: `Functions: Expected ${expected}, Found ${found} (${diff} MISSING)` }
        : { severity: 'warning', message: `Functions: Expected ${expected}, Found ${found} (${Math.abs(diff)} extra)` }
    );
  } else if (expected === 0) {
    issues.push({ severity: 'info', message: `Found: ${found} function(s)` });
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// CONFIG / TYPES CHECKS (auto-converted — should have zero TODOs)
// ═══════════════════════════════════════════════════════════════

function checkConfigStructure(content) {
  const issues = [];
  if (!/export\s+const\s+\w+/.test(content)) {
    issues.push({ severity: 'error', message: 'No exported const declarations found' });
  }
  if (/throw\s+new\s+Error\s*\(\s*['"`].*not\s+implemented/i.test(content)) {
    issues.push({ severity: 'error', message: 'Config files are auto-converted and should never contain a "not implemented" placeholder' });
  }
  return issues;
}

function checkTypeStructure(content) {
  const issues = [];
  if (!/export\s+interface\s+\w+/.test(content)) {
    issues.push({ severity: 'error', message: 'No exported interface found' });
  }
  if (/throw\s+new\s+Error\s*\(\s*['"`].*not\s+implemented/i.test(content)) {
    issues.push({ severity: 'error', message: 'Type files are auto-converted and should never contain a "not implemented" placeholder' });
  }
  return issues;
}

// ═══════════════════════════════════════════════════════════════
// FEATURE STEP COVERAGE (features/*.feature vs src/steps Given/When/Then)
// ═══════════════════════════════════════════════════════════════

/**
 * Convert a Gherkin/Cucumber expression step text into a matching RegExp.
 * Supports {string}, {int}, {float}, {word} and the anonymous {}.
 */
function stepTextToRegex(stepText) {
  let escaped = stepText.replace(/[.*+?^${}()|[\]\\]/g, (c) => '\\' + c);
  escaped = escaped
    .replace(/\\\{string\\\}/g, '"([^"]*)"')
    .replace(/\\\{int\\\}/g, '(-?\\d+)')
    .replace(/\\\{float\\\}/g, '(-?\\d+\\.\\d+)')
    .replace(/\\\{word\\\}/g, '(\\S+)')
    .replace(/\\\{\\\}/g, '(.+)');
  return new RegExp('^' + escaped + '$', 'i');
}

function collectStepDefinitions() {
  const stepFiles = getAllFiles(CONFIG.stepsOut, '.steps.ts');
  const defs = [];
  for (const file of stepFiles) {
    const content = fs.readFileSync(file, 'utf-8');
    const re = /\b(?:Given|When|Then)\s*\(\s*(['"`])((?:(?!\1).)*)\1/g;
    let m;
    while ((m = re.exec(content))) {
      defs.push({ text: m[2], pattern: stepTextToRegex(m[2]), file: toPosixPath(file) });
    }
  }
  return defs;
}

function toPosixPath(p) {
  return p.split(path.sep).join('/');
}

function checkFeatureStepCoverage() {
  const issues = [];
  const featureFiles = getAllFiles(CONFIG.featuresOut, '.feature');
  if (featureFiles.length === 0) {
    return { ran: false, issues };
  }

  const defs = collectStepDefinitions();
  let totalSteps = 0;
  const unmatched = [];

  for (const ff of featureFiles) {
    const content = fs.readFileSync(ff, 'utf-8');
    for (const raw of content.split('\n')) {
      const line = raw.trim();
      const m = line.match(/^(Given|When|Then|And|But)\s+(.+?)\s*$/);
      if (!m) continue;
      const text = m[2];
      totalSteps++;
      const matched = defs.some((d) => d.pattern.test(text));
      if (!matched) {
        unmatched.push(`${path.basename(ff)}: "${m[1]} ${text}"`);
      }
    }
  }

  if (defs.length === 0) {
    issues.push({ severity: 'error', message: 'No Given/When/Then(...) step definitions found in src/steps/ to check feature files against' });
  }

  if (unmatched.length > 0) {
    issues.push({
      severity: 'error',
      message: `${unmatched.length} of ${totalSteps} Gherkin step line(s) across ${featureFiles.length} feature file(s) have no matching Given/When/Then(...) definition`,
    });
    for (const u of unmatched.slice(0, 15)) {
      issues.push({ severity: 'error', message: `  Unmatched: ${u}` });
    }
    if (unmatched.length > 15) {
      issues.push({ severity: 'info', message: `  ...and ${unmatched.length - 15} more` });
    }
  } else if (totalSteps > 0) {
    issues.push({
      severity: 'info',
      message: `All ${totalSteps} Gherkin step line(s) across ${featureFiles.length} feature file(s) match a step definition`,
    });
  }

  return { ran: true, issues };
}

// ═══════════════════════════════════════════════════════════════
// IMPLEMENTATION / TODO CHECK (page, step, util)
// ═══════════════════════════════════════════════════════════════

function checkImplementation(content) {
  const issues = [];

  const todoMatches = content.match(/throw\s+new\s+Error\s*\(\s*['"`](Method|Step|Hook|Function).*not\s+implemented/g) || [];
  if (todoMatches.length > 0) {
    issues.push({ severity: 'error', message: `${todoMatches.length} method(s)/step(s)/function(s) NOT implemented` });
  }

  const todoComments = content.match(/\/\/\s*TODO:/gi) || [];
  if (todoComments.length > 0) {
    issues.push({ severity: 'warning', message: `${todoComments.length} TODO comment(s) remaining` });
  }

  const originalJava = content.match(/\/\/\s*Original\s*Java:/gi) || [];
  if (originalJava.length > 0) {
    issues.push({ severity: 'warning', message: `${originalJava.length} "Original Java" comment(s) not cleaned up` });
  }

  const lines = content.split('\n');
  const playwrightMethods = [
    'click(', 'fill(', 'clear(', 'hover(', 'focus(',
    'press(', 'selectOption(', 'check(', 'uncheck(',
    'waitFor(', 'goto(', 'reload(', 'goBack(', 'goForward(',
    'textContent(', 'innerText(', 'getAttribute(',
    'isVisible(', 'isEnabled(', 'isChecked(',
    'scrollIntoViewIfNeeded(', 'dblclick(', 'type(',
    'screenshot(', 'evaluate(', 'waitForSelector(',
    'waitForTimeout(', 'waitForLoadState(', 'waitForURL(',
  ];

  const missingAwaits = [];
  lines.forEach((line, idx) => {
    const trimmed = line.trim();
    if (trimmed.startsWith('//') || trimmed.startsWith('*') || trimmed.startsWith('/*')) return;
    for (const method of playwrightMethods) {
      if (line.includes('.' + method) && !line.includes('await ') && !line.includes('await(') && !line.includes('return await')) {
        missingAwaits.push({ line: idx + 1, method });
      }
    }
  });

  if (missingAwaits.length > 0) {
    issues.push({
      severity: 'error',
      message: `${missingAwaits.length} missing await(s): lines ${missingAwaits.slice(0, 3).map((m) => m.line).join(', ')}${missingAwaits.length > 3 ? '...' : ''}`,
    });
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// BOILERPLATE/PLACEHOLDER DETECTION (page, step, util)
// ═══════════════════════════════════════════════════════════════

function extractBodies(content, category) {
  const bodies = [];

  if (category === 'page') {
    const methodRegex = /async\s+(\w+)\s*\([^)]*\)\s*(?::\s*Promise<[^>]+>)?\s*\{([\s\S]*?)\n\s{2}\}/g;
    let match;
    while ((match = methodRegex.exec(content))) {
      bodies.push({ name: match[1], body: match[2].trim() });
    }
  } else {
    // step / util files: top-level exported functions
    const fnRegex = /export\s+(?:async\s+)?function\s+(\w+)\s*\([^)]*\)[^{]*\{([\s\S]*?)\n\}/g;
    let match;
    while ((match = fnRegex.exec(content))) {
      bodies.push({ name: match[1], body: match[2].trim() });
    }
  }

  return bodies;
}

function isBoilerplateOnly(body) {
  if (!body || body.length === 0) return true;

  const withoutComments = body.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').trim();
  if (!withoutComments) return true;

  const boilerplatePatterns = [
    /^await\s+page\.waitForLoadState\s*\(\s*['"`]\w+['"`]\s*\)\s*;?$/,
    /^await\s+page\.waitForTimeout\s*\(\s*\d+\s*\)\s*;?$/,
    /^await\s+page\.waitForSelector\s*\([^)]+\)\s*;?$/,
    /^await\s+page\.waitForNavigation\s*\([^)]*\)\s*;?$/,
    /^await\s+page\.waitForURL\s*\([^)]+\)\s*;?$/,
    /^console\.log\s*\([^)]*\)\s*;?$/,
    /^await\s+Promise\.resolve\s*\(\s*\)\s*;?$/,
    /^return\s*;?$/,
    /^\/\/.*$/,
    /^\s*$/,
  ];

  const statements = withoutComments.split(/;|\n/).map((s) => s.trim()).filter((s) => s.length > 0);
  if (statements.length === 0) return true;

  return statements.every((stmt) => boilerplatePatterns.some((pattern) => pattern.test(stmt)));
}

function checkBoilerplate(content, category) {
  const issues = [];
  const bodies = extractBodies(content, category);

  let boilerplateOnlyCount = 0;
  const boilerplateNames = [];
  for (const item of bodies) {
    if (isBoilerplateOnly(item.body)) {
      boilerplateOnlyCount++;
      boilerplateNames.push(item.name);
    }
  }
  if (boilerplateOnlyCount > 0) {
    const examples = boilerplateNames.slice(0, 3).join(', ');
    issues.push({
      severity: 'error',
      message: `${boilerplateOnlyCount} method(s)/function(s) have ONLY boilerplate code: ${examples}${boilerplateNames.length > 3 ? '...' : ''}`,
    });
  }

  let emptyCount = 0;
  for (const item of bodies) {
    const cleaned = item.body.replace(/\/\/.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').trim();
    if (!cleaned || cleaned === '{}') emptyCount++;
  }
  if (emptyCount > 0) {
    issues.push({ severity: 'error', message: `${emptyCount} empty method(s)/function(s) — no implementation` });
  }

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// SYNTAX CHECK (all categories)
// ═══════════════════════════════════════════════════════════════

function checkSyntax(content) {
  const issues = [];

  const openBraces = (content.match(/\{/g) || []).length;
  const closeBraces = (content.match(/\}/g) || []).length;
  if (openBraces !== closeBraces) {
    issues.push({ severity: 'error', message: `Unbalanced braces: {=${openBraces}, }=${closeBraces}` });
  }

  const openParens = (content.match(/\(/g) || []).length;
  const closeParens = (content.match(/\)/g) || []).length;
  if (openParens !== closeParens) {
    issues.push({ severity: 'error', message: `Unbalanced parentheses: (=${openParens}, )=${closeParens}` });
  }

  if (/async\s+async/.test(content)) issues.push({ severity: 'error', message: 'Double async keyword' });
  if (/await\s+await/.test(content)) issues.push({ severity: 'error', message: 'Double await keyword' });

  return issues;
}

// ═══════════════════════════════════════════════════════════════
// LEGACY (unclassified) FILES — informational only
// ═══════════════════════════════════════════════════════════════

function checkLegacyFile() {
  return [{
    severity: 'warning',
    message: 'Unclassified source file — could not be auto-categorized as page/step/util/config/type. Original Java kept in a comment; needs manual review (see migration-manifest.json → needsManualReview).',
  }];
}

// ═══════════════════════════════════════════════════════════════
// MANIFEST COVERAGE CHECK — ensures nothing was silently skipped
// ═══════════════════════════════════════════════════════════════

function checkManifestCoverage() {
  const manifest = loadJsonSafe(CONFIG.manifestFile);
  if (!manifest) {
    return { ran: false, issues: [{ severity: 'warning', message: 'migration-manifest.json not found — run `node scripts/migrate.js` first' }] };
  }

  const issues = [];
  for (const f of manifest.files || []) {
    if (f.category === 'infra') continue; // infra is intentionally documentation-only, no output file
    if (f.output && !fs.existsSync(f.output)) {
      issues.push({ severity: 'error', message: `${f.source} (${f.category}) → expected output ${f.output} but it is MISSING on disk` });
    }
  }

  if (manifest.needsManualReview && manifest.needsManualReview.length > 0) {
    issues.push({
      severity: 'warning',
      message: `${manifest.needsManualReview.length} source file(s) need manual review: ${manifest.needsManualReview.join(', ')}`,
    });
  }

  if (issues.length === 0) {
    issues.push({ severity: 'info', message: `All ${manifest.files?.length || 0} scanned source file(s) accounted for — nothing silently dropped` });
  }

  return { ran: true, issues };
}

// ═══════════════════════════════════════════════════════════════
// CATEGORY DETECTION
// ═══════════════════════════════════════════════════════════════

function detectCategory(filePath) {
  if (filePath.includes('.page.ts')) return 'page';
  if (filePath.includes('.steps.ts')) return 'step';
  if (filePath.includes('.utils.ts')) return 'util';
  if (filePath.includes('.config.ts')) return 'config';
  if (filePath.includes('.types.ts')) return 'type';
  if (filePath.includes('.legacy.ts')) return 'legacy';
  return 'unknown';
}

const CATEGORY_LABELS = {
  page: '📄 PAGES',
  step: '📝 STEPS',
  util: '🔧 UTILS',
  config: '⚙️  CONFIG',
  type: '🧩 TYPES',
  legacy: '❓ LEGACY (needs manual review)',
};

// ═══════════════════════════════════════════════════════════════
// VERIFY SINGLE FILE
// ═══════════════════════════════════════════════════════════════

function verifyFile(filePath, silent = false) {
  const fileName = path.basename(filePath);

  if (!fs.existsSync(filePath)) {
    if (!silent) console.log(`   ❌ ${fileName} - File not found`);
    return { passed: false, file: fileName, error: 'File not found', checks: [] };
  }

  const content = fs.readFileSync(filePath, 'utf-8');
  const category = detectCategory(filePath);

  if (!silent) console.log(`\n   📄 ${fileName}`);

  const checks = [];

  if (category === 'legacy') {
    checks.push({ name: 'Manual Review Needed', passed: false, issues: checkLegacyFile() });
  } else {
    const javaSyntaxIssues = checkNoJavaSyntax(content);
    checks.push({ name: 'No Java/BDD Syntax', passed: !javaSyntaxIssues.some((i) => i.severity === 'error'), issues: javaSyntaxIssues });

    if (category === 'page') {
      const structureIssues = checkPageStructure(content);
      checks.push({ name: 'Page Structure', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
      const countIssues = checkPageCountMatch(filePath, content);
      checks.push({ name: 'Count Match', passed: !countIssues.some((i) => i.severity === 'error'), issues: countIssues });
    } else if (category === 'step') {
      const structureIssues = checkStepStructure(content);
      checks.push({ name: 'Step Structure (Given/When/Then)', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
      const countIssues = checkStepCountMatch(filePath, content);
      checks.push({ name: 'Count Match', passed: !countIssues.some((i) => i.severity === 'error'), issues: countIssues });
    } else if (category === 'util') {
      const structureIssues = checkUtilStructure(content);
      checks.push({ name: 'Util Structure', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
      const countIssues = checkUtilCountMatch(filePath, content);
      checks.push({ name: 'Count Match', passed: !countIssues.some((i) => i.severity === 'error'), issues: countIssues });
    } else if (category === 'config') {
      const structureIssues = checkConfigStructure(content);
      checks.push({ name: 'Config Structure', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
    } else if (category === 'type') {
      const structureIssues = checkTypeStructure(content);
      checks.push({ name: 'Type Structure', passed: !structureIssues.some((i) => i.severity === 'error'), issues: structureIssues });
    }

    if (['page', 'step', 'util'].includes(category)) {
      const implIssues = checkImplementation(content);
      checks.push({ name: 'Implementation', passed: !implIssues.some((i) => i.severity === 'error'), issues: implIssues });
      const boilerplateIssues = checkBoilerplate(content, category);
      checks.push({ name: 'No Boilerplate', passed: !boilerplateIssues.some((i) => i.severity === 'error'), issues: boilerplateIssues });
    }

    const syntaxIssues = checkSyntax(content);
    checks.push({ name: 'Syntax', passed: !syntaxIssues.some((i) => i.severity === 'error'), issues: syntaxIssues });
  }

  if (!silent) {
    for (const check of checks) {
      const icon = check.passed ? '✓' : '✗';
      console.log(`      ├─ ${check.name}: ${icon}`);
      for (const issue of check.issues.filter((i) => i.severity === 'error')) {
        console.log(`      │  └─ ❌ ${issue.message}${issue.line ? ` (line ${issue.line})` : ''}`);
      }
      for (const issue of check.issues.filter((i) => i.severity === 'warning')) {
        console.log(`      │  └─ ⚠️  ${issue.message}`);
      }
      for (const issue of check.issues.filter((i) => i.severity === 'info')) {
        console.log(`      │  └─ ℹ️  ${issue.message}`);
      }
    }
  }

  const hasError = checks.some((c) => !c.passed);
  const warningCount = checks.reduce((sum, c) => sum + c.issues.filter((i) => i.severity === 'warning').length, 0);
  const errorCount = checks.reduce((sum, c) => sum + c.issues.filter((i) => i.severity === 'error').length, 0);

  if (!silent) {
    if (!hasError && warningCount === 0) console.log('      └─ ✅ PASSED');
    else if (!hasError) console.log(`      └─ ⚠️  PASSED (${warningCount} warning${warningCount > 1 ? 's' : ''})`);
    else console.log(`      └─ ❌ FAILED (${errorCount} error${errorCount > 1 ? 's' : ''})`);
  }

  return { passed: !hasError, file: fileName, category, checks, errorCount, warningCount };
}

// ═══════════════════════════════════════════════════════════════
// VERIFY ALL FILES
// ═══════════════════════════════════════════════════════════════

function verifyAll() {
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('   CoVe - STRICT Chain of Verification (playwright-bdd architecture)');
  console.log('═══════════════════════════════════════════════════════════════');

  const groups = [
    { category: 'page', dir: CONFIG.pagesOut, suffix: '.page.ts' },
    { category: 'step', dir: CONFIG.stepsOut, suffix: '.steps.ts' },
    { category: 'util', dir: CONFIG.utilsOut, suffix: '.utils.ts' },
    { category: 'config', dir: CONFIG.configOut, suffix: '.config.ts' },
    { category: 'type', dir: CONFIG.typesOut, suffix: '.types.ts' },
    { category: 'legacy', dir: CONFIG.legacyOut, suffix: '.legacy.ts' },
  ];

  const results = { byCategory: {}, files: [] };

  for (const group of groups) {
    console.log(`\n${CATEGORY_LABELS[group.category]}:`);
    const files = getAllFiles(group.dir, group.suffix);
    const stats = { total: 0, passed: 0, failed: 0, errors: 0, warnings: 0 };

    if (files.length === 0) {
      console.log('   (none found)');
    } else {
      for (const file of files) {
        const result = verifyFile(file);
        results.files.push(result);
        stats.total++;
        if (result.passed) stats.passed++;
        else stats.failed++;
        stats.errors += result.errorCount || 0;
        stats.warnings += result.warningCount || 0;
      }
    }
    results.byCategory[group.category] = stats;
  }

  // Feature step coverage — every Gherkin step in features/ must match a
  // Given/When/Then(...) definition somewhere in src/steps/.
  console.log('\n🥒 FEATURE STEP COVERAGE:');
  const featureCoverage = checkFeatureStepCoverage();
  if (!featureCoverage.ran) {
    console.log('   (no .feature files found under features/)');
  }
  for (const issue of featureCoverage.issues) {
    const icon = issue.severity === 'error' ? '❌' : issue.severity === 'warning' ? '⚠️ ' : 'ℹ️ ';
    console.log(`   ${icon} ${issue.message}`);
  }
  const featureCoverageHasErrors = featureCoverage.issues.some((i) => i.severity === 'error');

  // Manifest coverage — make sure nothing was silently skipped during migrate.js
  console.log('\n📋 MANIFEST COVERAGE:');
  const coverage = checkManifestCoverage();
  if (!coverage.ran) {
    console.log('   ⚠️  Skipped (no migration-manifest.json)');
  }
  for (const issue of coverage.issues) {
    const icon = issue.severity === 'error' ? '❌' : issue.severity === 'warning' ? '⚠️ ' : 'ℹ️ ';
    console.log(`   ${icon} ${issue.message}`);
  }
  const manifestHasErrors = coverage.issues.some((i) => i.severity === 'error');

  // Summary
  let totalPassed = 0, totalFailed = 0, totalFiles = 0, totalErrors = 0, totalWarnings = 0;
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('   SUMMARY');
  console.log('═══════════════════════════════════════════════════════════════\n');
  for (const group of groups) {
    const s = results.byCategory[group.category];
    totalPassed += s.passed;
    totalFailed += s.failed;
    totalFiles += s.total;
    totalErrors += s.errors;
    totalWarnings += s.warnings;
    if (s.total > 0) {
      console.log(`   ${CATEGORY_LABELS[group.category].padEnd(34)} ${s.passed}/${s.total} passed${s.failed > 0 ? ` (${s.failed} failed)` : ' ✅'}`);
    }
  }
  console.log('   ─────────────────────────────────────────────────────────');
  console.log(`   Total:    ${totalPassed}/${totalFiles} passed`);
  console.log(`   Errors:   ${totalErrors}`);
  console.log(`   Warnings: ${totalWarnings}\n`);

  const overallFailed = totalFailed > 0 || manifestHasErrors || featureCoverageHasErrors;

  if (!overallFailed) {
    console.log('   ✅ ALL CHECKS PASSED');
  } else {
    console.log('   ❌ VERIFICATION FAILED');
    if (totalFailed > 0) {
      console.log('\n   Failed files:');
      for (const file of results.files.filter((f) => !f.passed)) {
        console.log(`   - ${file.file}`);
      }
    }
    if (featureCoverageHasErrors) {
      console.log('\n   Feature step coverage errors found — see above.');
    }
    if (manifestHasErrors) {
      console.log('\n   Manifest coverage errors found — see above.');
    }
  }

  console.log('\n═══════════════════════════════════════════════════════════════\n');

  fs.writeFileSync(
    CONFIG.reportFile,
    JSON.stringify({ ...results, featureStepCoverage: featureCoverage.issues, manifestCoverage: coverage.issues }, null, 2)
  );
  console.log(`   Report saved: ${CONFIG.reportFile}\n`);

  process.exit(overallFailed ? 1 : 0);
}

// ═══════════════════════════════════════════════════════════════
// CLI
// ═══════════════════════════════════════════════════════════════

const args = process.argv.slice(2);

if (args[0] === 'file' && args[1]) {
  const result = verifyFile(args[1]);
  process.exit(result.passed ? 0 : 1);
} else if (args[0] === 'help' || args[0] === '--help') {
  console.log(`
CoVe - STRICT Chain of Verification (playwright-bdd architecture)

Usage:
  npm run verify              Run full verification across all categories
  npm run verify:file <path>  Verify a single file

Categories checked:
  Pages    src/pages/*.page.ts        — class structure, locator/method counts
  Steps    src/steps/*.steps.ts       — playwright-bdd Given/When/Then(...) definitions
  Utils    src/utils/*.utils.ts       — exported helper functions
  Config   src/config/*.config.ts     — auto-converted constants (zero TODOs expected)
  Types    src/types/*.types.ts       — auto-converted interfaces (zero TODOs expected)
  Legacy   src/legacy/**/*.legacy.ts  — flagged for manual review, never "passes"

Also checks:
  - Feature Step Coverage: every Gherkin step in features/*.feature has a
    matching Given/When/Then(...) definition in src/steps/
  - Manifest Coverage: migration-manifest.json to confirm no source file
    was silently skipped during migration

Exit codes:
  0 = All passed
  1 = Some failed
`);
} else {
  verifyAll();
}

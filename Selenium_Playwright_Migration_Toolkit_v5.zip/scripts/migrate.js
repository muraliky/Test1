#!/usr/bin/env node
/**
 * Selenium (Java) -> Playwright (TypeScript) Migration Script — v4
 *
 * Differences from v3:
 *  - Scans the ENTIRE `_source-java` tree (any folder layout), not just
 *    pages/steps/features. Every .java file is classified and routed.
 *  - Generates playwright-bdd step definitions (Given/When/Then). Feature
 *    files are kept as-is in features/ and compiled together with the
 *    generated steps by playwright-bdd's own `bddgen` at test-run time —
 *    no custom spec-file generation needed.
 *  - Produces a migration-manifest.json describing how every source file
 *    was classified and where it ended up, so nothing is silently dropped.
 *
 * Creates SKELETON files with TODO markers for anything that needs real
 * logic (pages, steps, utils). Method implementation is done by the
 * @pw-orchestrator / @pw-migrate agents. Pure data (constants, POJOs) is
 * converted automatically since it requires no judgement.
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const XLSX = require('xlsx');

// ═══════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════

const CONFIG = {
  sourceDir: './_source-java',
  pagesOut: './src/pages',
  stepsOut: './src/steps',
  utilsOut: './src/utils',
  configOut: './src/config',
  typesOut: './src/types',
  legacyOut: './src/legacy',
  fixturesOut: './src/fixtures',
  featuresOut: './features',
  testDataOut: './src/test-data',
  notesOut: './docs/migration-notes',
  pendingFile: './pending-methods.json',
  manifestFile: './migration-manifest.json',
};

// Tracks everything that still needs a human/agent to implement real logic
let pending = {
  pages: {},       // fileName -> [methodName, ...]
  steps: {},       // fileName -> [stepText, ...]
  utils: {},       // fileName -> [functionName, ...]
  pageFiles: [],
  stepFiles: [],
  utilFiles: [],
  totalMethods: 0,
  totalSteps: 0,
  totalUtilFunctions: 0,
};

// Full record of every source file and what happened to it
let manifest = {
  generatedAt: new Date().toISOString(),
  sourceRoot: CONFIG.sourceDir,
  files: [], // { source, category, output, notes }
  summary: {},
  needsManualReview: [],
};

// ═══════════════════════════════════════════════════════════════
// GENERIC UTILITIES
// ═══════════════════════════════════════════════════════════════

function toKebabCase(str) {
  return str
    .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
    .replace(/([A-Z])([A-Z][a-z])/g, '$1-$2')
    .toLowerCase();
}

function toCamelCase(str) {
  if (!str) return str;
  return str.charAt(0).toLowerCase() + str.slice(1);
}

function toPascalCase(str) {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Word-aware casing helpers — unlike toCamelCase/toPascalCase above (which
 * just flip the first letter of an already-cased identifier), these split on
 * underscores/hyphens/spaces first. Needed for yaml file names like
 * `account_aggregate.yaml`, which aren't camelCase/PascalCase to begin with.
 */
function splitWords(str) {
  return str
    .replace(/\.(ya?ml|java|xlsx?|xls)$/i, '')
    .split(/[-_\s]+/)
    .filter(Boolean);
}

function toPascalCaseFromWords(str) {
  return splitWords(str)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join('');
}

function toCamelCaseFromWords(str) {
  const pascal = toPascalCaseFromWords(str);
  return pascal ? pascal.charAt(0).toLowerCase() + pascal.slice(1) : pascal;
}

function toKebabCaseFromWords(str) {
  return splitWords(str)
    .map((w) => w.toLowerCase())
    .join('-');
}

/**
 * Normalizes a file/class name down to bare lowercase alphanumerics with any
 * trailing "Page" suffix stripped, so `AccountAggregatePage.java` and
 * `account_aggregate.yaml` resolve to the same key ("accountaggregate") and
 * can be paired up — a yaml-derived page object's locators, plus a same-named
 * Java page class's methods.
 */
function normalizeKey(name) {
  return name
    .replace(/\.(ya?ml|java|xlsx?|xls)$/i, '')
    .replace(/page$/i, '')
    .replace(/[^a-zA-Z0-9]/g, '')
    .toLowerCase();
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function getAllFiles(dir, ext) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  for (const item of fs.readdirSync(dir)) {
    const full = path.join(dir, item);
    if (fs.statSync(full).isDirectory()) {
      results = results.concat(getAllFiles(full, ext));
    } else if (item.endsWith(ext)) {
      results.push(full);
    }
  }
  return results;
}

function toPosix(p) {
  return p.replace(/\\/g, '/');
}

/**
 * Strip a leading directory segment if it matches one of the given
 * synonyms (case-insensitive). Used so `_source-java/pages/auth/Foo.java`
 * lands at `src/pages/auth/foo.page.ts` instead of `src/pages/pages/auth/...`.
 */
function stripKnownPrefix(relDir, synonyms) {
  if (!relDir || relDir === '.') return '';
  const parts = relDir.split(/[/\\]/).filter(Boolean);
  if (parts.length && synonyms.includes(parts[0].toLowerCase())) {
    return parts.slice(1).join('/');
  }
  return parts.join('/');
}

function formatMethodDescription(methodName) {
  const words = methodName
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, (s) => s.toUpperCase())
    .trim();
  return words;
}

// ═══════════════════════════════════════════════════════════════
// LOCATOR CONVERSION (Selenium -> Playwright)
// ═══════════════════════════════════════════════════════════════

/**
 * Safely wraps a raw locator/string value as a single-quoted TS string
 * literal, escaping backslashes and embedded single quotes. Selenium xpaths
 * routinely contain single-quoted predicates (e.g. contains(text(),'Foo')),
 * so naive `'${value}'` interpolation produces broken generated code.
 */
function tsStringLiteral(str) {
  return `'${String(str).replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
}

function escapeRegexLiteral(str) {
  return String(str).replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
}

function convertLocator(loc) {
  let m;

  if ((m = loc.match(/\/\/button\[text\(\)\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByRole('button', { name: ${tsStringLiteral(m[1])} })`;
  if ((m = loc.match(/\/\/button\[contains\(text\(\),\s*['"]([^'"]+)['"]\)\]/)))
    return `getByRole('button', { name: /${escapeRegexLiteral(m[1])}/i })`;
  if ((m = loc.match(/\/\/a\[text\(\)\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByRole('link', { name: ${tsStringLiteral(m[1])} })`;
  if ((m = loc.match(/\/\/input\[@placeholder\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByPlaceholder(${tsStringLiteral(m[1])})`;
  if ((m = loc.match(/\/\/label\[text\(\)\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByLabel(${tsStringLiteral(m[1])})`;
  if ((m = loc.match(/\/\/\*\[@data-testid\s*=\s*['"]([^'"]+)['"]\]/)))
    return `getByTestId(${tsStringLiteral(m[1])})`;
  if ((m = loc.match(/\/\/\w*\[@id\s*=\s*['"]([^'"]+)['"]\]/)))
    return `locator(${tsStringLiteral('#' + m[1])})`;
  if ((m = loc.match(/By\.id\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator(${tsStringLiteral('#' + m[1])})`;
  if ((m = loc.match(/By\.name\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator(${tsStringLiteral(`[name="${m[1]}"]`)})`;
  if ((m = loc.match(/By\.className\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator(${tsStringLiteral('.' + m[1])})`;
  if ((m = loc.match(/By\.cssSelector\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator(${tsStringLiteral(m[1])})`;
  if ((m = loc.match(/By\.xpath\s*\(\s*["']([^'"]+)["']\s*\)/)))
    return `locator(${tsStringLiteral(m[1])})`;
  if (loc.startsWith('//')) return `locator(${tsStringLiteral(loc)})`;

  return `locator(${tsStringLiteral(loc)})`;
}

// ═══════════════════════════════════════════════════════════════
// YAML UI OBJECT MAP → PLAYWRIGHT PAGE OBJECT
// (some repos keep page-object locators in standalone .yaml files —
//  e.g. QAF-style UI object repositories — instead of, or alongside,
//  literal @FindBy values in the Java page class itself)
// ═══════════════════════════════════════════════════════════════

// Recognized locator-strategy fields inside one yaml element's definition,
// in priority order (first non-empty one found wins).
const YAML_LOCATOR_FIELDS = ['id', 'css', 'xpath', 'class', 'name', 'linktext', 'partiallinktext', 'tagname', 'value'];

// Field names specific enough to a UI-locator definition on their own (a
// single occurrence is sufficient evidence). "class"/"name"/"value" are
// common enough in generic config yaml that they need a second corroborating
// field before counting as a locator definition.
const DISTINCTIVE_YAML_LOCATOR_FIELDS = ['id', 'css', 'xpath', 'linktext', 'partiallinktext', 'tagname'];

/**
 * Heuristic check: does this parsed yaml object look like a UI object map
 * (top-level keys = element names, each value an object carrying locator
 * fields like id/css/xpath/class/name/...), as opposed to some unrelated
 * config yaml? Requires at least half of the top-level entries to carry
 * either one distinctive locator field, or 2+ recognized locator-ish fields.
 */
function isQafUiMapYaml(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return false;
  const keys = Object.keys(obj);
  if (keys.length === 0) return false;

  let matchCount = 0;
  for (const k of keys) {
    const v = obj[k];
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      const subKeys = Object.keys(v).map((s) => s.toLowerCase());
      const hits = subKeys.filter((s) => YAML_LOCATOR_FIELDS.includes(s) || s === 'element_type').length;
      const hasDistinctive = subKeys.some((s) => DISTINCTIVE_YAML_LOCATOR_FIELDS.includes(s));
      if (hasDistinctive || hits >= 2) matchCount++;
    }
  }
  return matchCount > 0 && matchCount / keys.length >= 0.5;
}

/**
 * Picks the first populated locator-strategy field off one yaml element
 * definition and converts it to a Playwright locator expression (the part
 * that goes after `page.`).
 */
function convertYamlElementToLocator(el) {
  const get = (k) => (el && typeof el[k] === 'string' ? el[k].trim() : '');

  const id = get('id');
  if (id) return { expr: `locator(${tsStringLiteral('#' + id)})`, field: 'id', raw: id };

  const css = get('css');
  if (css) return { expr: `locator(${tsStringLiteral(css)})`, field: 'css', raw: css };

  const xpath = get('xpath');
  if (xpath) return { expr: convertLocator(xpath), field: 'xpath', raw: xpath };

  const cls = get('class');
  if (cls) return { expr: `locator(${tsStringLiteral('.' + cls.replace(/\s+/g, '.'))})`, field: 'class', raw: cls };

  const name = get('name');
  if (name) return { expr: `locator(${tsStringLiteral(`[name="${name}"]`)})`, field: 'name', raw: name };

  const linktext = get('linktext');
  if (linktext) return { expr: `getByRole('link', { name: ${tsStringLiteral(linktext)}, exact: true })`, field: 'linktext', raw: linktext };

  const partial = get('partiallinktext');
  if (partial) return { expr: `getByRole('link', { name: /${escapeRegexLiteral(partial)}/i })`, field: 'partiallinktext', raw: partial };

  const tagname = get('tagname');
  if (tagname) return { expr: `locator(${tsStringLiteral(tagname)})`, field: 'tagname', raw: tagname };

  const value = get('value');
  if (value) return { expr: `locator(${tsStringLiteral(value)})`, field: 'value', raw: value };

  return null;
}

function parseYamlPageObject(obj, fileName) {
  const className = `${toPascalCaseFromWords(fileName)}Page`;
  const locators = [];
  const skipped = [];

  for (const key of Object.keys(obj)) {
    const el = obj[key];
    if (!el || typeof el !== 'object') continue;

    const normEl = {};
    for (const k of Object.keys(el)) normEl[k.toLowerCase()] = el[k];

    const loc = convertYamlElementToLocator(normEl);
    const propName = toCamelCaseFromWords(key);

    if (loc) {
      locators.push({ name: propName, original: key, converted: loc.expr, sourceField: loc.field, sourceRaw: loc.raw });
    } else {
      skipped.push(key);
    }
  }

  return { className, locators, skipped };
}

function generateSkeletonPageFromYaml(parsed, yamlFile) {
  const kebab = toKebabCaseFromWords(path.basename(yamlFile)) || 'page';

  let out = `/**
 * @fileoverview ${parsed.className}
 * @source ${toPosix(yamlFile)}
 *
 * Auto-converted from a YAML UI object map (page objects maintained as data,
 * not as literal @FindBy values in a Java class). Every top-level yaml key
 * became a readonly Locator property below. If a Java page class with a
 * matching name exists in the source repo, its methods are merged into this
 * same file (see the @source-methods line, if present) instead of being
 * generated as a separate, locator-less page object.
 */

import { Page, Locator, expect } from '@playwright/test';

export class ${parsed.className} {
  readonly page: Page;
`;

  for (const loc of parsed.locators) {
    out += `  /**
   * ${loc.name} locator (yaml key "${loc.original}", ${loc.sourceField}: "${loc.sourceRaw}")
   * @type {Locator}
   */
  readonly ${loc.name}: Locator;
`;
  }

  out += `
  /**
   * Creates an instance of ${parsed.className}
   * @param {Page} page - Playwright page object
   */
  constructor(page: Page) {
    this.page = page;
`;
  for (const loc of parsed.locators) {
    out += `    this.${loc.name} = page.${loc.converted};\n`;
  }
  out += `  }\n`;

  if (parsed.skipped.length) {
    out += `
  // ⚠️  The following yaml keys had no usable locator field (id/css/xpath/
  // class/name/linktext/partiallinktext/tagname/value were all empty) and
  // were skipped. Review the source yaml and add them by hand if needed:
  // ${parsed.skipped.join(', ')}
`;
  }

  out += `}\n`;
  return { content: out, fileName: `${kebab}.page.ts`, className: parsed.className };
}

/**
 * Appends a Java page class's methods into an already-generated yaml-derived
 * page object file, rather than generating a second (locator-less) skeleton
 * for the same logical page. Locators stay sourced from the yaml; only
 * methods come from the Java file.
 */
function mergeMethodsIntoYamlPage(yamlMatch, parsed, javaFile) {
  let existing = fs.readFileSync(yamlMatch.outPath, 'utf-8');

  if (!existing.includes('@source-methods')) {
    existing = existing.replace(/(@source\s+[^\n\r]+\n)/, `$1 * @source-methods ${toPosix(javaFile)}\n`);
  }

  const methodNames = [];
  let methodsBlock = '';

  for (const method of parsed.methods) {
    methodNames.push(method.name);
    const tp = convertParams(method.params);
    const ret = javaToTsType(method.returnType);

    // Find every `someName.someMethod(...)` call in the Java method body and
    // flag any that don't correspond to a locator this page actually has.
    // Java field names commonly mirror the yaml's snake_case keys (e.g.
    // `view_tab.click()` for yaml key `view_tab`), so compare case-insensitively
    // via the same word-casing used to derive the yaml-based locator names.
    const KNOWN_NON_LOCATOR = new Set(['this', 'Thread', 'System', 'Assert', 'String', 'Integer', 'Boolean', 'Long', 'Double', 'Math', 'Arrays', 'List', 'Collections', 'Optional', 'Pattern']);
    const calledNames = Array.from(
      new Set((method.body.match(/\b([A-Za-z_]\w*)\.[A-Za-z_]\w*\s*\(/g) || []).map((m) => m.replace(/\.[A-Za-z_]\w*\s*\($/, '')))
    ).filter((n) => !KNOWN_NON_LOCATOR.has(n));
    const unknownRefs = calledNames.filter((n) => !yamlMatch.locatorNames.has(toCamelCaseFromWords(n)));

    methodsBlock += `
  /**
   * ${formatMethodDescription(method.name)}
${tp.docs ? tp.docs + '\n' : ''}   * @returns {Promise<${ret}>}
   */
  async ${method.name}(${tp.params}): Promise<${ret}> {
    // TODO: Implement this method
${unknownRefs.length ? `    // ⚠️  References not found among yaml-derived locators: ${unknownRefs.join(', ')} — verify the field/locator name\n` : ''}    // Original Java:
    // ${method.body.split('\n').map((l) => l.trim()).filter((l) => l).join('\n    // ')}
    throw new Error('Method ${method.name} not implemented');
  }
`;
  }

  const lastBrace = existing.lastIndexOf('}');
  existing = existing.slice(0, lastBrace) + methodsBlock + existing.slice(lastBrace);
  fs.writeFileSync(yamlMatch.outPath, existing);

  const fileName = path.basename(yamlMatch.outPath);
  pending.pages[fileName] = [...(pending.pages[fileName] || []), ...methodNames];
  if (!pending.pageFiles.includes(yamlMatch.relPath)) pending.pageFiles.push(yamlMatch.relPath);
  pending.totalMethods += methodNames.length;

  return methodNames;
}

// ═══════════════════════════════════════════════════════════════
// TYPE CONVERSION (Java -> TypeScript)
// ═══════════════════════════════════════════════════════════════

function javaToTsType(t) {
  if (!t) return 'unknown';
  let type = t.trim();

  // Generics: List<X>, ArrayList<X>, Set<X> -> X[]
  let m = type.match(/^(?:List|ArrayList|LinkedList|Set|HashSet)\s*<\s*(.+)\s*>$/);
  if (m) return `${javaToTsType(m[1])}[]`;

  // Map<K,V> -> Record<K, V>
  m = type.match(/^(?:Map|HashMap)\s*<\s*([^,]+)\s*,\s*(.+)\s*>$/);
  if (m) return `Record<${javaToTsType(m[1])}, ${javaToTsType(m[2])}>`;

  // Arrays: Type[]
  m = type.match(/^(.+)\[\]$/);
  if (m) return `${javaToTsType(m[1])}[]`;

  const map = {
    String: 'string',
    CharSequence: 'string',
    char: 'string',
    Character: 'string',
    int: 'number',
    Integer: 'number',
    long: 'number',
    Long: 'number',
    short: 'number',
    Short: 'number',
    double: 'number',
    Double: 'number',
    float: 'number',
    Float: 'number',
    BigDecimal: 'number',
    boolean: 'boolean',
    Boolean: 'boolean',
    void: 'void',
    Void: 'void',
    Object: 'unknown',
    WebElement: 'Locator',
    List: 'any[]',
    DataTable: 'Record<string, string>[]',
  };
  return map[type] || type; // fall back to the original type name (might be a converted model)
}

function convertParams(params) {
  if (!params || !params.trim()) return { params: '', docs: '', names: [], types: [] };
  const result = { params: [], docs: [], names: [], types: [] };
  for (const p of params.split(',').map((x) => x.trim())) {
    const parts = p.split(/\s+/);
    if (parts.length >= 2) {
      const tsType = javaToTsType(parts[0]);
      const name = parts[parts.length - 1];
      result.params.push(`${name}: ${tsType}`);
      result.docs.push(`   * @param {${tsType}} ${name}`);
      result.names.push(name);
      result.types.push(tsType);
    }
  }
  return {
    params: result.params.join(', '),
    docs: result.docs.join('\n'),
    names: result.names,
    types: result.types,
  };
}

// ═══════════════════════════════════════════════════════════════
// CLASSIFICATION — decide what a .java file actually is
// ═══════════════════════════════════════════════════════════════

const SYNONYMS = {
  page: ['pages', 'page', 'pageobjects', 'pageobject', 'po'],
  steps: ['steps', 'stepdefs', 'stepdefinitions', 'stepdefinition', 'glue'],
  util: ['utils', 'util', 'helpers', 'helper', 'common'],
  config: ['config', 'configs', 'constants', 'properties', 'env'],
  type: ['models', 'model', 'pojo', 'pojos', 'dto', 'dtos', 'types', 'beans', 'entities', 'entity'],
};

function getClassOrInterfaceName(content, fallback) {
  const cm = content.match(/(?:public\s+)?(?:abstract\s+)?(?:final\s+)?class\s+(\w+)/);
  if (cm) return cm[1];
  const im = content.match(/(?:public\s+)?interface\s+(\w+)/);
  if (im) return im[1];
  return fallback;
}

/**
 * Classify a Java source file into one of:
 *   'steps' | 'page' | 'infra' | 'type' | 'config' | 'util' | 'unknown'
 */
function classifyJavaFile(content, fileName, relDir) {
  const dirSeg = (relDir.split(/[/\\]/)[0] || '').toLowerCase();

  // 1. STEP DEFINITIONS — strongest signal, check first.
  if (/@(Given|When|Then)\s*\(/.test(content)) {
    return 'steps';
  }

  // 2. INFRASTRUCTURE — test-runner / driver-lifecycle / reporting plumbing
  //    that Playwright replaces natively (config, fixtures, built-in reporters).
  const infraNameHints = /\b(Hooks?|Runner|Listener|DriverFactory|DriverManager|TestBase|BaseTest|TestSuite|ExtentReport\w*|WebDriverManager)\b/;
  const infraContentHints =
    /@RunWith\s*\(|CucumberOptions|WebDriverManager\.|new\s+ChromeDriver\s*\(|new\s+FirefoxDriver\s*\(|new\s+RemoteWebDriver\s*\(|implements\s+ITestListener|implements\s+WebDriverEventListener|ExtentReports|ExtentTest|@BeforeSuite|@AfterSuite/;
  if (infraNameHints.test(fileName) || infraContentHints.test(content)) {
    return 'infra';
  }

  // 3. PAGE OBJECTS — @FindBy annotations, or WebElement fields + By locators.
  const hasFindBy = /@FindBy\s*\(/.test(content);
  const hasWebElementAndBy = /\bWebElement\b/.test(content) && /By\.\w+\s*\(/.test(content);
  const looksLikePageByName = /Page$/.test(fileName.replace('.java', '')) && /By\s+\w+\s*=/.test(content);
  if (hasFindBy || hasWebElementAndBy || looksLikePageByName) {
    return 'page';
  }

  // 4. CONFIG / CONSTANTS — file is (almost) entirely `static final` fields.
  const constantFields = content.match(/(?:public|private|protected)?\s*static\s+final\s+\w[\w<>,\[\]]*\s+\w+\s*=\s*[^;]+;/g) || [];
  const anyMethods = /(?:public|private|protected)\s+[\w<>\[\],\s]+\s+\w+\s*\([^)]*\)\s*\{/.test(
    content.replace(/(?:public|private|protected)?\s*static\s+final\s+[^;]+;/g, '')
  );
  if (constantFields.length >= 2 && (dirSeg && SYNONYMS.config.includes(dirSeg) ? true : !anyMethods)) {
    return 'config';
  }
  if (SYNONYMS.config.includes(dirSeg) && constantFields.length >= 1) {
    return 'config';
  }

  // 5. POJO / MODEL / DTO — private fields + matching getters, no Selenium.
  const privateFields = content.match(/private\s+[\w<>\[\],\s]+\s+\w+\s*;/g) || [];
  const getters = content.match(/public\s+[\w<>\[\],\s]+\s+get\w+\s*\(\s*\)/g) || [];
  const noSelenium = !/\bWebElement\b|\bWebDriver\b|By\.\w+\s*\(/.test(content);
  if (noSelenium && privateFields.length >= 1 && getters.length >= 1 && getters.length >= privateFields.length - 1) {
    return 'type';
  }

  // 6. UTIL / HELPER — static utility methods, nothing Selenium-specific.
  const staticMethods = content.match(/(?:public|private|protected)?\s*static\s+(?!final)[\w<>\[\],\s]+\s+\w+\s*\([^)]*\)\s*\{/g) || [];
  if (noSelenium && (staticMethods.length >= 1 || SYNONYMS.util.includes(dirSeg))) {
    return 'util';
  }

  // 7. Unknown — converted as a flagged legacy stub so nothing is dropped silently.
  return 'unknown';
}

/**
 * Given the index of an opening '{', scans forward counting brace depth
 * (with basic string/char-literal awareness so braces inside string
 * literals aren't miscounted) to find the matching closing '}'.
 *
 * This replaces a simpler regex heuristic (closing brace must be alone on
 * its own line) that used to back every method/step/hook extractor below.
 * That heuristic silently merged any single-line method — a common,
 * perfectly valid Java pattern for terse Selenium/QAF Page Object wrapper
 * methods like `public void clickSubmit() { submit.click(); }` — into
 * whatever method/step happened to follow it, since its closing brace
 * shares a line with the opening one.
 *
 * @returns {{ body: string, endIndex: number }} body excludes both braces;
 *   endIndex is the index immediately after the matching closing brace.
 */
function extractBalancedBraceBody(content, openBraceIndex) {
  let depth = 1;
  let i = openBraceIndex + 1;
  let inString = null;
  while (i < content.length && depth > 0) {
    const ch = content[i];
    if (inString) {
      if (ch === '\\') { i += 2; continue; }
      if (ch === inString) inString = null;
      i++;
      continue;
    }
    if (ch === '"' || ch === "'") { inString = ch; i++; continue; }
    if (ch === '{') depth++;
    else if (ch === '}') depth--;
    i++;
  }
  return { body: content.slice(openBraceIndex + 1, Math.max(i - 1, openBraceIndex + 1)), endIndex: i };
}

// ═══════════════════════════════════════════════════════════════
// PARSE: JAVA PAGE OBJECT
// ═══════════════════════════════════════════════════════════════

function parseJavaPage(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), locators: [], methods: [] };

  // Uses a backreference to the opening quote char so values that contain
  // the OTHER quote type (e.g. xpath text()='Sign In' inside a "..." value)
  // are captured in full instead of truncating at the first nested quote.
  const findByRe = /@FindBy\s*\(\s*(\w+)\s*=\s*(["'])((?:(?!\2).)*)\2\s*\)\s*(?:public|private|protected)?\s*\w+\s+(\w+)\s*;/g;
  let m;
  while ((m = findByRe.exec(content))) {
    const [, type, , val, name] = m;
    let conv;
    if (type === 'xpath') conv = convertLocator(val);
    else if (type === 'id') conv = `locator('#${val}')`;
    else if (type === 'name') conv = `locator('[name="${val}"]')`;
    else if (type === 'className' || type === 'css') conv = `locator('.${val}')`;
    else conv = `locator('${val}')`;
    result.locators.push({ name, original: `${type}="${val}"`, converted: conv });
  }

  const byRe = /(?:private|public|protected)?\s*By\s+(\w+)\s*=\s*(By\.\w+\s*\([^)]+\))\s*;/g;
  while ((m = byRe.exec(content))) {
    result.locators.push({ name: m[1], original: m[2], converted: convertLocator(m[2]) });
  }

  const methodSigRe = /public\s+(\w+)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{/g;
  while ((m = methodSigRe.exec(content))) {
    const [, ret, name, params] = m;
    const openBraceIndex = m.index + m[0].length - 1;
    const { body, endIndex } = extractBalancedBraceBody(content, openBraceIndex);
    methodSigRe.lastIndex = endIndex;
    if (name === result.className) continue; // skip constructor
    result.methods.push({ name, returnType: ret, params: params.trim(), body: body.trim() });
  }

  return result;
}

function generateSkeletonPage(parsed, javaFile) {
  const kebab = toKebabCase(parsed.className.replace(/Page$/, '')) || 'page';
  const methods = [];

  let out = `/**
 * @fileoverview ${parsed.className}
 * @source ${toPosix(javaFile)}
 */

import { Page, Locator, expect } from '@playwright/test';

export class ${parsed.className} {
  readonly page: Page;
`;

  for (const loc of parsed.locators) {
    out += `  /**
   * ${loc.name} locator
   * @type {Locator}
   */
  readonly ${loc.name}: Locator;
`;
  }

  out += `
  /**
   * Creates an instance of ${parsed.className}
   * @param {Page} page - Playwright page object
   */
  constructor(page: Page) {
    this.page = page;
`;
  for (const loc of parsed.locators) {
    out += `    this.${loc.name} = page.${loc.converted};\n`;
  }
  out += `  }\n`;

  for (const method of parsed.methods) {
    methods.push(method.name);
    const tp = convertParams(method.params);
    const ret = javaToTsType(method.returnType);

    out += `
  /**
   * ${formatMethodDescription(method.name)}
${tp.docs ? tp.docs + '\n' : ''}   * @returns {Promise<${ret}>}
   */
  async ${method.name}(${tp.params}): Promise<${ret}> {
    // TODO: Implement this method
    // Original Java:
    // ${method.body.split('\n').map((l) => l.trim()).filter((l) => l).join('\n    // ')}
    throw new Error('Method ${method.name} not implemented');
  }
`;
  }

  out += `}\n`;
  return { content: out, fileName: `${kebab}.page.ts`, className: parsed.className, methods };
}

// ═══════════════════════════════════════════════════════════════
// PARSE: JAVA STEP DEFINITIONS
// ═══════════════════════════════════════════════════════════════

function parseJavaSteps(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), steps: [], hooks: [] };

  const patterns = [
    /@(Given|When|Then|And|But)\s*\(\s*["'](.+?)["']\s*\)\s*(?:public\s+)?(?:void\s+)?(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{/g,
    /@(Given|When|Then|And|But)\s*\(\s*value\s*=\s*["'](.+?)["']\s*\)\s*(?:public\s+)?(?:void\s+)?(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{/g,
    /@(Given|When|Then|And|But)\s*\(\s*["']([\s\S]*?)["']\s*\)\s*(?:public\s+)?(?:void\s+)?(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{/g,
  ];

  const foundSteps = new Set();

  for (const stepRe of patterns) {
    let m;
    while ((m = stepRe.exec(content))) {
      let [, ann, text, name, params] = m;
      const openBraceIndex = m.index + m[0].length - 1;
      const { body, endIndex } = extractBalancedBraceBody(content, openBraceIndex);
      stepRe.lastIndex = endIndex;

      text = text.replace(/\s+/g, ' ').trim();
      if (foundSteps.has(text)) continue;
      foundSteps.add(text);

      if (ann === 'And' || ann === 'But') {
        const lower = text.toLowerCase();
        if (
          lower.includes('click') || lower.includes('enter') || lower.includes('select') ||
          lower.includes('type') || lower.includes('input') || lower.includes('fill') ||
          lower.includes('submit') || lower.includes('press') || lower.includes('navigate')
        ) {
          ann = 'When';
        } else if (
          lower.includes('should') || lower.includes('verify') || lower.includes('see') ||
          lower.includes('displayed') || lower.includes('visible') || lower.includes('assert') ||
          lower.includes('error') || lower.includes('message') || lower.includes('contains')
        ) {
          ann = 'Then';
        } else {
          ann = 'Given';
        }
      }

      result.steps.push({
        annotation: ann,
        stepText: text,
        methodName: name,
        params: params.trim(),
        body: body ? body.trim() : '',
      });
    }
  }

  // @Before / @After hooks inside a step-definition class (legal Cucumber pattern)
  const hookRe = /@(Before|After)(?:\s*\(\s*(?:["'][^"']*["'])?\s*\))?\s*(?:public\s+)?(?:void\s+)?(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{/g;
  let hm;
  while ((hm = hookRe.exec(content))) {
    const [, kind, name, params] = hm;
    const openBraceIndex = hm.index + hm[0].length - 1;
    const { body, endIndex } = extractBalancedBraceBody(content, openBraceIndex);
    hookRe.lastIndex = endIndex;
    result.hooks.push({ kind, methodName: name, params: params.trim(), body: body.trim() });
  }

  return result;
}

/**
 * Detect which page-object fixtures a step body references (by looking for
 * `someName.method()` calls where `someName` matches a registered fixture),
 * so the generated Given/When/Then destructures only what it needs.
 */
function detectFixtureRefs(body) {
  const refs = new Set();
  const pageRefs = body.match(/\b(\w+)Page\./g) || [];
  pageRefs.forEach((p) => refs.add(toCamelCase(p.replace('.', ''))));
  return Array.from(refs);
}

function generateSkeletonSteps(parsed, javaFile, relativeDir) {
  const steps = [];
  const stepTexts = [];

  // fixtures.ts always lives at src/fixtures/test-fixtures.ts; work out the
  // relative import path based on how deep this step file is nested under
  // src/steps/.
  const depth = relativeDir && relativeDir !== '.' ? relativeDir.split(/[/\\]/).filter(Boolean).length : 0;
  const fixturesImport = '../'.repeat(depth + 1) + 'fixtures/test-fixtures';

  let out = `/**
 * @fileoverview ${parsed.className} — step definitions
 * @source ${toPosix(javaFile)}
 *
 * playwright-bdd step definitions. Step text uses the same Cucumber
 * expressions ({string}, {int}, etc.) as the original .feature files, so
 * existing Gherkin scenarios match without being rewritten.
 */

import { Given, When, Then } from '${fixturesImport}';
import { expect } from '@playwright/test';

`;

  for (const step of parsed.steps) {
    steps.push(step.methodName);
    stepTexts.push(step.stepText);
    const tp = convertParams(step.params);
    const fixtures = ['page', ...detectFixtureRefs(step.body)];
    const typedArgList = tp.params ? `, ${tp.params}` : '';

    out += `/**
 * ${step.annotation}: ${step.stepText}
${tp.docs ? tp.docs + '\n' : ''} */
${step.annotation}('${escapeTsString(step.stepText)}', async ({ ${fixtures.join(', ')} }${typedArgList}) => {
  // TODO: Implement this step
  // Original Java:
  // ${step.body.split('\n').map((l) => l.trim()).filter((l) => l).join('\n  // ')}
  throw new Error('Step "${escapeTsString(step.stepText)}" not implemented');
});

`;
  }

  for (const hook of parsed.hooks) {
    out += `/**
 * NOTE: Originally a Cucumber @${hook.kind} hook.
 * Wire this into src/fixtures/test-fixtures.ts (fixture setup/teardown via
 * the \`use()\` callback) instead — playwright-bdd step files only contain
 * Given/When/Then, not raw hooks.
 * Original Java:
 * ${hook.body.split('\n').map((l) => l.trim()).filter((l) => l).join('\n * ')}
 */

`;
  }

  return { content: out, steps, stepTexts, hookNames: parsed.hooks.map((h) => h.methodName) };
}

// ═══════════════════════════════════════════════════════════════
// PARSE + GENERATE: UTIL / HELPER CLASSES
// ═══════════════════════════════════════════════════════════════

function parseJavaUtil(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), methods: [] };
  const methodSigRe = /(?:public|private|protected)?\s*static\s+(?!final\b)([\w<>\[\],\s]+?)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{/g;
  let m;
  while ((m = methodSigRe.exec(content))) {
    const [, ret, name, params] = m;
    const openBraceIndex = m.index + m[0].length - 1;
    const { body, endIndex } = extractBalancedBraceBody(content, openBraceIndex);
    methodSigRe.lastIndex = endIndex;
    result.methods.push({ name, returnType: ret.trim(), params: params.trim(), body: body.trim() });
  }
  // Fall back to non-static public methods if no static utility methods found
  if (result.methods.length === 0) {
    const instSigRe = /public\s+([\w<>\[\],\s]+?)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{/g;
    while ((m = instSigRe.exec(content))) {
      const [, ret, name, params] = m;
      const openBraceIndex = m.index + m[0].length - 1;
      const { body, endIndex } = extractBalancedBraceBody(content, openBraceIndex);
      instSigRe.lastIndex = endIndex;
      if (name === result.className) continue;
      result.methods.push({ name, returnType: ret.trim(), params: params.trim(), body: body.trim() });
    }
  }
  return result;
}

function generateSkeletonUtil(parsed, javaFile) {
  const functions = [];
  let out = `/**
 * @fileoverview ${parsed.className} — utility functions
 * @source ${toPosix(javaFile)}
 */

`;
  for (const method of parsed.methods) {
    functions.push(method.name);
    const tp = convertParams(method.params);
    const ret = javaToTsType(method.returnType);
    out += `/**
 * ${formatMethodDescription(method.name)}
${tp.docs ? tp.docs + '\n' : ''}   * @returns {${ret}}
 */
export function ${method.name}(${tp.params}): ${ret} {
  // TODO: Implement this function
  // Original Java:
  // ${method.body.split('\n').map((l) => l.trim()).filter((l) => l).join('\n  // ')}
  throw new Error('Function ${method.name} not implemented');
}

`;
  }
  return { content: out, functions };
}

// ═══════════════════════════════════════════════════════════════
// PARSE + GENERATE: CONFIG / CONSTANTS (fully automatic, no TODOs)
// ═══════════════════════════════════════════════════════════════

function convertJavaValueLiteral(raw) {
  let v = raw.trim();

  let m = v.match(/^System\.getenv\s*\(\s*["']([^"']+)["']\s*\)$/);
  if (m) return `process.env.${m[1]} ?? ''`;

  m = v.match(/^System\.getProperty\s*\(\s*["']([^"']+)["']\s*\)$/);
  if (m) return `process.env.${m[1].replace(/\./g, '_').toUpperCase()} ?? ''`;

  // Already a valid TS literal (string, number, boolean, simple array)
  if (/^["'].*["']$/.test(v) || /^-?\d+(\.\d+)?$/.test(v) || /^(true|false)$/.test(v)) {
    return v;
  }

  // new String[]{"a","b"} -> ["a","b"]
  m = v.match(/^new\s+\w+\[\]\s*\{([\s\S]*)\}$/);
  if (m) return `[${m[1]}]`;

  // Unrecognized expression — keep it but flag with a comment on the call site
  return `${v} /* TODO: verify converted value */`;
}

function parseJavaConfig(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), constants: [] };
  const fieldRe = /(?:public|private|protected)?\s*static\s+final\s+([\w<>\[\],\s]+?)\s+(\w+)\s*=\s*([\s\S]*?);/g;
  let m;
  while ((m = fieldRe.exec(content))) {
    const [, type, name, value] = m;
    result.constants.push({ name, type: type.trim(), value: value.trim() });
  }
  return result;
}

function generateConfigFile(parsed, javaFile) {
  let out = `/**
 * @fileoverview ${parsed.className} — configuration constants
 * @source ${toPosix(javaFile)}
 * Auto-converted 1:1 from \`static final\` fields. Review TODO markers (if any).
 */

`;
  for (const c of parsed.constants) {
    const tsType = javaToTsType(c.type);
    const tsValue = convertJavaValueLiteral(c.value);
    out += `export const ${c.name}: ${tsType} = ${tsValue};\n`;
  }
  return out;
}

// ═══════════════════════════════════════════════════════════════
// PARSE + GENERATE: POJO / MODEL / DTO (fully automatic)
// ═══════════════════════════════════════════════════════════════

function parseJavaType(content, fileName) {
  const result = { className: getClassOrInterfaceName(content, fileName.replace('.java', '')), fields: [] };
  const fieldRe = /private\s+([\w<>\[\],\s.]+?)\s+(\w+)\s*;/g;
  let m;
  while ((m = fieldRe.exec(content))) {
    const [, type, name] = m;
    result.fields.push({ name, type: type.trim() });
  }
  return result;
}

function generateTypeFile(parsed, javaFile) {
  let out = `/**
 * @fileoverview ${parsed.className} — data model
 * @source ${toPosix(javaFile)}
 * Auto-converted from a Java POJO/DTO's private fields.
 */

export interface ${parsed.className} {
`;
  for (const f of parsed.fields) {
    out += `  ${f.name}: ${javaToTsType(f.type)};\n`;
  }
  out += `}\n`;
  return out;
}

// ═══════════════════════════════════════════════════════════════
// LEGACY FALLBACK (unclassified files — never silently dropped)
// ═══════════════════════════════════════════════════════════════

function generateLegacyStub(content, javaFile, className) {
  return `/**
 * @fileoverview ${className} — UNCLASSIFIED SOURCE FILE
 * @source ${toPosix(javaFile)}
 *
 * ⚠️  This file could not be confidently classified as a page object, step
 * definition, utility, config, or model. The original Java source is kept
 * below for reference. Please review manually and move the converted logic
 * into src/pages, src/steps, src/utils, src/config, or src/types as
 * appropriate, then delete this file.
 *
 * Original Java:
 * ${content.split('\n').map((l) => l).join('\n * ')}
 */

export {}; // placeholder — remove once migrated
`;
}

// ═══════════════════════════════════════════════════════════════
// FEATURE FILE (GHERKIN) PARSING
// ═══════════════════════════════════════════════════════════════

function parseFeatureFile(content) {
  const lines = content.split('\n');
  const feature = { tags: [], name: '', description: [], background: null, scenarios: [] };

  let pendingTags = [];
  let mode = 'top'; // 'top' | 'description' | 'background' | 'scenario' | 'examples'
  let currentScenario = null;
  let currentExamples = null;
  let lastStepRef = null;

  for (let raw of lines) {
    const line = raw.replace(/\t/g, '  ');
    const trimmed = line.trim();

    if (!trimmed || trimmed.startsWith('#')) continue;

    if (trimmed.startsWith('@')) {
      pendingTags.push(...trimmed.split(/\s+/));
      continue;
    }

    if (/^Feature:/i.test(trimmed)) {
      feature.name = trimmed.replace(/^Feature:\s*/i, '').trim();
      feature.tags = pendingTags;
      pendingTags = [];
      mode = 'description';
      continue;
    }

    if (/^Background:/i.test(trimmed)) {
      feature.background = { steps: [] };
      mode = 'background';
      lastStepRef = null;
      continue;
    }

    if (/^Scenario Outline:|^Scenario Template:/i.test(trimmed)) {
      currentScenario = {
        type: 'outline',
        tags: pendingTags,
        name: trimmed.replace(/^Scenario Outline:|^Scenario Template:/i, '').trim(),
        steps: [],
        examples: [],
      };
      pendingTags = [];
      feature.scenarios.push(currentScenario);
      mode = 'scenario';
      lastStepRef = null;
      continue;
    }

    if (/^Scenario:/i.test(trimmed)) {
      currentScenario = {
        type: 'scenario',
        tags: pendingTags,
        name: trimmed.replace(/^Scenario:\s*/i, '').trim(),
        steps: [],
        examples: [],
      };
      pendingTags = [];
      feature.scenarios.push(currentScenario);
      mode = 'scenario';
      lastStepRef = null;
      continue;
    }

    if (/^Examples:|^Scenarios:/i.test(trimmed)) {
      currentExamples = { headers: [], rows: [] };
      currentScenario.examples.push(currentExamples);
      mode = 'examples';
      continue;
    }

    if (/^(Given|When|Then|And|But)\s+/.test(trimmed)) {
      const km = trimmed.match(/^(Given|When|Then|And|But)\s+(.*)$/);
      const stepObj = { keyword: km[1], text: km[2].trim(), docString: null, dataTable: null };
      if (mode === 'background') {
        feature.background.steps.push(stepObj);
      } else if (mode === 'scenario') {
        currentScenario.steps.push(stepObj);
      }
      lastStepRef = stepObj;
      continue;
    }

    if (trimmed.startsWith('|')) {
      const cells = trimmed
        .split('|')
        .slice(1, -1)
        .map((c) => c.trim());
      if (mode === 'examples') {
        if (currentExamples.headers.length === 0) currentExamples.headers = cells;
        else currentExamples.rows.push(cells);
      } else if (lastStepRef) {
        if (!lastStepRef.dataTable) lastStepRef.dataTable = { headers: [], rows: [] };
        if (lastStepRef.dataTable.headers.length === 0) lastStepRef.dataTable.headers = cells;
        else lastStepRef.dataTable.rows.push(cells);
      }
      continue;
    }

    if (trimmed.startsWith('"""')) {
      // DocString — best effort: not multi-line parsed, just flagged for manual review
      if (lastStepRef) lastStepRef.docString = '(doc string present — see original .feature file)';
      continue;
    }

    if (mode === 'description') {
      feature.description.push(trimmed);
    }
  }

  return feature;
}

function escapeTsString(s) {
  return s.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

// ═══════════════════════════════════════════════════════════════
// FIXTURES + CONFIG GENERATION
// ═══════════════════════════════════════════════════════════════

function generateFixtures(pageRegistrations) {
  let imports = '';
  let types = '';
  let impl = '';

  for (const p of pageRegistrations) {
    imports += `import { ${p.className} } from '../pages/${p.importPath}';\n`;
    types += `  ${p.fixtureName}: ${p.className};\n`;
    impl += `  ${p.fixtureName}: async ({ page }, use) => { await use(new ${p.className}(page)); },\n`;
  }

  return `/**
 * @fileoverview playwright-bdd fixtures
 *
 * Wires every generated Page Object into the Playwright-BDD test object as
 * a fixture, then exposes Given/When/Then bound to that test object. Step
 * definition files under src/steps/ (*.steps.ts) import Given/When/Then from
 * here rather than from 'playwright-bdd' directly.
 */

import { test as base, createBdd } from 'playwright-bdd';
${imports}
type CustomFixtures = {
${types}};

export const test = base.extend<CustomFixtures>({
${impl}});

export const { Given, When, Then } = createBdd(test);
export { expect } from '@playwright/test';
`;
}

function generatePlaywrightConfig() {
  return `import { defineConfig, devices } from '@playwright/test';
import { defineBddConfig, cucumberReporter } from 'playwright-bdd';

const testDir = defineBddConfig({
  features: './features/**/*.feature',
  // The fixtures file is included alongside the step definitions so
  // playwright-bdd can discover the custom \`test\` object (created via
  // createBdd() in src/fixtures/test-fixtures.ts) without extra config.
  steps: ['./src/steps/**/*.steps.ts', './src/fixtures/test-fixtures.ts'],
});

export default defineConfig({
  testDir,
  timeout: 30000,
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ['html'],
    ['list'],
    cucumberReporter('html', { outputFile: 'cucumber-report/report.html' }),
  ],

  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:3000',

    // Use installed Desktop Chrome rather than the bundled Playwright browser
    channel: 'chrome',

    // Saved auth state (cookies/session, never credentials) — see docs/AUTHENTICATION.md
    storageState: './auth.json',

    headless: false, // set true for CI
    viewport: { width: 1280, height: 720 },

    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },

  projects: [
    {
      name: 'setup',
      testMatch: /.*\\.setup\\.ts/,
      use: { storageState: undefined },
    },
    {
      name: 'desktop-chrome',
      dependencies: ['setup'],
      use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    },
  ],

  // Uncomment to start a local server before tests:
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://localhost:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});
`;
}

// ═══════════════════════════════════════════════════════════════
// MAIN MIGRATION PASS
// ═══════════════════════════════════════════════════════════════

let pageRegistrations = []; // { className, importPath (relative to src/pages, no ext), fixtureName }
let infraNotes = [];
let legacyFiles = [];
let yamlPageIndex = {}; // normalizedKey -> { className, outPath, relPath, locatorNames: Set<string> }

function recordManifest(sourceFile, category, outputFile, notes) {
  manifest.files.push({ source: toPosix(sourceFile), category, output: outputFile ? toPosix(outputFile) : null, notes: notes || '' });
}

/**
 * PASS 0 — yaml-based page objects. Runs before the Java pass so that when a
 * Java page class shares a name with an already-converted yaml UI map
 * (e.g. AccountAggregatePage.java <-> account_aggregate.yaml), its methods
 * get merged into the yaml-derived file instead of generating a second,
 * locator-less skeleton.
 */
function migrateYamlPageObjects() {
  console.log('\n🗺️  Scanning for YAML UI object maps (page objects kept as data)...\n');
  const yamlFiles = [...getAllFiles(CONFIG.sourceDir, '.yaml'), ...getAllFiles(CONFIG.sourceDir, '.yml')];
  if (!yamlFiles.length) {
    console.log('   No .yaml/.yml files found under ' + CONFIG.sourceDir);
    return;
  }

  let matched = 0;
  for (const file of yamlFiles) {
    const fileName = path.basename(file);
    let content;
    try {
      content = fs.readFileSync(file, 'utf-8');
    } catch (e) {
      console.log(`   ❌ ${fileName}: could not read (${e.message})`);
      continue;
    }

    let parsedYaml;
    try {
      parsedYaml = yaml.load(content);
    } catch (e) {
      console.log(`   ⚠️  ${fileName}: not valid YAML, skipped (${e.message})`);
      continue;
    }

    if (!isQafUiMapYaml(parsedYaml)) {
      // Doesn't look like a UI object map (could be some unrelated config
      // yaml elsewhere in the repo) — leave it untouched.
      continue;
    }

    matched++;
    const relDir = path.relative(CONFIG.sourceDir, path.dirname(file));
    const parsed = parseYamlPageObject(parsedYaml, fileName);
    const result = generateSkeletonPageFromYaml(parsed, file);

    const outDir = path.join(CONFIG.pagesOut, stripKnownPrefix(relDir, SYNONYMS.page));
    ensureDir(outDir);
    const outPath = path.join(outDir, result.fileName);
    fs.writeFileSync(outPath, result.content);

    const relPath = toPosix(path.relative('.', outPath));
    const importPath = toPosix(path.relative(CONFIG.pagesOut, outPath)).replace(/\.ts$/, '');
    pageRegistrations.push({ className: result.className, importPath, fixtureName: toCamelCase(result.className) });

    yamlPageIndex[normalizeKey(fileName)] = {
      className: result.className,
      outPath,
      relPath,
      locatorNames: new Set(parsed.locators.map((l) => l.name)),
    };

    recordManifest(
      file,
      'page-yaml',
      outPath,
      `YAML UI object map → ${parsed.locators.length} locator(s) auto-converted${parsed.skipped.length ? `, ${parsed.skipped.length} skipped (no usable locator field)` : ''}`
    );
    console.log(`   🗺️  YAML PAGE ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${relPath}  (${parsed.locators.length} locator(s))`);
  }

  if (matched === 0) {
    console.log('   Found .yaml/.yml file(s), but none matched the UI-object-map shape (id/css/xpath/class/name/linktext/... fields) — none converted.');
  }
}

/**
 * PASS 0.5 — Excel data-provider workbooks. One-time conversion to JSON;
 * the JSON becomes the source of truth going forward (the .xlsx file is not
 * read again at test time).
 */
function migrateExcelDataProviders() {
  console.log('\n📊 Scanning for Excel data-provider workbooks...\n');
  const excelFiles = [...getAllFiles(CONFIG.sourceDir, '.xlsx'), ...getAllFiles(CONFIG.sourceDir, '.xls')];
  if (!excelFiles.length) {
    console.log('   No .xlsx/.xls files found under ' + CONFIG.sourceDir);
    return;
  }

  let convertedAny = false;

  for (const file of excelFiles) {
    const fileName = path.basename(file);
    const workbookBase = toKebabCaseFromWords(fileName) || 'workbook';
    let workbook;
    try {
      workbook = XLSX.readFile(file, { cellText: true });
    } catch (e) {
      console.log(`   ❌ ${fileName}: could not read (${e.message})`);
      continue;
    }

    const combined = {};
    const relDir = path.relative(CONFIG.sourceDir, path.dirname(file));
    const outDir = path.join(CONFIG.testDataOut, stripKnownPrefix(relDir, []));
    ensureDir(outDir);

    for (const sheetName of workbook.SheetNames) {
      const sheet = workbook.Sheets[sheetName];
      const records = parseDataProviderSheet(sheet);
      if (records.length === 0) continue;

      combined[sheetName] = records;

      const sheetOutDir = path.join(outDir, workbookBase);
      ensureDir(sheetOutDir);
      const sheetOutPath = path.join(sheetOutDir, `${toKebabCaseFromWords(sheetName) || 'sheet'}.json`);
      fs.writeFileSync(sheetOutPath, JSON.stringify(records, null, 2));
    }

    if (Object.keys(combined).length === 0) {
      console.log(`   ⚠️  ${fileName}: no readable sheets/rows found, skipped`);
      continue;
    }

    const combinedOutPath = path.join(outDir, `${workbookBase}.json`);
    fs.writeFileSync(combinedOutPath, JSON.stringify(combined, null, 2));
    convertedAny = true;

    const sheetCount = Object.keys(combined).length;
    const recordCount = Object.values(combined).reduce((s, r) => s + r.length, 0);

    recordManifest(
      file,
      'data',
      combinedOutPath,
      `Excel data provider → JSON (one-time conversion, JSON is now the source of truth), ${sheetCount} sheet(s), ${recordCount} record(s)`
    );
    console.log(`   📊 DATA   ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${toPosix(combinedOutPath)}  (${sheetCount} sheet(s), ${recordCount} record(s))`);
  }

  if (convertedAny) {
    generateDataProviderUtil();
    console.log('   ✅ src/utils/test-data.utils.ts (load JSON test data via getWorkbookData/getSheetData/findScenario)');
  }
}

/**
 * Parses one Excel sheet into an array of flat record objects. Tries the
 * "block style" QAF data-provider layout first (a labeled row — column A is
 * the scenario/test-case name, other populated columns in that same row are
 * field headers — immediately followed by a data row holding the values for
 * those same columns), falling back to a plain single-header-row flat table
 * if no blocks are found. This is a best-effort, generic heuristic — if your
 * workbook uses a different layout, adjust this function.
 */
function parseDataProviderSheet(sheet) {
  const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: '' });
  const blockRecords = parseBlockStyleSheet(rows);
  if (blockRecords.length > 0) return blockRecords;
  return parseFlatTableSheet(rows);
}

function parseBlockStyleSheet(rows) {
  const records = [];
  let i = 0;
  while (i < rows.length) {
    const row = rows[i] || [];
    const colA = (row[0] || '').toString().trim();

    const headerCols = [];
    for (let c = 1; c < row.length; c++) {
      const v = (row[c] || '').toString().trim();
      if (v) headerCols.push({ col: c, label: v });
    }

    if (colA && headerCols.length > 0) {
      const nextRow = rows[i + 1] || [];
      const nextColA = (nextRow[0] || '').toString().trim();

      if (!nextColA) {
        // Genuine block: the next row carries the data values and doesn't
        // start a new labeled block of its own.
        const record = { scenario: colA };
        for (const { col, label } of headerCols) {
          record[toCamelCaseFromWords(label)] = (nextRow[col] || '').toString().trim();
        }
        records.push(record);
        i += 2;
        continue;
      }

      // Column A is populated on the very next row too — this isn't the
      // "label row, then data row" pairing block-style sheets use (it looks
      // more like a flat table where every row is its own complete record).
      // Bail out of block-style parsing entirely rather than fabricate
      // empty-value records; the caller falls back to parseFlatTableSheet,
      // which can parse the whole sheet correctly from the top.
      return [];
    }
    i++;
  }
  return records;
}

function parseFlatTableSheet(rows) {
  const cleaned = rows.filter((r) => (r || []).some((c) => (c || '').toString().trim()));
  if (cleaned.length < 2) return [];

  const headers = cleaned[0].map((c) => (c || '').toString().trim());
  if (headers.filter(Boolean).length < 2) return [];

  const records = [];
  for (let i = 1; i < cleaned.length; i++) {
    const row = cleaned[i];
    const record = {};
    let any = false;
    headers.forEach((h, idx) => {
      if (!h) return;
      const val = (row[idx] || '').toString().trim();
      if (val) any = true;
      record[toCamelCaseFromWords(h)] = val;
    });
    if (any) records.push(record);
  }
  return records;
}

function generateDataProviderUtil() {
  const content = `/**
 * @fileoverview Test data provider
 *
 * Replaces the old Excel-based data provider. Workbook(s) under
 * _source-java/ were converted ONE TIME into JSON by \`node scripts/migrate.js\`
 * — the JSON files under src/test-data/ are now the source of truth; the
 * original .xlsx file(s) are not read again at test time.
 *
 * Layout written by migrate.js:
 *   src/test-data/<workbook>.json              -> { "<sheetName>": TestDataRecord[] }
 *   src/test-data/<workbook>/<sheetName>.json   -> TestDataRecord[] (same data, per-sheet)
 *
 * Each record always has a "scenario" field — the original block label /
 * test-case name from the source sheet (or empty string for plain flat-table
 * sheets that had no per-row label column).
 */

import fs from 'fs';
import path from 'path';

const TEST_DATA_DIR = path.join(__dirname, '..', 'test-data');

export type TestDataRecord = Record<string, string>;

/**
 * Loads every sheet of a converted workbook.
 * @param {string} workbook - workbook file name without extension, e.g. 'pwm-phase3-test-runner'
 * @returns {Record<string, TestDataRecord[]>}
 */
export function getWorkbookData(workbook: string): Record<string, TestDataRecord[]> {
  const file = path.join(TEST_DATA_DIR, \`\${workbook}.json\`);
  if (!fs.existsSync(file)) {
    throw new Error(\`Test data workbook not found: \${file}\`);
  }
  return JSON.parse(fs.readFileSync(file, 'utf-8'));
}

/**
 * Loads a single sheet's records.
 * @param {string} workbook
 * @param {string} sheet
 * @returns {TestDataRecord[]}
 */
export function getSheetData(workbook: string, sheet: string): TestDataRecord[] {
  const data = getWorkbookData(workbook);
  if (!data[sheet]) {
    throw new Error(\`Sheet "\${sheet}" not found in workbook "\${workbook}". Available: \${Object.keys(data).join(', ')}\`);
  }
  return data[sheet];
}

/**
 * Finds a single record by its "scenario" field (the original block label /
 * test-case name from the source Excel sheet).
 * @param {string} workbook
 * @param {string} sheet
 * @param {string} scenario
 * @returns {TestDataRecord | undefined}
 */
export function findScenario(workbook: string, sheet: string, scenario: string): TestDataRecord | undefined {
  return getSheetData(workbook, sheet).find((r) => r.scenario === scenario);
}
`;
  ensureDir(CONFIG.utilsOut);
  fs.writeFileSync(path.join(CONFIG.utilsOut, 'test-data.utils.ts'), content);
}

function migrateJavaFiles() {
  console.log('\n🔎 Scanning entire source repo...\n');
  const javaFiles = getAllFiles(CONFIG.sourceDir, '.java');
  if (!javaFiles.length) {
    console.log('   No .java files found under ' + CONFIG.sourceDir);
    return;
  }
  console.log(`   Found ${javaFiles.length} Java file(s)\n`);

  for (const file of javaFiles) {
    const fileName = path.basename(file);
    const relDir = path.relative(CONFIG.sourceDir, path.dirname(file));
    let content;
    try {
      content = fs.readFileSync(file, 'utf-8');
    } catch (e) {
      console.log(`   ❌ ${fileName}: could not read (${e.message})`);
      continue;
    }

    const category = classifyJavaFile(content, fileName, relDir);

    try {
      switch (category) {
        case 'page': {
          const parsed = parseJavaPage(content, fileName);
          const yamlMatch = yamlPageIndex[normalizeKey(fileName)];

          if (yamlMatch) {
            // A yaml UI object map with a matching name was already converted
            // in PASS 0 — merge this Java class's methods into that file
            // instead of generating a second, locator-less skeleton (this
            // Java file's @FindBy values are typically just key references
            // into the yaml, not real locators, so parsed.locators is
            // intentionally discarded here).
            const methodNames = mergeMethodsIntoYamlPage(yamlMatch, parsed, file);
            recordManifest(
              file,
              'page',
              yamlMatch.outPath,
              `Merged ${methodNames.length} method(s) into yaml-derived page object ${yamlMatch.relPath} — locators sourced from the yaml file, not this Java file`
            );
            console.log(`   📄 PAGE   ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${yamlMatch.relPath} (merged into yaml-derived page; ${methodNames.length} method(s))`);
            break;
          }

          const result = generateSkeletonPage(parsed, file);
          const outDir = path.join(CONFIG.pagesOut, stripKnownPrefix(relDir, SYNONYMS.page));
          ensureDir(outDir);
          const outPath = path.join(outDir, result.fileName);
          fs.writeFileSync(outPath, result.content);

          const relPath = toPosix(path.relative('.', outPath));
          pending.pages[result.fileName] = result.methods;
          pending.pageFiles.push(relPath);
          pending.totalMethods += result.methods.length;

          const importPath = toPosix(path.relative(CONFIG.pagesOut, outPath)).replace(/\.ts$/, '');
          pageRegistrations.push({
            className: result.className,
            importPath,
            fixtureName: toCamelCase(result.className),
          });

          recordManifest(file, 'page', outPath, `${result.methods.length} method(s) need implementation`);
          console.log(`   📄 PAGE   ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${relPath}`);
          break;
        }
        case 'steps': {
          const parsed = parseJavaSteps(content, fileName);
          const kebab = toKebabCase(parsed.className.replace(/Steps?$/, '')) || 'steps';
          const outFileName = `${kebab}.steps.ts`;
          const stepsRelDir = stripKnownPrefix(relDir, SYNONYMS.steps);
          const outDir = path.join(CONFIG.stepsOut, stepsRelDir);
          ensureDir(outDir);
          const outPath = path.join(outDir, outFileName);

          const result = generateSkeletonSteps(parsed, file, stepsRelDir);
          fs.writeFileSync(outPath, result.content);

          const relPath = toPosix(path.relative('.', outPath));
          pending.steps[outFileName] = result.stepTexts;
          pending.stepFiles.push(relPath);
          pending.totalSteps += result.steps.length;

          recordManifest(
            file,
            'steps',
            outPath,
            `${result.steps.length} step(s)${result.hookNames.length ? `, ${result.hookNames.length} hook(s)` : ''} need implementation`
          );
          console.log(`   📝 STEPS  ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${relPath}`);
          break;
        }
        case 'util': {
          const parsed = parseJavaUtil(content, fileName);
          const kebab = toKebabCase(parsed.className) || 'util';
          const outFileName = `${kebab}.utils.ts`;
          const outDir = path.join(CONFIG.utilsOut, stripKnownPrefix(relDir, SYNONYMS.util));
          ensureDir(outDir);
          const outPath = path.join(outDir, outFileName);
          const result = generateSkeletonUtil(parsed, file);
          fs.writeFileSync(outPath, result.content);

          const relPath = toPosix(path.relative('.', outPath));
          pending.utils[outFileName] = result.functions;
          pending.utilFiles.push(relPath);
          pending.totalUtilFunctions += result.functions.length;

          recordManifest(file, 'util', outPath, `${result.functions.length} function(s) need implementation`);
          console.log(`   🔧 UTIL   ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${relPath}`);
          break;
        }
        case 'config': {
          const parsed = parseJavaConfig(content, fileName);
          const kebab = toKebabCase(parsed.className) || 'config';
          const outFileName = `${kebab}.config.ts`;
          const outDir = path.join(CONFIG.configOut, stripKnownPrefix(relDir, SYNONYMS.config));
          ensureDir(outDir);
          const outPath = path.join(outDir, outFileName);
          fs.writeFileSync(outPath, generateConfigFile(parsed, file));

          recordManifest(file, 'config', outPath, `${parsed.constants.length} constant(s) auto-converted`);
          console.log(`   ⚙️  CONFIG ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${toPosix(path.relative('.', outPath))}`);
          break;
        }
        case 'type': {
          const parsed = parseJavaType(content, fileName);
          const kebab = toKebabCase(parsed.className) || 'model';
          const outFileName = `${kebab}.types.ts`;
          const outDir = path.join(CONFIG.typesOut, stripKnownPrefix(relDir, SYNONYMS.type));
          ensureDir(outDir);
          const outPath = path.join(outDir, outFileName);
          fs.writeFileSync(outPath, generateTypeFile(parsed, file));

          recordManifest(file, 'type', outPath, `${parsed.fields.length} field(s) auto-converted`);
          console.log(`   🧩 TYPE   ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${toPosix(path.relative('.', outPath))}`);
          break;
        }
        case 'infra': {
          infraNotes.push({ file: toPosix(path.relative(CONFIG.sourceDir, file)), className: getClassOrInterfaceName(content, fileName) });
          recordManifest(file, 'infra', null, 'Superseded by Playwright config/fixtures/reporters — see docs/migration-notes/infrastructure.md');
          console.log(`   ⚠️  INFRA  ${toPosix(path.relative(CONFIG.sourceDir, file))} → (no TS output — see migration notes)`);
          break;
        }
        default: {
          const className = getClassOrInterfaceName(content, fileName.replace('.java', ''));
          const outDir = path.join(CONFIG.legacyOut, relDir === '.' ? '' : relDir);
          ensureDir(outDir);
          const outFileName = `${toKebabCase(className) || toKebabCase(fileName.replace('.java', ''))}.legacy.ts`;
          const outPath = path.join(outDir, outFileName);
          fs.writeFileSync(outPath, generateLegacyStub(content, file, className));

          legacyFiles.push(toPosix(path.relative('.', outPath)));
          manifest.needsManualReview.push(toPosix(path.relative(CONFIG.sourceDir, file)));
          recordManifest(file, 'unknown', outPath, 'Could not be classified — needs manual review');
          console.log(`   ❓ UNKNOWN ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${toPosix(path.relative('.', outPath))} (needs manual review)`);
          break;
        }
      }
    } catch (e) {
      console.log(`   ❌ ${fileName}: ${e.message}`);
      recordManifest(file, 'error', null, e.message);
    }
  }
}

function migrateFeatureFiles() {
  console.log('\n📋 Processing Feature Files...\n');
  const featureFiles = getAllFiles(CONFIG.sourceDir, '.feature');
  if (!featureFiles.length) {
    console.log('   No .feature files found');
    return;
  }

  for (const file of featureFiles) {
    const relDir = stripKnownPrefix(path.relative(CONFIG.sourceDir, path.dirname(file)), ['features', 'feature']);
    const fileName = path.basename(file);

    // Copy the feature file as-is — playwright-bdd's `bddgen` reads .feature
    // files directly at test-run time and matches steps via the Given/When/
    // Then definitions in src/steps/, so nothing needs to be pre-compiled here.
    const featOutDir = path.join(CONFIG.featuresOut, relDir);
    ensureDir(featOutDir);
    const content = fs.readFileSync(file, 'utf-8');
    const outPath = path.join(featOutDir, fileName);
    fs.writeFileSync(outPath, content);

    const feature = parseFeatureFile(content);
    const totalSteps =
      (feature.background ? feature.background.steps.length : 0) +
      feature.scenarios.reduce((sum, sc) => sum + sc.steps.length, 0);

    recordManifest(file, 'feature', outPath, `${feature.scenarios.length} scenario(s), ${totalSteps} step line(s) — compiled by playwright-bdd at test-run time`);
    console.log(`   ✅ ${toPosix(path.relative(CONFIG.sourceDir, file))} → ${toPosix(outPath)} (${feature.scenarios.length} scenario(s))`);
  }
}

function generateInfraNotesDoc() {
  ensureDir(CONFIG.notesOut);
  if (infraNotes.length === 0) return;

  let out = `# Infrastructure Files — Not Converted 1:1

These Java source files implement test-framework plumbing (driver lifecycle,
test runner wiring, hooks, reporting/listeners). Playwright provides this
natively, so they were intentionally **not** transliterated into TypeScript.
Use the table below to find the Playwright equivalent for each one.

| Source file | Class | Playwright equivalent |
|---|---|---|
`;
  for (const n of infraNotes) {
    out += `| \`${n.file}\` | \`${n.className}\` | See notes below |\n`;
  }

  out += `
## Cheat sheet

| Java/Selenium concept | Playwright equivalent |
|---|---|
| \`Hooks.java\` (\`@Before\`/\`@After\`) | \`src/fixtures/test-fixtures.ts\` fixture setup/teardown (the \`use()\` callback), or \`test.beforeEach\`/\`test.afterEach\` |
| \`DriverFactory\` / \`DriverManager\` | \`playwright.config.ts\` \`projects\` + \`use\` block (browser/channel is configured once, not per-test) |
| \`TestRunner\` (\`@RunWith(Cucumber.class)\`, \`@CucumberOptions\`) | \`playwright.config.ts\`'s \`defineBddConfig({ features, steps })\` — \`playwright-bdd\` discovers \`.feature\` files and step definitions itself, no runner class needed |
| \`Listener\` (\`ITestListener\`, \`WebDriverEventListener\`) | Built-in reporters (\`html\`, \`list\`, \`json\`) plus \`cucumberReporter()\` from \`playwright-bdd\`, configured in \`playwright.config.ts\` |
| \`ExtentReports\` | \`cucumberReporter('html', ...)\` (writes \`cucumber-report/report.html\`) plus Playwright's own HTML reporter (\`npx playwright show-report\`) |
| \`WebDriverManager\` (binary management) | Not needed — Playwright manages/launches browsers itself, or use \`channel: 'chrome'\` to drive the installed Desktop Chrome |
`;

  fs.writeFileSync(path.join(CONFIG.notesOut, 'infrastructure.md'), out);
  console.log(`\n   📓 Wrote docs/migration-notes/infrastructure.md (${infraNotes.length} file(s))`);
}

function generateSupportFiles() {
  console.log('\n🔧 Generating Support Files...\n');

  ensureDir(CONFIG.fixturesOut);
  fs.writeFileSync(path.join(CONFIG.fixturesOut, 'test-fixtures.ts'), generateFixtures(pageRegistrations));
  console.log('   ✅ src/fixtures/test-fixtures.ts');

  fs.writeFileSync('playwright.config.ts', generatePlaywrightConfig());
  console.log('   ✅ playwright.config.ts');

  fs.writeFileSync(CONFIG.pendingFile, JSON.stringify(pending, null, 2));
  console.log(`   ✅ ${CONFIG.pendingFile}`);

  manifest.summary = {
    totalSourceFiles: manifest.files.length,
    pages: manifest.files.filter((f) => f.category === 'page').length,
    yamlPages: manifest.files.filter((f) => f.category === 'page-yaml').length,
    steps: manifest.files.filter((f) => f.category === 'steps').length,
    utils: manifest.files.filter((f) => f.category === 'util').length,
    config: manifest.files.filter((f) => f.category === 'config').length,
    types: manifest.files.filter((f) => f.category === 'type').length,
    infra: manifest.files.filter((f) => f.category === 'infra').length,
    features: manifest.files.filter((f) => f.category === 'feature').length,
    dataProviders: manifest.files.filter((f) => f.category === 'data').length,
    unknown: manifest.files.filter((f) => f.category === 'unknown').length,
    errors: manifest.files.filter((f) => f.category === 'error').length,
  };
  fs.writeFileSync(CONFIG.manifestFile, JSON.stringify(manifest, null, 2));
  console.log(`   ✅ ${CONFIG.manifestFile}`);

  generateInfraNotesDoc();
}

function runMigration() {
  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('     SELENIUM (JAVA) → PLAYWRIGHT (TYPESCRIPT) MIGRATION');
  console.log('═══════════════════════════════════════════════════════════════');

  // Pass 0: yaml-based UI object maps (page objects kept as data). Runs
  // before the Java pass so matching Java page classes (paired by name) get
  // their methods merged in rather than generating duplicate, locator-less
  // page skeletons.
  migrateYamlPageObjects();

  // Pass 0.5: Excel data-provider workbooks -> one-time JSON conversion.
  migrateExcelDataProviders();

  // Pass 1: classify and convert every .java file in the repo.
  migrateJavaFiles();

  // Pass 2: feature files need the step registry from pass 1 to be complete
  // before they can be matched against, so this always runs second.
  migrateFeatureFiles();

  generateSupportFiles();

  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('                    SKELETON GENERATION COMPLETE');
  console.log('═══════════════════════════════════════════════════════════════\n');
  console.log(`   Source files scanned:  ${manifest.summary.totalSourceFiles}`);
  console.log(`   ├─ Pages:              ${manifest.summary.pages}  (${pending.totalMethods} methods to implement)`);
  console.log(`   ├─ Yaml page objects:  ${manifest.summary.yamlPages}  (locators auto-converted, 0 TODOs unless a Java page class was merged in)`);
  console.log(`   ├─ Step files:         ${manifest.summary.steps}  (${pending.totalSteps} steps to implement)`);
  console.log(`   ├─ Utils:              ${manifest.summary.utils}  (${pending.totalUtilFunctions} functions to implement)`);
  console.log(`   ├─ Config (auto):      ${manifest.summary.config}`);
  console.log(`   ├─ Types/POJOs (auto): ${manifest.summary.types}`);
  console.log(`   ├─ Data providers:     ${manifest.summary.dataProviders}  (Excel -> JSON, one-time conversion, see src/test-data/)`);
  console.log(`   ├─ Feature files:      ${manifest.summary.features}  (kept in features/, compiled by playwright-bdd's bddgen at test-run time)`);
  console.log(`   ├─ Infra (notes only): ${manifest.summary.infra}`);
  console.log(`   └─ Unclassified:       ${manifest.summary.unknown}  ${manifest.summary.unknown ? '⚠️  see migration-manifest.json' : ''}`);
  console.log('');
  console.log('   Next Steps (ONE FILE, ONE METHOD at a time):');
  console.log('     @pw-orchestrator start');
  console.log('\n═══════════════════════════════════════════════════════════════\n');
}

function showStatus() {
  if (!fs.existsSync(CONFIG.pendingFile)) {
    console.log('No pending-methods.json found. Run: npm run migrate');
    return;
  }
  const p = JSON.parse(fs.readFileSync(CONFIG.pendingFile, 'utf-8'));

  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('                    MIGRATION STATUS');
  console.log('═══════════════════════════════════════════════════════════════\n');

  console.log('   PAGE FILES:');
  p.pageFiles.forEach((file, i) => {
    const methods = p.pages[path.basename(file)] || [];
    console.log(`     ${i + 1}. ${file}`);
    methods.forEach((m) => console.log(`        • ${m}`));
  });

  console.log('\n   STEP FILES:');
  p.stepFiles.forEach((file, i) => {
    const steps = p.steps[path.basename(file)] || [];
    console.log(`     ${i + 1}. ${file}`);
    steps.slice(0, 3).forEach((s) => console.log(`        • ${s.substring(0, 50)}...`));
    if (steps.length > 3) console.log(`        ... and ${steps.length - 3} more`);
  });

  console.log('\n   UTIL FILES:');
  (p.utilFiles || []).forEach((file, i) => {
    const fns = p.utils[path.basename(file)] || [];
    console.log(`     ${i + 1}. ${file}`);
    fns.forEach((f) => console.log(`        • ${f}`));
  });

  console.log('\n   TOTALS:');
  console.log(`     Methods:   ${p.totalMethods}`);
  console.log(`     Steps:     ${p.totalSteps}`);
  console.log(`     Functions: ${p.totalUtilFunctions || 0}`);
  console.log('\n═══════════════════════════════════════════════════════════════\n');
}

function showHelp() {
  console.log(`
Selenium to Playwright Migration Script

Usage:
  npm run migrate          - Run full migration (create skeletons)
  npm run migrate:status   - Show migration status
  npm run migrate:help     - Show this help
  npm run migrate:force    - Force re-run (DANGEROUS: overwrites existing files)

This script:
  1. Scans the ENTIRE _source-java/ tree (any folder layout)
  2. Classifies each .java file: page / steps / util / config / type / infra / unknown
  3. Converts locators to Playwright format
  4. Creates TypeScript skeleton files with TODO markers (pages, steps, utils)
  5. Auto-converts constants and POJOs (no judgement needed, no TODOs)
  6. Copies each .feature file into features/ as-is and generates matching
     playwright-bdd step definitions (Given/When/Then) in src/steps/ — run
     "npm run bddgen" (or "npm test") to compile them at test time
  7. Generates migration-manifest.json so every source file's fate is traceable

After running, use @pw-orchestrator to implement the TODO methods/steps/functions.

SAFETY: This script will NOT overwrite existing output unless --force is used.
`);
}

function checkExistingFiles() {
  const existingPages = getAllFiles(CONFIG.pagesOut, '.page.ts');
  const existingSteps = getAllFiles(CONFIG.stepsOut, '.steps.ts');

  if (existingPages.length > 0 || existingSteps.length > 0) {
    console.log('\n═══════════════════════════════════════════════════════════════');
    console.log('   ⚠️  WARNING: EXISTING FILES DETECTED');
    console.log('═══════════════════════════════════════════════════════════════\n');

    if (existingPages.length > 0) console.log(`   📄 ${existingPages.length} page file(s) already exist`);
    if (existingSteps.length > 0) console.log(`   📝 ${existingSteps.length} step file(s) already exist`);

    console.log('\n   Running migrate.js will OVERWRITE these files!');
    console.log('\n   Options:');
    console.log('     1. Use @pw-orchestrator resume  - Continue from where you left off');
    console.log('     2. npm run migrate:force        - Force overwrite (DANGEROUS)');
    console.log('\n═══════════════════════════════════════════════════════════════\n');

    return true;
  }
  return false;
}

// ═══════════════════════════════════════════════════════════════
// CLI
// ═══════════════════════════════════════════════════════════════

const cmd = process.argv[2];
if (cmd === 'status') showStatus();
else if (cmd === 'help') showHelp();
else if (cmd === 'force') {
  console.log('\n⚠️  FORCE MODE: Overwriting existing files...\n');
  runMigration();
} else {
  if (checkExistingFiles()) {
    console.log('Migration aborted. Use --force to overwrite or resume to continue.\n');
    process.exit(1);
  } else {
    runMigration();
  }
}

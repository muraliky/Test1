---
name: pw-migrate
description: Convert a single file (page, step, or util). Use when you need to re-convert or fix a specific file.
---

# MIGRATE AGENT

Convert a single file.

## ON "@pw-migrate <filepath>"

1. Read: `cat <filepath>`
2. Find `throw new Error(...)` step/method bodies
3. Convert each one — see CONVERSION RULES below for the right shape based on which folder the file is in
4. Save file
5. Report: `✅ <file> converted`

## FILE-TYPE SPECIFIC NOTES

- **src/pages/*.page.ts** — class methods, use `this.<locator>` for element access. If the file's header has both `@source <path>.yaml` and `@source-methods <path>.java`, the locators came from the yaml file (don't touch the constructor) and only the methods below need converting — same conversion rules apply.
- **src/steps/*.steps.ts** — `playwright-bdd` step definitions: `Given('step text', async ({ page, ...fixtures }, ...args) => { ... })` (likewise `When`/`Then`). The step text inside the quotes is a Cucumber expression and must match the original `.feature` file's Gherkin step text exactly (including `{string}`/`{int}` placeholders) — don't rephrase it. Use `fixtures.<pageName>` (e.g. the destructured `loginPage`) to reach page objects, and the destructured `page` for raw Playwright access. If a comment says it was originally a Cucumber `@Before`/`@After` hook, implement the setup/teardown logic inside `src/fixtures/test-fixtures.ts`'s fixture `use()` callback instead of as a step — `playwright-bdd` step files only contain `Given`/`When`/`Then`.
- **src/utils/*.utils.ts** — plain functions, no fixtures parameter, implement the logic directly. If a step/method needs test data, pull it from `src/test-data/*.json` via `getSheetData`/`findScenario` in `src/utils/test-data.utils.ts` rather than reading Excel — the workbook is no longer read at test time.
- **src/config/*.config.ts** and **src/types/*.types.ts** are auto-converted by `migrate.js` and should never need this agent — if one looks incomplete, re-check the original Java source rather than hand-editing.

After editing any `src/steps/*.steps.ts` file, run `node scripts/verify.js` (or `@pw-verify`) to confirm the step text still matches its `.feature` file — the **Feature Step Coverage** section will flag any mismatch.

## CONVERSION RULES

| Selenium | Playwright |
|----------|------------|
| `element.click()` | `await this.element.click()` |
| `element.sendKeys(text)` | `await this.element.fill(text)` |
| `element.clear()` | `await this.element.clear()` |
| `element.getText()` | `await this.element.textContent()` |
| `element.isDisplayed()` | `await this.element.isVisible()` |
| `driver.get(url)` | `await this.page.goto(url)` (page) / `await page.goto(url)` (step, destructured) |
| `Thread.sleep(ms)` | `await this.page.waitForTimeout(ms)` (page) / `await page.waitForTimeout(ms)` (step, destructured) |

| Java/Cucumber (old) | This toolkit (new) |
|---|---|
| `@Given("the user enters {string}") public void enterUsername(String username) { ... }` | `Given('the user enters {string}', async ({ page, loginPage }, username: string) => { ... })` |
| `@Before public void setUp() { ... }` (hook) | Logic moves into `src/fixtures/test-fixtures.ts`'s fixture `use()` callback — not a step |

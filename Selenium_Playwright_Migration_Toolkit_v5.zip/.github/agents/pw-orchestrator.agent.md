---
name: pw-orchestrator
description: Selenium to Playwright migration (playwright-bdd architecture). Converts ONE file at a time, ONE method at a time. Runs CoVe after EACH file - must pass before moving on.
---

# ORCHESTRATOR AGENT

## ⚙️ EXECUTION MODE

**To avoid repeated permission prompts:**
1. Ensure you're in **Agent Mode** in VS Code Copilot Chat
2. Or add to VS Code settings.json:
   ```json
   { "github.copilot.chat.runCommand.enabled": true }
   ```

## ⛔ CRITICAL SAFETY RULES

1. **NEVER RE-RUN migrate.js** - Only run it ONCE at the very start. It scans the **entire** `_source-java/` tree (not just pages/steps/features), so re-running it after manual edits will regenerate skeletons and wipe your work.
2. **If migrate.js already ran** - Use `resume` or read `pending-methods.json` directly
3. **If files exist in src/pages, src/steps, or src/utils** - DO NOT run migrate.js (it will warn and abort)

## CRITICAL WORKFLOW RULES

1. **ONE FILE AT A TIME** - Never work on multiple files simultaneously
2. **ONE METHOD/FUNCTION AT A TIME** - Convert each individually, show before/after
3. **CoVe AFTER EACH FILE** - Run verification immediately after converting each file
4. **FIX BEFORE NEXT** - If CoVe fails, FIX the file until it passes. DO NOT move to next file.
5. **NO SKIPPING** - Process every method/function, every file
6. **SAVE AFTER EACH FILE** - Write file only after all its methods/functions are done

---

## WHAT GETS PROCESSED BY THIS AGENT (and what doesn't)

`migrate.js` classifies the **entire** Java source tree into categories. Only some of them need the method-by-method conversion loop below:

| Category | Needs this agent's loop? | Why |
|---|---|---|
| `src/pages/*.page.ts` | ✅ Usually | Method bodies are skeletons (`throw new Error(...)`). **Exception:** a page generated purely from a `.yaml` UI object map (no matching Java page class found) has 0 methods — locators only, nothing to implement. Check `pending-methods.json`; if a `.page.ts` file isn't listed there, skip it. |
| `src/steps/*.steps.ts` | ✅ Yes | `Given`/`When`/`Then(...)` step bodies are skeletons |
| `src/utils/*.utils.ts` | ✅ Yes | Utility function bodies are skeletons |
| `src/config/*.config.ts` | ❌ No | Auto-converted 1:1 from `static final` fields — already complete |
| `src/types/*.types.ts` | ❌ No | Auto-converted 1:1 from POJO fields — already complete |
| `src/test-data/**/*.json` + `src/utils/test-data.utils.ts` | ❌ No | Excel data-provider workbooks are auto-converted to JSON once (the JSON is now the source of truth, not the original `.xlsx`) — nothing to fill in. Spot-check the JSON against the original sheet, since the Excel→JSON parsing is a best-effort heuristic (see README's "Excel Data Providers" section). |
| `features/*.feature` | ❌ No (copied as-is) | Compiled together with `src/steps/*.steps.ts` by `playwright-bdd`'s own `bddgen` at test-run time. Re-verify after steps are done — see **ON "verify-features"** below. |
| `src/legacy/**/*.legacy.ts` | ⚠️ Manual, not looped | Could not be auto-classified. See **ON "review-legacy"** below. |
| docs/migration-notes/infrastructure.md | ❌ No | Reference notes only, nothing to convert |

---

## ON "start"

### 1. Check if Migration Already Started

```bash
cat migration-progress.json 2>/dev/null || echo "not found"
```

**IF migration-progress.json EXISTS:**
```
⚠️ Migration already in progress!
Use: @pw-orchestrator resume
```
→ DO NOT run migrate.js. Use `resume` instead.

**IF migration-progress.json DOES NOT EXIST:**
→ Continue to step 2.

### 2. Generate Skeletons (ONLY ONCE)

```bash
node scripts/migrate.js
```

This scans **every** `.java` file anywhere under `_source-java/` (not just fixed `pages/`, `steps/`, `features/` folders) and classifies each one. Read the summary it prints, then:

```bash
cat migration-manifest.json
```

Note any files listed under `needsManualReview` — those went to `src/legacy/**/*.legacy.ts` and are handled separately (see **ON "review-legacy"**), not by this loop.

**If migrate.js shows "EXISTING FILES DETECTED" warning:**
```
⚠️ Files already exist. DO NOT force overwrite.
Use: @pw-orchestrator resume
```

### 3. Get File List

```bash
cat pending-methods.json
```

This now has three arrays to process: `pageFiles`, `stepFiles`, `utilFiles`.

### 4. Create Progress File

Create `migration-progress.json`:
```json
{
  "completedFiles": [],
  "totalFiles": <count of pageFiles + stepFiles + utilFiles>,
  "startedAt": "<timestamp>"
}
```

### 5. Process First File

Pick FIRST file from `pageFiles`, then `stepFiles`, then `utilFiles` (in that order). Go to **FILE PROCESSING** section below.

---

## ON "resume"

### 1. Read Progress

```bash
cat migration-progress.json
```

**IF NOT FOUND:** Tell user to run `@pw-orchestrator start` first.

### 2. Read Pending Methods

```bash
cat pending-methods.json
```

### 3. Find Next File

Compare `completedFiles` with all files in `pending-methods.json`:
- First check `pageFiles` array
- Then check `stepFiles` array
- Then check `utilFiles` array

Find first file NOT in `completedFiles`.

### 4. Continue

Go to **FILE PROCESSING** section below with that file.

---

## ON "status"

```bash
cat migration-progress.json
cat pending-methods.json | head -50
```

Show:
- Completed files count
- Remaining files count (broken down: pages / steps / utils)
- Current file (if any)

---

## FILE PROCESSING

**DO THIS FOR ONE FILE ONLY. DO NOT PROCEED TO NEXT FILE UNTIL CoVe PASSES.**

### Step A: Announce File

```
═══════════════════════════════════════════════════════════════
   FILE [X/Y]: <filename>
═══════════════════════════════════════════════════════════════
```

### Step B: Read File

```bash
cat src/pages/<filename>
# or
cat src/steps/<filename>
# or
cat src/utils/<filename>
```

### Step C: List All Methods/Functions

Find all methods/functions with `throw new Error('Method ... not implemented')`, `throw new Error('Step ... not implemented')`, `throw new Error('Hook ... not implemented')`, or `throw new Error('Function ... not implemented')`.

List them:
```
   Methods to convert:
   1. login(username, password)
   2. enterUsername(username)
   3. clickLoginButton()
   4. getErrorMessage()
```

### Step D: Convert Item 1

Look for the `// Original Java:` comment block above the throw statement.

**For src/pages/*.page.ts** — fill in the method body using `this.<locator>`:
```
   ─────────────────────────────────────────
   METHOD [1/4]: login(username, password)
   ─────────────────────────────────────────

   ORIGINAL JAVA (from comments):
   usernameInput.clear();
   usernameInput.sendKeys(username);
   passwordInput.sendKeys(password);
   loginButton.click();

   CONVERTED TYPESCRIPT:
   await this.usernameInput.clear();
   await this.usernameInput.fill(username);
   await this.passwordInput.fill(password);
   await this.loginButton.click();

   ✅ Method 1 done
```

**For src/steps/*.steps.ts** — `playwright-bdd` step definitions: fill in the body of `Given('step text', async ({ page, ...fixtures }, ...args) => { ... })` (likewise `When`/`Then`), using the destructured fixture (e.g. `loginPage`) to reach page objects. **Never change the step text string itself** — it must keep matching the original `.feature` file's Gherkin wording:
```
   ─────────────────────────────────────────
   STEP [1/4]: When('the user enters {string} and {string}', ...)
   ─────────────────────────────────────────

   ORIGINAL JAVA (from comments):
   loginPage.login(username, password);

   CONVERTED TYPESCRIPT:
   When('the user enters {string} and {string}', async ({ page, loginPage }, username: string, password: string) => {
     await loginPage.login(username, password);
   });

   ✅ Step 1 done
```

If the comment says **"Originally a Cucumber @Before hook"**, it's a hook, not a step — implement the equivalent setup/teardown inside `src/fixtures/test-fixtures.ts`'s fixture `use()` callback instead. `playwright-bdd` step files only ever contain `Given`/`When`/`Then`, never raw hooks.

**For src/utils/*.utils.ts** — implement the function body directly (no `fixtures` parameter needed, these are plain helpers):
```
   ─────────────────────────────────────────
   FUNCTION [1/2]: isWeekend(dayOfWeek)
   ─────────────────────────────────────────

   ORIGINAL JAVA:
   return dayOfWeek == 6 || dayOfWeek == 7;

   CONVERTED TYPESCRIPT:
   export function isWeekend(dayOfWeek: number): boolean {
     return dayOfWeek === 6 || dayOfWeek === 7;
   }

   ✅ Function 1 done
```

**IMPORTANT:** After converting, remove the `// TODO:` and `// Original Java:` comments. The final method/function should be clean.

### Step E: Convert Remaining Items

Repeat for Method/Step/Function 2, 3, 4, etc.

**DO NOT SKIP ANY ITEM.**

### Step F: Save Complete File

After ALL methods/functions are converted, save the file with all changes.

---

## ⚠️ STRICT CoVe VERIFICATION (AFTER EACH FILE)

### Step G: Run CoVe on This File

```bash
node scripts/verify.js file <filepath>
```

Example:
```bash
node scripts/verify.js file src/pages/login.page.ts
node scripts/verify.js file src/steps/login.steps.ts
node scripts/verify.js file src/utils/date-utils.utils.ts
```

### Step H: Check CoVe Result

**IF CoVe PASSES (exit code 0):**
```
   ✅ CoVe PASSED: <filename>

   Checks:
   ├─ No Java/BDD Syntax: ✓
   ├─ Page Structure: ✓
   ├─ Count Match: ✓
   ├─ Implementation: ✓
   ├─ No Boilerplate: ✓
   └─ Syntax: ✓
```
→ Go to Step J (Update Progress)

**IF CoVe FAILS (exit code 1):**
```
   ❌ CoVe FAILED: <filename>

   Checks:
   ├─ No Java/BDD Syntax: ✗
   │  └─ ❌ Selenium: .sendKeys() → use .fill()
   ├─ Count Match: ✗
   │  └─ ❌ Methods: Expected 6, Found 4 (2 MISSING)
   └─ ...
```
→ Go to Step I (Fix and Re-verify)

### Step I: FIX AND RE-VERIFY (if CoVe failed)

**DO NOT MOVE TO NEXT FILE. FIX THIS FILE FIRST.**

1. **Read the CoVe errors carefully**
2. **Fix each error:**
   - Java/BDD syntax found → Convert to the Playwright/playwright-bdd equivalent (leftover Java `@Given`/`@When`/`@Then` annotations or Selenium calls, not `Given`/`When`/`Then(...)` calls — those are correct)
   - Missing methods/steps/functions → Find and convert the missing ones
   - Missing locators → Add missing locator definitions
   - Missing await → Add await keyword
   - Boilerplate-only body → Replace placeholder waits/console.log with real logic
   - Unbalanced braces → Fix syntax

3. **Save the fixed file**

4. **Re-run CoVe:**
```bash
node scripts/verify.js file <filepath>
```

5. **Repeat until CoVe PASSES**

```
   🔄 RETRY [1]: Fixing .sendKeys() → .fill()
   🔄 RETRY [2]: Adding missing method getBalance()
   ✅ CoVe PASSED on retry 2
```

**ONLY AFTER CoVe PASSES, proceed to Step J.**

---

### Step J: Update Progress

Add filename to `completedFiles` in `migration-progress.json`.

### Step K: Report File Done

```
═══════════════════════════════════════════════════════════════
   ✅ FILE COMPLETE: <filename>
   ─────────────────────────────────────────
   Methods converted: 4/4
   CoVe: PASSED
═══════════════════════════════════════════════════════════════
```

### Step L: Next File

```
═══════════════════════════════════════════════════════════════
   FILE [X+1/Y]: <next-filename>
═══════════════════════════════════════════════════════════════
```

Go back to Step B with next file.

### Step M: All Files Done

Once `pageFiles`, `stepFiles`, and `utilFiles` are all in `completedFiles`:

```
═══════════════════════════════════════════════════════════════
   ✅ ALL PAGES/STEPS/UTILS CONVERTED
═══════════════════════════════════════════════════════════════
```

→ Continue with **ON "verify-features"**, then **ON "review-legacy"** if any legacy files exist.

---

## ON "verify-features"

Once every step is implemented, confirm every Gherkin step across `features/**/*.feature` resolves to a real `Given`/`When`/`Then(...)` definition:

```bash
node scripts/verify.js
```

Look specifically at the **🥒 FEATURE STEP COVERAGE** section of the output. An "Unmatched" entry means a feature file's step text doesn't match any step definition's Cucumber-expression pattern — fix the mismatch in `src/steps/*.steps.ts` (the step text string passed to `Given`/`When`/`Then`), not the `.feature` file, unless the `.feature` file itself has a typo.

Once CoVe and feature coverage are both clean, actually compile and run the tests (this is what `npm test` does under the hood):
```bash
npx bddgen
npx playwright test --project=desktop-chrome
```
`bddgen` reads `features/**/*.feature` + `src/steps/**/*.steps.ts` and writes runnable spec files into `.features-gen/` (gitignored, regenerated every run) — there's nothing to hand-edit there.

---

## ON "review-legacy"

```bash
cat migration-manifest.json
```

For every entry in `needsManualReview`, open the corresponding file under `src/legacy/**/*.legacy.ts`. It contains the full original Java source in a comment because `migrate.js` couldn't confidently classify it as a page/step/util/config/type. For each one:

1. Read the embedded Java and decide what it actually is (often a helper class, retry/wait utility, or custom assertion).
2. Move the converted logic into the appropriate folder (`src/utils`, `src/pages`, etc.) by hand.
3. Delete the `.legacy.ts` file once migrated.
4. Run `node scripts/verify.js` to confirm the new file passes its category's checks.

This is manual triage, not a method-by-method loop — there's no fixed pattern `migrate.js` can apply automatically.

---

## CoVe CHECKS (What verify.js checks)

### For Pages (src/pages):
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No Selenium/WebDriver/sendKeys/getText |
| Page Structure | export class, constructor(page), Page import |
| Count Match | Locators & Methods count matches Java source |
| Implementation | No `throw new Error` remaining |
| No Boilerplate | Method bodies aren't just placeholder waits/console.log |
| Syntax | Balanced braces, await present |

### For Steps (src/steps) — playwright-bdd Given/When/Then:
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No leftover Java `@Given`/`@When`/`@Then` annotations, no Selenium syntax |
| Step Structure | `Given`/`When`/`Then` imported from the fixtures file; handlers destructure `{ page }` |
| Count Match | `Given`/`When`/`Then(...)` call count matches Java source |
| Implementation | No `throw new Error` remaining |
| No Boilerplate | Bodies aren't just placeholder waits/console.log |
| Syntax | Balanced braces, await present |

### For Utils (src/utils):
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No Java type declarations remaining |
| Util Structure | `export function`/`export async function` present |
| Count Match | Function count matches Java source |
| Implementation | No `throw new Error` remaining |
| No Boilerplate | Bodies aren't trivial placeholders |
| Syntax | Balanced braces |

### For Config/Types (src/config, src/types) — auto-converted, should already pass:
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No Java syntax leaked through |
| Structure | `export const` (config) / `export interface` (types) present |
| Syntax | Balanced braces |

### Feature Step Coverage (features/**/*.feature vs src/steps):
| Check | What it verifies |
|-------|------------------|
| Coverage | Every Gherkin `Given`/`When`/`Then`/`And`/`But` line has a matching `Given`/`When`/`Then(...)` definition somewhere in `src/steps/` |

---

## CONVERSION TABLE

| Selenium | Playwright |
|----------|------------|
| `el.click()` | `await this.el.click()` |
| `el.sendKeys(text)` | `await this.el.fill(text)` |
| `el.clear()` | `await this.el.clear()` |
| `el.getText()` | `await this.el.textContent()` |
| `el.isDisplayed()` | `await this.el.isVisible()` |
| `el.isEnabled()` | `await this.el.isEnabled()` |
| `el.getAttribute(x)` | `await this.el.getAttribute(x)` |
| `driver.get(url)` | `await this.page.goto(url)` |
| `Thread.sleep(ms)` | `await this.page.waitForTimeout(ms)` |
| `new Select(el).selectByVisibleText(t)` | `await this.el.selectOption({label: t})` |

| Java | TypeScript |
|------|------------|
| `for (Type x : list)` | `for (const x of list)` |
| `String s = "x"` | `const s = "x"` |
| `list.size()` | `list.length` |
| `str.equals(x)` | `str === x` |

| Java/Cucumber (old) | This toolkit (new) |
|---|---|
| `@Given("user is on the login page") public void userIsOnLoginPage() { ... }` | `Given('user is on the login page', async ({ page }) => { ... });` — playwright-bdd, matched by the same Cucumber-expression text, compiled together with `.feature` files by `bddgen` |
| `@Before public void setUp() { ... }` (hook) | Logic moves into `src/fixtures/test-fixtures.ts`'s fixture `use()` callback — not a step |

---

## ON "verify"

Run full verification on all files:
```bash
node scripts/verify.js
```

---

## EXAMPLE SESSION WITH CoVe

```
═══════════════════════════════════════════════════════════════
   FILE [1/3]: login.page.ts
═══════════════════════════════════════════════════════════════

   Methods to convert:
   1. login(username, password)
   2. getErrorMessage()

   ─────────────────────────────────────────
   METHOD [1/2]: login(username, password)
   ─────────────────────────────────────────

   ORIGINAL JAVA:
   usernameInput.sendKeys(username);
   passwordInput.sendKeys(password);
   loginButton.click();

   CONVERTED TYPESCRIPT:
   await this.usernameInput.fill(username);
   await this.passwordInput.fill(password);
   await this.loginButton.click();

   ✅ Method 1 done

   ─────────────────────────────────────────
   METHOD [2/2]: getErrorMessage()
   ─────────────────────────────────────────

   ORIGINAL JAVA:
   return errorLabel.getText();

   CONVERTED TYPESCRIPT:
   return await this.errorLabel.textContent();

   ✅ Method 2 done

   ─────────────────────────────────────────
   🔍 Running CoVe: login.page.ts
   ─────────────────────────────────────────

   $ node scripts/verify.js file src/pages/login.page.ts

   📄 login.page.ts
      ├─ No Java/BDD Syntax: ✓
      ├─ Page Structure: ✓
      ├─ Count Match: ✓
      │  └─ ℹ️  Found: 5 locator(s), 2 method(s)
      ├─ Implementation: ✓
      ├─ No Boilerplate: ✓
      └─ Syntax: ✓
      └─ ✅ PASSED

═══════════════════════════════════════════════════════════════
   ✅ FILE COMPLETE: login.page.ts
   ─────────────────────────────────────────
   Methods converted: 2/2
   CoVe: PASSED
═══════════════════════════════════════════════════════════════

═══════════════════════════════════════════════════════════════
   FILE [2/3]: login.steps.ts
═══════════════════════════════════════════════════════════════

   Steps to convert:
   1. Given('the user is on the login page', ...)
   2. When('the user enters {string} and {string}', ...)

   ─────────────────────────────────────────
   STEP [1/2]: Given('the user is on the login page', ...)
   ─────────────────────────────────────────

   ORIGINAL JAVA:
   driver.get("https://example.com/login");

   CONVERTED TYPESCRIPT:
   Given('the user is on the login page', async ({ page }) => {
     await page.goto('https://example.com/login');
   });

   ✅ Step 1 done

   ... (converts remaining steps) ...

   ─────────────────────────────────────────
   🔍 Running CoVe: login.steps.ts
   ─────────────────────────────────────────

   $ node scripts/verify.js file src/steps/login.steps.ts

   📄 login.steps.ts
      ├─ No Java/BDD Syntax: ✓
      ├─ Step Structure (Given/When/Then): ✓
      ├─ Count Match: ✓
      ├─ Implementation: ✓
      ├─ No Boilerplate: ✓
      └─ Syntax: ✓
      └─ ✅ PASSED

═══════════════════════════════════════════════════════════════
   ✅ FILE COMPLETE: login.steps.ts
═══════════════════════════════════════════════════════════════

   ... (continues through utilFiles, then verify-features, then review-legacy) ...
```

---
name: pw-verify
description: Run STRICT CoVe verification on migrated files. Checks structure, count match, implementation, boilerplate, and syntax across pages, steps, utils, config, types, plus feature step coverage and manifest coverage.
---

# VERIFY AGENT

## ON "@pw-verify"

Run full verification on all files (pages, steps, utils, config, types, plus feature step coverage and manifest coverage):
```bash
node scripts/verify.js
```

## ON "@pw-verify <filepath>"

Verify single file:
```bash
node scripts/verify.js file <filepath>
```

---

## CoVe CHECKS

### For Pages — src/pages/*.page.ts (6 checks):
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No Selenium/WebDriver/sendKeys/getText/isDisplayed |
| Page Structure | export class, constructor(page: Page), Page import |
| Count Match | Locators & Methods count matches the source — for a Java-sourced page, against `@FindBy`/`WebElement` fields and `public` methods in the `.java` file; for a yaml-derived page, locator count is checked against the yaml's top-level key count, and method count (if any Java methods were merged in) against the `@source-methods` Java file |
| Implementation | No `throw new Error('Method ... not implemented')` |
| No Boilerplate | Method bodies aren't just placeholder waits/console.log |
| Syntax | Balanced braces, no double async/await |

### Excel-derived test data — src/test-data/**/*.json:
Not part of the per-file CoVe loop — these are auto-converted data, not skeleton code with TODOs. Manifest Coverage (below) still confirms the output JSON exists on disk for every `.xlsx`/`.xls` source file found.

### For Steps — src/steps/*.steps.ts (6 checks), playwright-bdd Given/When/Then:
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No leftover Java `@Given`/`@When`/`@Then` annotations, no Selenium syntax |
| Step Structure (Given/When/Then) | `Given`/`When`/`Then` imported from the fixtures file; at least one `Given(/When(/Then(` call present; handlers destructure `{ page }` |
| Count Match | `Given`/`When`/`Then(...)` call count matches the Java `@Given`/`@When`/`@Then` count from source; `@Before`/`@After` hooks are tracked separately (they become fixture setup/teardown, not steps) |
| Implementation | No `throw new Error('Step "..." not implemented')` |
| No Boilerplate | Bodies aren't just placeholder waits/console.log |
| Syntax | Balanced braces, no double async/await |

### For Utils — src/utils/*.utils.ts (6 checks):
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | No leftover Java type declarations |
| Util Structure | `export function`/`export async function` present |
| Count Match | Function count matches Java source |
| Implementation | No `throw new Error('Function ... not implemented')` |
| No Boilerplate | Bodies aren't trivial placeholders |
| Syntax | Balanced braces |

### For Config — src/config/*.config.ts (3 checks), auto-converted:
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | Clean conversion, nothing leaked through |
| Config Structure | `export const` declarations present, zero "not implemented" placeholders |
| Syntax | Balanced braces |

### For Types — src/types/*.types.ts (3 checks), auto-converted:
| Check | What it verifies |
|-------|------------------|
| No Java/BDD Syntax | Clean conversion, nothing leaked through |
| Type Structure | `export interface` present, zero "not implemented" placeholders |
| Syntax | Balanced braces |

### Legacy — src/legacy/**/*.legacy.ts:
Always flagged with a warning ("needs manual review") — these never "pass" CoVe because `migrate.js` couldn't classify them. Use `@pw-orchestrator review-legacy` to triage them by hand.

### Feature Step Coverage (runs once across features/, not per-file):
Parses every `Given`/`When`/`Then`/`And`/`But` line in `features/**/*.feature`, converts each generated step definition's text into the same Cucumber-expression-aware pattern playwright-bdd itself uses (`{string}`, `{int}`, `{float}`, `{word}`), and confirms every Gherkin step line matches at least one `Given`/`When`/`Then(...)` definition in `src/steps/`. This catches step-text typos or rephrasing before you ever have to run `npm test` to find out.

### Manifest Coverage (runs once, not per-file):
Cross-references `migration-manifest.json` against what's actually on disk, to confirm no `_source-java/**/*.java` file was silently dropped during migration.

---

## Example Output

```
📄 login.page.ts
   ├─ No Java/BDD Syntax: ✓
   ├─ Page Structure: ✓
   ├─ Count Match: ✓
   │  └─ ℹ️  Found: 5 locator(s), 2 method(s)
   ├─ Implementation: ✓
   ├─ No Boilerplate: ✓
   └─ Syntax: ✓
   └─ ✅ PASSED

📝 login.steps.ts
   ├─ No Java/BDD Syntax: ✓
   ├─ Step Structure (Given/When/Then): ✓
   ├─ Count Match: ✗
   │  └─ ❌ Steps: Expected 12, Found 10 (2 MISSING)
   ├─ Implementation: ✓
   ├─ No Boilerplate: ✓
   └─ Syntax: ✓
   └─ ❌ FAILED (1 error)

🥒 FEATURE STEP COVERAGE:
   ❌ 1 of 12 Gherkin step line(s) across 1 feature file(s) have no matching Given/When/Then(...) definition
   ❌   Unmatched: login.feature: "When the user submits an empty form"
```

#!/bin/bash

echo ""
echo "================================================================"
echo "   SELENIUM TO PLAYWRIGHT MIGRATION - Setup"
echo "================================================================"
echo ""

if ! command -v node &> /dev/null; then
    echo "   ❌ Node.js not found. Install from https://nodejs.org"
    exit 1
fi

echo "[1/2] Installing dependencies..."
npm install > /dev/null 2>&1
echo "      ✅"

echo ""
echo "[2/2] Creating directories..."
mkdir -p _source-java
echo "      ✅"

echo ""
echo "================================================================"
echo "   Copy your Java source repo:"
echo "================================================================"
echo ""
echo "   migrate.js scans the ENTIRE tree under _source-java/ — point"
echo "   this at the root of your Selenium/Java project (or any"
echo "   subfolder of it), not just pages/steps/features."
echo ""

read -p "Path to your Java source repo (Enter to skip): " SOURCE_PATH
if [ -n "$SOURCE_PATH" ] && [ -d "$SOURCE_PATH" ]; then
    cp -R "$SOURCE_PATH"/* _source-java/ 2>/dev/null
    echo "      Copied source repo into _source-java/"
fi

echo ""
echo "================================================================"
echo "   SETUP COMPLETE"
echo "================================================================"
echo ""
echo "   Next: @pw-orchestrator start"
echo ""

# Selenium → Playwright Migration Toolkit

Migrate an entire Selenium + Java + QAF + Cucumber repository to Playwright + TypeScript + `playwright-bdd` — your existing `.feature` files stay as the source of truth, and Java step definitions become `playwright-bdd` Given/When/Then step definitions.

## Features

- **Whole-repo scanning** — point it at your entire Java source tree (not just `pages/`, `steps/`, `features/`) and it classifies every file automatically.
- **playwright-bdd output** — `.feature` files are kept as-is; Java `@Given`/`@When`/`@Then` step definitions become `playwright-bdd` `Given`/`When`/`Then(...)` calls, matched against your existing Gherkin step text via the same Cucumber-expression syntax (`{string}`, `{int}`, etc.) — no rewriting required.
- **Auto-classification** — every `.java` file is classified as `page`, `steps`, `infra`, `config`, `type`, `util`, or `unknown`, and routed to a clean, standards-based folder structure.
- **YAML UI object maps** — repos that keep page-object locators in standalone `.yaml` files (e.g. QAF-style element repositories) get them auto-converted into a Playwright page class; a same-named Java page class's methods are merged into that same file instead of generating a broken duplicate. See [YAML Page Objects](#yaml-page-objects) below.
- **Excel data providers** — `.xlsx`/`.xls` data-provider workbooks under `_source-java/` are converted to JSON **once**; the JSON becomes the source of truth (the Excel file isn't read again at test time). See [Excel Data Providers](#excel-data-providers) below.
- **Desktop Chrome** — uses installed Chrome, not bundled Playwright browsers.
- **Secure Auth** — credentials encrypted, session reused across test runs.
- **CoVe Verification** — `scripts/verify.js` cross-checks generated output against the source files, the migration manifest, and confirms every Gherkin step has a matching step definition.

---

## How It Works

```
@pw-orchestrator start
      │
      ├── node scripts/migrate.js
      │     ├── Pass 0   — YAML UI object maps   → src/pages/*.page.ts   (locators auto-converted; merged with a same-named Java page class's methods, if one exists)
      │     ├── Pass 0.5 — Excel data providers   → src/test-data/**/*.json (one-time conversion; JSON is the new source of truth)
      │     ├── Walk _source-java/ recursively (entire repo, any folder layout)
      │     ├── classifyJavaFile() → page | steps | infra | config | type | util | unknown
      │     ├── Page objects   → src/pages/*.page.ts        (skeleton, locators mapped)
      │     ├── Step defs      → src/steps/*.steps.ts        (skeleton, Given/When/Then)
      │     ├── Utils          → src/utils/*.utils.ts        (skeleton)
      │     ├── Config/consts  → src/config/*.config.ts      (auto-converted, no TODOs)
      │     ├── Models/DTOs    → src/types/*.types.ts        (auto-converted, no TODOs)
      │     ├── Infra/runners  → docs/migration-notes/infrastructure.md (documented, not ported — Playwright replaces this natively)
      │     ├── Unrecognized   → src/legacy/**/*.legacy.ts   (flagged for manual review)
      │     └── *.feature      → features/*.feature          (copied as-is — compiled by playwright-bdd's bddgen at test-run time)
      │
      ├── Convert each pending page/step/util method, one file at a time
      │
      └── node scripts/verify.js   (CoVe check — re-run after every file)
```

A feature file's Gherkin steps are matched against your generated step definitions using the same Cucumber-expression syntax Java/Cucumber uses (`{string}`, `{int}`, quoted literals, etc.), so existing step text doesn't need to be rewritten. `playwright-bdd`'s own `bddgen` does the actual compiling at test-run time (`npm test` runs it automatically); `verify.js` does a static check ahead of time so you can catch unmatched steps without needing a live test run.

---

## Quick Start

```bash
# 1. Setup
./setup.sh        # or setup.bat on Windows

# 2. Copy your ENTIRE Java source repo in — any structure, any depth
cp -r /your/project/* _source-java/

# 3. Run migration (in VS Code with Copilot)
@pw-orchestrator start
```

### After migration

```bash
# 1. Setup authentication (REQUIRED before running tests)
npm run auth:setup
# Opens browser → you log in manually → session saved to auth.json

# 2. Run tests (this runs "bddgen" first, compiling features/ + src/steps/
#    into runnable Playwright tests, then runs them)
npm test

# 3. Debug failures
# Use your existing Playwright MCP / debugging agents for this —
# this toolkit's job ends once migration + verification pass.
```

---

## Secure Authentication

**Your credentials are never stored in plain text or exposed to test/debug tooling.**

```bash
npm run auth:setup    # Interactive login (recommended)
npm run auth:check    # Check auth status
npm run auth:clear    # Clear auth when done
```

See `docs/AUTHENTICATION.md` for full details, including how `auth.json` is wired into `playwright.config.ts` via `storageState`.

---

## Agents

| Agent | Purpose |
|-------|---------|
| `@pw-orchestrator` | Drives the full migration — processes pages → steps → utils, one file/method at a time, then runs verification |
| `@pw-migrate` | Re-convert a single file (page, step, or util) |
| `@pw-verify` | Run CoVe verification across all categories, or a single file |

Agents related to Playwright MCP debugging and the old `@pw-debug` workflow have been removed from this toolkit. Once migration and verification are complete, use whatever Playwright execution/debugging agents your team already has for test running and failure triage — that's a separate concern from migration.

---

## YAML Page Objects

Some repos (notably QAF-style UI object repositories) keep page-object locators in a standalone `.yaml` file instead of — or alongside — literal `@FindBy` values in the Java page class itself, e.g.:

```yaml
view_tab:
  element_type: data
  xpath: "(//button[contains(text(),'View')])[2]"
preloader:
  class: "app-loader"
```

with a matching Java class that references elements by key rather than by literal locator:

```java
@FindBy(locator = "view_tab")
private QAFExtendedWebElement view_tab;

public void clickViewTab() { view_tab.click(); }
```

`migrate.js` handles this as **Pass 0**, before the regular Java pass:

1. Every `.yaml`/`.yml` file under `_source-java/` is checked against a heuristic — at least half its top-level entries must look like locator definitions (carrying 2+ of `id`/`css`/`xpath`/`class`/`name`/`linktext`/`partiallinktext`/`tagname`). Yaml files that don't match (unrelated config, etc.) are left untouched.
2. A matching yaml file is converted into a Playwright page class: `account_aggregate.yaml` → class `AccountAggregatePage`, file `account-aggregate.page.ts`. Every top-level key becomes a `readonly ... : Locator` property, picking the first populated locator field in priority order `id > css > xpath > class > name > linktext > partiallinktext > tagname > value`.
3. When the Java pass later reaches a `.java` page class with a matching name (paired by stripping extensions/casing/the trailing "Page" suffix — `AccountAggregatePage.java` ↔ `account_aggregate.yaml`), its methods are **merged into the already-generated yaml-derived file** as TODO stubs, instead of generating a second, locator-less skeleton from the Java file's (in this pattern, unreliable) key-reference `@FindBy` values. The merged file's header gets a second `@source-methods <path>` line alongside the original `@source <yaml path>` line.
4. If a merged method references a name that isn't one of the yaml-derived locators (after case-normalizing — Java field names like `view_tab` are expected to match yaml keys like `view_tab` → locator property `viewTab`), a `⚠️` comment flags it for manual review rather than failing silently.
5. A yaml file with **no** matching Java class still gets a clean locator-only page object (0 pending methods) — this is the common case for repos where the yaml map is the entire page object and methods live elsewhere (steps files, a shared base class, etc.).

This is best-effort name-pairing, not infallible — if your Java page classes don't follow the `<Name>Page.java` ↔ `<name>.yaml`/`<name>_<words>.yaml` convention, the merge won't trigger and you'll get a separate (likely locator-light) skeleton from the Java file as usual; rename or merge by hand in that case.

---

## Excel Data Providers

`.xlsx`/`.xls` files under `_source-java/` (e.g. QAF Excel-based data providers) are converted to JSON **once**, as part of **Pass 0.5** — the JSON becomes the source of truth going forward; `migrate.js` doesn't re-read the Excel file on subsequent runs, and your tests shouldn't either.

Output layout:

```
src/test-data/<workbook-name>.json              → { "<sheetName>": [ {record}, ... ] }
src/test-data/<workbook-name>/<sheetName>.json   → [ {record}, ... ]   (same data, per-sheet)
```

Each sheet is parsed with one of two strategies, tried in order:

1. **Block style** (common in QAF data-provider sheets) — a row whose column A holds a label (the scenario/test-case name) and whose other columns hold field-name headers, immediately followed by a row carrying the corresponding values in those same columns. Repeats down the sheet, optionally separated by blank rows. Produces one record per block: `{ scenario: "<label>", <camelCased header>: "<value>", ... }`.
2. **Flat table** (fallback) — a classic first-row-headers, one-row-per-record table. Used automatically whenever the block-style parser can't find a clean label-row/data-row pairing.

This is a generic, best-effort heuristic, not a guarantee — if your workbook uses a different layout, adjust `parseBlockStyleSheet`/`parseFlatTableSheet` in `scripts/migrate.js` (search for `parseDataProviderSheet`) and re-run `node scripts/migrate.js`. Always spot-check the generated JSON against the original sheet before deleting/archiving the Excel file.

A small typed helper is generated at `src/utils/test-data.utils.ts`:

```typescript
import { getSheetData, findScenario } from '../utils/test-data.utils';

const records = getSheetData('pwm-phase3-test-runner', 'RestrictionValidations');
const row = findScenario('pwm-phase3-test-runner', 'RestrictionValidations', 'Sell_Ticker_On_BuyList');
```

---

## Configuration

### Login Page Settings

Edit `scripts/auth-setup.js`:

```javascript
const CONFIG = {
  loginUrl: 'https://your-app.com/login',
  selectors: {
    usernameInput: '#username',
    passwordInput: '#password',
    loginButton: 'button[type="submit"]',
    loggedInIndicator: '.user-menu',
  },
};
```

---

## Directory Structure

```
├── _source-java/                     # INPUT: your entire Java repo, any layout
├── src/
│   ├── pages/                        # OUTPUT: page objects (*.page.ts)
│   ├── steps/                        # OUTPUT: playwright-bdd step definitions (*.steps.ts)
│   ├── utils/                        # OUTPUT: utility/helper classes (*.utils.ts)
│   ├── config/                       # OUTPUT: constants/config, auto-converted (*.config.ts)
│   ├── types/                        # OUTPUT: models/DTOs, auto-converted (*.types.ts)
│   ├── test-data/                    # OUTPUT: Excel data providers, converted to JSON once (*.json)
│   ├── fixtures/                     # test-fixtures.ts — createBdd(), Given/When/Then, page-object fixtures
│   └── legacy/                       # Unclassified files, ported as-is for manual review (*.legacy.ts)
├── features/                         # Your .feature files, kept as the source of truth
├── .features-gen/                    # Auto-generated by "bddgen" at test-run time (gitignored, not committed)
├── docs/
│   ├── AUTHENTICATION.md
│   └── migration-notes/
│       └── infrastructure.md         # Notes on infra/runner files Playwright replaces natively
├── scripts/
│   ├── migrate.js                    # Classifies & scaffolds the entire repo
│   ├── verify.js                     # CoVe verification
│   └── auth-setup.js
├── .github/agents/                   # Copilot agent definitions (single source — no duplication)
├── migration-manifest.json           # Full audit trail: every source file → classification → output path
├── pending-methods.json              # Tracks remaining TODO methods per file, drives the orchestrator loop
├── cucumber-report/                  # Generated by "npm test" (gitignored)
├── auth.json                         # Saved auth state (gitignored)
└── playwright.config.ts              # Wires defineBddConfig() — features/ + src/steps/ + src/fixtures/
```

---

## Classification Categories

`scripts/migrate.js` classifies every `.java` file under `_source-java/` using content and naming heuristics, in this order:

| Category | Detected by | Output |
|----------|-------------|--------|
| `page-yaml` | Standalone `.yaml`/`.yml` UI object map (≥2 of `id`/`css`/`xpath`/`class`/`name`/`linktext`/`partiallinktext`/`tagname` per entry) | `src/pages/*.page.ts` — locators auto-converted; a same-named Java page class's methods are merged in, if one exists (see [YAML Page Objects](#yaml-page-objects)) |
| `data` | `.xlsx`/`.xls` workbook anywhere under `_source-java/` | `src/test-data/**/*.json` — one-time conversion, JSON is the source of truth (see [Excel Data Providers](#excel-data-providers)) |
| `steps` | `@Given`/`@When`/`@Then` annotations | `src/steps/*.steps.ts` — skeleton (`Given`/`When`/`Then(...)`) |
| `infra` | Test runner / driver-lifecycle / reporting plumbing (`@RunWith`, `CucumberOptions`, `WebDriverManager`, `ExtentReports`, hooks, etc.) | Documented in `docs/migration-notes/infrastructure.md`, not ported — Playwright/playwright-bdd replaces this natively |
| `page` | `@FindBy`, `WebElement` + `By.*`, or `*Page` naming convention | `src/pages/*.page.ts` — skeleton |
| `config` | Mostly `static final` fields, no real methods | `src/config/*.config.ts` — auto-converted |
| `type` | Private fields + matching getters (POJO/DTO), no Selenium | `src/types/*.types.ts` — auto-converted |
| `util` | Everything else with reusable static/helper methods | `src/utils/*.utils.ts` — skeleton |
| `unknown` | Doesn't match any of the above | `src/legacy/**/*.legacy.ts` — ported as-is, flagged for manual review |

Every classification decision is recorded in `migration-manifest.json` (source path → category → output path → review status), so nothing is silently dropped — `verify.js` cross-checks the manifest against disk on every run, and separately checks that every Gherkin step in `features/` resolves to a generated step definition.

---

## Requirements

- Node.js 18+
- VS Code with GitHub Copilot (for the agents)
- Desktop Chrome installed

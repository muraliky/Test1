# Secure Authentication Guide

## Overview

This toolkit uses **Auth State Persistence** - the most secure approach:

1. You log in **once** (manually or via script)
2. Session cookies are saved to `auth.json`
3. The Playwright `setup` project (and any test run) reuses the saved session via `storageState`
4. **Credentials are NEVER stored or exposed to test code**

```
┌─────────────────────────────────────────────────────────────────┐
│  SECURE AUTH FLOW                                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  YOU                        auth.json                  Tests    │
│   │                            │                         │      │
│   │  npm run auth:setup        │                         │      │
│   │  ───────────────────►      │                         │      │
│   │  (enter credentials)       │                         │      │
│   │                            │                         │      │
│   │  Login successful          │                         │      │
│   │  ───────────────────►      │                         │      │
│   │                        [cookies]                     │      │
│   │                        [session]                     │      │
│   │                            │                         │      │
│   │                            │   storageState: './auth.json'  │
│   │                            │ ◄─────────────────────  │      │
│   │                            │                         │      │
│   │                            │   Already logged in!    │      │
│   │                            │ ─────────────────────►  │      │
│   │                                                      │      │
│   │            ❌ Credentials NEVER reach test code      │      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Quick Start

### Option 1: Interactive Login (Recommended)

```bash
npm run auth:setup
```

This opens Desktop Chrome. You log in manually. Session is saved.

### Option 2: Headless Login (CI/Automation)

```bash
# Set credentials securely (use your org's secret management)
export AUTH_ENCRYPTION_KEY="your-32-char-encryption-key"
export TEST_USERNAME="your-username"
export TEST_PASSWORD="your-password"

npm run auth:setup:headless
```

Credentials are encrypted in memory, used once, then cleared.

---

## Commands

| Command | Description |
|---------|-------------|
| `npm run auth:setup` | Interactive login in browser |
| `npm run auth:setup:headless` | Headless login with env vars |
| `npm run auth:check` | Check if auth state exists/valid |
| `npm run auth:clear` | Delete saved auth state |

---

## Configuration

Edit `scripts/auth-setup.js` to match your login page:

```javascript
const CONFIG = {
  loginUrl: 'https://your-app.com/login',

  selectors: {
    usernameInput: '#username',      // Your username field
    passwordInput: '#password',      // Your password field
    loginButton: 'button[type="submit"]',
    loggedInIndicator: '.user-menu', // Element visible after login
  },
};
```

---

## How tests consume the saved session

`playwright.config.ts` wires `auth.json` into every test via the `setup` → `desktop-chrome` project dependency:

```typescript
use: {
  storageState: './auth.json',
},
projects: [
  { name: 'setup', testMatch: /.*\.setup\.ts/, use: { storageState: undefined } },
  { name: 'desktop-chrome', dependencies: ['setup'], use: { ...devices['Desktop Chrome'] } },
],
```

Tests compiled by `playwright-bdd` from `features/*.feature` + `src/steps/*.steps.ts` never see credentials — they just inherit an already-authenticated `page` fixture.

---

## Security Best Practices

### ✅ DO:
- Use `npm run auth:setup` (interactive) when possible
- Set `AUTH_ENCRYPTION_KEY` for headless mode
- Refresh auth state regularly
- Clear auth state when done: `npm run auth:clear`

### ❌ DON'T:
- Commit `auth.json` to git
- Commit `.env.encrypted` with real credentials
- Share auth state files
- Use hardcoded credentials

---

## What Gets Stored

### auth.json (Session State)
```json
{
  "cookies": [
    { "name": "session_id", "value": "abc123..." },
    { "name": "auth_token", "value": "xyz789..." }
  ],
  "origins": [
    { "localStorage": [...] }
  ]
}
```

**Contains:** Session cookies, localStorage, sessionStorage
**Does NOT contain:** Username, password, credentials

### .env.encrypted (Optional)
```json
{
  "username": "aes-256-encrypted-value",
  "password": "aes-256-encrypted-value"
}
```

Only created if you choose to save credentials for headless mode.
Encrypted with AES-256-CBC using `AUTH_ENCRYPTION_KEY`.

---

## Troubleshooting

### "Session expired"
```bash
npm run auth:setup
```

### "Not logged in" during tests
```bash
npm run auth:check  # Check if auth.json exists
npm run auth:setup  # Refresh if needed
```

### "Auth state too old"
Auth state typically expires based on your app's session timeout.
Refresh before running tests:
```bash
npm run auth:setup
```

---

## CI/CD Integration

For CI pipelines, use environment variables:

```yaml
# GitHub Actions example
jobs:
  test:
    steps:
      - name: Setup Auth
        env:
          AUTH_ENCRYPTION_KEY: ${{ secrets.AUTH_ENCRYPTION_KEY }}
          TEST_USERNAME: ${{ secrets.TEST_USERNAME }}
          TEST_PASSWORD: ${{ secrets.TEST_PASSWORD }}
          LOGIN_URL: https://your-app.com/login
        run: npm run auth:setup:headless

      - name: Run Tests
        run: npm test
```

**Note:** Use your CI's secret management for credentials.

@echo off
SETLOCAL EnableDelayedExpansion

echo.
echo ================================================================
echo    SELENIUM TO PLAYWRIGHT MIGRATION - Setup
echo ================================================================
echo.

where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo    X Node.js not found. Install from https://nodejs.org
    pause
    exit /b 1
)

echo [1/2] Installing dependencies...
call npm install >nul 2>nul
echo       OK

echo.
echo [2/2] Creating directories...
if not exist "_source-java" mkdir "_source-java"
echo       OK

echo.
echo ================================================================
echo    Copy your Java source repo:
echo ================================================================
echo.
echo    migrate.js scans the ENTIRE tree under _source-java\ -- point
echo    this at the root of your Selenium/Java project (or any
echo    subfolder of it), not just pages/steps/features.
echo.

set /p SOURCE_PATH="Path to your Java source repo (Enter to skip): "
if defined SOURCE_PATH if exist "!SOURCE_PATH!" (
    xcopy /E /I /Y /Q "!SOURCE_PATH!" "_source-java\" >nul
    echo       Copied source repo into _source-java\
)

echo.
echo ================================================================
echo    SETUP COMPLETE
echo ================================================================
echo.
echo    Next: @pw-orchestrator start
echo.
pause
ENDLOCAL
